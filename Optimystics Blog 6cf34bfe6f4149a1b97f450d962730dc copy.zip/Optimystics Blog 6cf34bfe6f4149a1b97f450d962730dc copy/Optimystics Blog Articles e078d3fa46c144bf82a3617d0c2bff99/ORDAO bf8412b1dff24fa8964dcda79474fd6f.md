# ORDAO

Displays on Pages:: Fractal App, OREC, Respect, Tools
AI summary: ORDAO is an advanced set of EVM smart contracts designed to facilitate decentralized onchain governance and award distribution for the Optimism Fractal community. It enables community-driven decision-making through an innovative consent-based voting system and is currently deployed on the OP Mainnet.
AI summary 1: In this blog post, we delve into ORDAO, an innovative set of EVM smart contracts designed to facilitate a decentralized onchain governance system for Optimism Fractal and other communities. Developed by Tadas, ORDAO represents the next generation of governance software, aiming to enhance community engagement through an advanced consent-based voting system. We will explore the core components of ORDAO, including the Optimistic Respect-based Executive Contract (OREC), and discuss its deployment details, functionalities, and the potential impact on decentralized governance. This article serves as a comprehensive introduction to ORDAO, highlighting its key features and resources for further exploration.
Description: An elegant set of EVM smart contracts that enable a powerful decentralized onchain governance system, which is proposed as the next generation of Optimism Fractal software.
Published?: Yes

![ordao blog thumbnail 1.png](Community%20Delegation%20112074f5adac80cbb06fd76395f4b421/ordao_blog_thumbnail_1.png)

# Introduction

This article provides information about ORDAO, OREC, and related Optimistic Respect-based software. ORDAO is the codename for the next generation of Optimism Fractal app developed and proposed by Tadas. 

ORDAO is a set of smart contracts that enables a powerful decentralized onchain governance and award distribution system for Optimism Fractal, as well as other communities or organizations. Please note this article is in an early stage of development and will be updated soon. Enjoy!

**Table of Contents**

# What is ORDAO?

ORDAO is a code name for a new version of Optimism Fractal software, not yet officially adopted by the community. The core component is [OREC](OREC%20101074f5adac80adaff5ec3442ec8f89.md) (Optimistic Respect-based Executive Contract), which allows for truly decentralized, onchain execution of transactions based on community voting with an innovative consent-based voting system. 

The ORDAO app features a set of EVM smart contracts built with the intention to transfer ownership of the Optimism Fractal [community account](https://optimism.blockscout.com/address/0x53C9E3a44B08E7ECF3E8882996A500eb06c0C5CC) and onchain decision-making powers to the current Respect distribution of Optimism Fractal. It uses a non-transferable, non-fungible token (NFT) system for [Respect](Respect%206357d339d30b425997f3da4dd6f75f32.md), which includes metadata about when and how the Respect was earned.

ORDAO allows for proposing and voting on various types of transactions, including Respect distribution, custom calls, and more. It features an ORConsole app which provides access to all features of the OREC contract through a browser console interface along with a basic UI for Respect Game consensus submissions. A GUI is in development by another team, as you can read in our Fractalgram [article](Fractalgram%20198c4a23def749669d9bab38283ef66e.md).

The ORDAO app is now deployed on the OP Mainnet and may be used by any community or organization. 

### Key ORDAO Resources

- You can explore the concept and implementation in the [Github Repository](https://github.com/sim31/frapps/tree/main/concepts/apps/of2).

- You can learn more by reading below and watching the [video playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lmBtLkZ7fEF6luDLBShtWFT), asking questions about ORDAO and OREC Optimism Fractal [discord](https://discord.gg/dJgrP8ekYC), and joining the [ORDAO Office Hours](https://lu.ma/hjj2no0v).

- 
    
    In essence, ORDAO is a more decentralized, automated, and flexible governance and award distribution system for Optimism Fractal.
    

# What is OREC?

Optimistic Respect-based Executive Contract ([OREC](OREC%20101074f5adac80adaff5ec3442ec8f89.md)) is a smart contract that executes transactions on behalf of an organization or community that has a non-transferrable reputation token, aka [Respect](Respect%206357d339d30b425997f3da4dd6f75f32.md). This allows communities to easily make collective decisions and onchain actions with a high degree of decentralization.

OREC is the core component that ORDAO is built to enable and provides an immense innovation in onchain decentralized governance. Learn more at the [Github Page](https://github.com/sim31/frapps/blob/main/concepts/OREC.md), this [article](OREC%20101074f5adac80adaff5ec3442ec8f89.md), and the videos below.

![[https://optimystics.io/orec](https://optimystics.io/orec)](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f/image.png)

[https://optimystics.io/orec](https://optimystics.io/orec)

# Deployment Details

The deployment details and instructions for testing were posted by Tadas in the Optimism Fractal discord. They are pasted below for your convenience.

## **Deployment of ORDAO for Optimism Fractal**

### **Frontends**

Submission app: [https://of.frapps.xyz/](https://of.frapps.xyz/)

Console: [https://of-console.frapps.xyz/](https://of-console.frapps.xyz/)

### **Contracts**

Orec contract: [https://optimism.blockscout.com/address/0x7Abe89De9172b3F8F122AA8756b0F9Ee989686b7?tab=contract](https://optimism.blockscout.com/address/0x7Abe89De9172b3F8F122AA8756b0F9Ee989686b7?tab=contract)

Respect1155 contract: [https://optimism.blockscout.com/address/0xAA76B4397b0F79D5a16093c3040d8cf95951b9Ee](https://optimism.blockscout.com/address/0xAA76B4397b0F79D5a16093c3040d8cf95951b9Ee)

### **Configuration**

- `voting_period` - 2 days;
- `veto_period` - 2 days;
- `prop_weight_threshold` - 408 Respect
- `max_live_votes` - 4
- `respect_contract` - 0x53C9E3a44B08E7ECF3E8882996A500eb06c0C5CC

See [Orec concept for the meaning of these variables](https://github.com/sim31/frapps/blob/main/concepts/OREC.md) for more details.

## More ORDAO Deployment Details

If you’re interested in seeing the testnet deployment of ORDAO, you can visit this [page](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f/Testnet%20deployment%20of%20ORDAO%2010c074f5adac80d8ab13cc5845a3d0d5.md). If you’re interested in testing the ORDAO mainnet version during Optimism Fractal events, you can see these [instructions](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f/Instructions%20for%20testing%20ORDAO%20mainnet%20version%20dur%2010c074f5adac801eb9b9f7bc5c45db6b.md).

- 
    
    [**Testnet deployment of ORDAO**](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f/Testnet%20deployment%20of%20ORDAO%2010c074f5adac80d8ab13cc5845a3d0d5.md)
    
    [**Instructions for testing ORDAO mainnet version during OF meeting**](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f/Instructions%20for%20testing%20ORDAO%20mainnet%20version%20dur%2010c074f5adac801eb9b9f7bc5c45db6b.md)
    

## First Look at ORDAO

The original version of ORDAO was first previewed during Optimism Fractal’s 28th event. You can see the concept and implementation in this [repository](https://github.com/sim31/frapps), watch Tadas give an [introduction](https://www.youtube.com/watch?v=CsTqPS4HHsw&t=428s) to the software during a recent Optimism Fractal Respect Game, and watch a more detailed [overview](https://youtu.be/CsTqPS4HHsw?si=7Q_z8EkZnEGmfhI_&t=3698) of the app in development during the Optimism Town Hall.

# Videos

![[https://optimismfractal.com/40](https://optimismfractal.com/40)](OREC%20101074f5adac80adaff5ec3442ec8f89/optimism_fractal_40_thumbnail_image.png)

[https://optimismfractal.com/40](https://optimismfractal.com/40)

### [OF 40: Optimism Fractal ORDAO App](https://optimismfractal.com/40)

How are Respect Game apps transforming Optimism Fractal? Enjoy a collaborative builder-empowering Respect Game, then explore an introduction to ORDAO - a new app proposed as the next generation of Optimism Fractal software 📱🍎🌱

You can watch Dan giving a brief overview about ORDAO [here](https://youtu.be/jYcMpadnaZA?si=vemvZ-Wg6u17hE1i&t=3924) and see Tadas’ [presentation](https://youtu.be/jYcMpadnaZA?si=gGB3IAb98oq35DwS&t=4129), followed by a thoughtful community discussion. 

[https://www.youtube.com/watch?v=_58c4pFYyAc](https://www.youtube.com/watch?v=_58c4pFYyAc)

### **EF 108: Optimistic Respect-based Executive Contract**

What is the future of onchain governance? Explore OREC, the new Optimistic Respect-based Executive Contract that simplifies decision-making with unprecedented coordination and decentralization 🏛️📜

[https://youtu.be/-hhIRu_eHjA](https://youtu.be/-hhIRu_eHjA)

### NovaCrypto Interview about ORDAO and OREC

[https://youtu.be/rop-eVcGOmM](https://youtu.be/rop-eVcGOmM)

### ORDAO Office Hours 1

The first ORDAO Office Hours, featuring an introductory overview of ORDAO, OREC, and ORConsole. Recorded on September 16, 2024.

Note: Due to a technical issue, Dan's audio was not recorded. We're sharing the raw footage of the recording now as an educational resource and plan to produce versions with higher production quality in the future.

[https://www.youtube.com/watch?v=MXl1E3jz6t4](https://www.youtube.com/watch?v=MXl1E3jz6t4)

### ORDAO Office Hours 2

The second ORDAO Office Hours featuring a deep dive into OREC, the Optimistic Respect-based Executive Contract. Recorded on September 17, 2024. 

[https://youtu.be/3ze7GRrvv2Y](https://youtu.be/3ze7GRrvv2Y)

### Office Hours 3

The third ORDAO Office Hours meeting, featuring an overview of ORConsole. Recorded on September 18, 2024. 

[https://www.youtube.com/watch?v=fjkWy7Af-ZQ](https://www.youtube.com/watch?v=fjkWy7Af-ZQ)

### ORDAO Office Hours 4

The fourth ORDAO Office Hours meeting, featuring discussions about integrating ORDAO with Optimism Fractal and the next Office Hours. Recorded on September 19, 2024. 

# Related Posts

[Untitled](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f/Untitled%20101074f5adac80abbf3ecadbae5fb322.csv)