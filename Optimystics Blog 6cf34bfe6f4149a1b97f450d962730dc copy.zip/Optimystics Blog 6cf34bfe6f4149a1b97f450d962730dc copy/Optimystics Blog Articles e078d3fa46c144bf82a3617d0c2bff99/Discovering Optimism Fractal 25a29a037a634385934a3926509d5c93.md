# Discovering Optimism Fractal

Displays on Pages:: EF 68
AI summary: The article discusses the Optimism Fractal grant proposal and its interactions with the Optimism Grants Council, highlighting the principles of optimistic consensus games and the ongoing opportunities within the Optimism community. It includes insights from a live discussion during the 68th Eden Fractal meeting, focusing on feedback and future possibilities for the grant proposal.
AI summary 1: The blog post titled "Discovering Optimism Fractal" delves into the intricacies of the Optimism Fractal grant proposal, highlighting its significance and the collaborative efforts of the Optimism Grants Council. It captures the essence of a live discussion held during the 68th Eden Fractal meeting, where community leaders shared insights and reflections on the proposal. The article outlines the foundational principles of the Optimism Fractal, offering readers a glimpse into the innovative concepts introduced by The Optimism Collective, such as RetroPGF and Superchain. With a focus on community engagement and the importance of optimistic consensus games, the post serves as a comprehensive resource for understanding the ongoing developments in the Optimism ecosystem.
Description: Explore the Optimism Fractal grant proposal and interactions with the Optimism Grants Council to discover the benefits of optimistic consensus games!
Published?: Yes

![optimism fractal notion cover image copy.png](Discovering%20Optimism%20Fractal%2025a29a037a634385934a3926509d5c93/optimism_fractal_notion_cover_image_copy.png)

### Welcome!

This article provides an overview of the Optimism Fractal Proposal and the inspiring principles around Optimism grants opportunities. The following was written in September 2023 and provides timestamps from a live discussion with community leaders during the 68th Eden Fractal meeting, which you can see below or in the original [show notes](https://edenfractal.com/68). Enjoy!

### Intro to Optimism

For anyone that’s unfamiliar with [Optimism Collective](https://app.optimism.io/announcement), this is a new type of community designed to reward public goods and build a sustainable future for the open internet. Optimism is a pioneering [Ethereum](https://ethereum.org/en/) L2 community that is highly aligned with our values for creating public goods and improving human coordination for everyone’s benefit!

In case you’ve missed our last [episode](https://edenfractal.com/67), we encourage you to watch Dan Singjoy’s introductory presentation about Optimism at [1:50:20](https://www.youtube.com/watch?v=uDFrqdLmp8I&t=6620s), highlighting the Optimism Fractal grant [proposal](https://app.charmverse.io/op-grants/page-8947154553563161) to start a new community at [2:03:55](https://youtu.be/uDFrqdLmp8I?si=dBv3M_RWEoDbaaPi&t=7435). The introductory presentation provides an overview of brilliant innovations from The Optimism Collective, including [RetroPGF](https://app.optimism.io/retropgf), [Superchain](https://app.optimism.io/superchain), and the [Optimistic Vision](https://www.optimism.io/vision). 

### Optimism Fractal Grant Proposal

The Optimism Fractal proposal created by the Optimystics team was the root for the ongoing Optimism topic. This episode was focused on providing a thorough review of the grant application, including preliminary feedback from reviewers from the Optimism Grants council based on their rubric at [37:10](https://www.youtube.com/watch?v=QcWcW2meiTg&t=2230s). You can find links to preliminary feedback and to rubic in the Rubic section below. The good news that the grant proposal made it to the final evaluation stage encouraged further brainstorming on possibilities and tickled more engagement.

Dan Singjoy summarizes the scope of the Optimism Fractal proposal at [1:42:00](https://www.youtube.com/watch?v=QcWcW2meiTg&t=6120s), including to build the initial toolset for the first season with EVM compatible tools for social games, to host meetings, build educational welcoming materials and market it. At [2:10:00](https://www.youtube.com/watch?v=QcWcW2meiTg&t=7800s), the group goes through the curated feedback notes where Dan explains the rubric criteria meanings, scores, and ranking process. He goes through the proposed milestones in the Optimism Fractal during [2:18:00](https://www.youtube.com/watch?v=QcWcW2meiTg&t=8280s), and then presents the many ongoing Optimism [grants](https://community.optimism.io/docs/governance/get-a-grant/#) programs and builder opportunities at [2:20:55](https://youtu.be/QcWcW2meiTg?t=8455).

### Full Episode

Watch the full episode below for all the exciting discussions about this and check out this [article](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6.md) for more details about the roots of Optimism Fractal! Thanks for reading and watching :)

[https://youtu.be/QcWcW2meiTg](https://youtu.be/QcWcW2meiTg)

**EF 68: Planting Optimism Fractal**

What are the best growth opportunities for communities creating public goods? We explore the new Optimism Fractal grant proposal, RetroPGF, and other grants to fund public goods creators in the Optimism Ecosystem 🌱