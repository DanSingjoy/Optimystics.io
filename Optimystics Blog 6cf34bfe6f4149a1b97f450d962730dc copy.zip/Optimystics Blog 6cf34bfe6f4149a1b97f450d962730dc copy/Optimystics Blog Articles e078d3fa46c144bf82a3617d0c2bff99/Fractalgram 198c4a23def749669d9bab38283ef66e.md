# Fractalgram

Displays on Pages:: Firmament, Fractal App, ORDAO, OREC, Respect, Tools
AI summary: Fractalgram is an innovative web application designed to facilitate community engagement through the Respect Game, offering both current features and a next-generation version that enhances user interaction and governance capabilities on Optimistic blockchains.
AI summary 1: This blog post provides a comprehensive overview of Fractalgram, an innovative web application designed to facilitate community engagement through the Respect Game. The article discusses the current version of Fractalgram, its features, and the ongoing development of its next-generation app, which promises to enhance user experience with new functionalities. Readers will find insights into how Fractalgram integrates with various blockchain technologies, its open-source nature, and the collaborative efforts of its developers. Additionally, the post highlights resources for further exploration of Fractalgram and its impact on community decision-making and cooperation.
Description: An innovative web app that helps communities play the Respect Game at community events or in asynchronous chats.
Published?: Yes

![fractalgram app 1280720.jpg](Fractalgram%20198c4a23def749669d9bab38283ef66e/fractalgram_app_1280720.jpg)

## Welcome

This article provides an introduction and resources about Fractalgram. Fractalgram is an innovative web app that helps communities cooperate with the [Respect Game](https://optimystics.io/respectgame). The following article shows the current version and a next generation Fractalgram app that is in development. Enjoy!

**Table of Contents**

![fractalgram blue title1.png](Fractalgram%20198c4a23def749669d9bab38283ef66e/fractalgram_blue_title1.png)

## Fractalgram Current Version

The first version of Fractalgram is a fun and innovative telegram web app that makes it easy for communities to play the Respect Game. Fractalgram provides an intuitive interface that makes it easy and delightful for non-technical communities to play fun web3 games and cooperate more effectively!

Players can use Fractalgram to rank contributions and elect delegates with automated Telegram polls, then push one button to immediately send all scores to the web app.  The process of voting and entering scores is fun, simple, and seamless for players of all ages with Fractalgram. 

You can learn more about Fractalgram by reading the introductory [blog post](https://peakd.com/dao/@sim31/introducing-fractalgram) and watching Tadas’ provide demonstrate how it works [here](https://youtu.be/d6KXgSlFDrQ?t=4758). You can also watch Tadas introduce the app for the first time in this [demo](https://www.youtube.com/watch?v=SyI8ghnXznI&t=1891s). The app features smooth integrations with the Eden Fractal [web app](https://edenfracfront.web.app/) and you can hear about on-chain compatibility [here](https://www.youtube.com/watch?v=MRMOd8YnnLE&t=3447s). 

The client side code of Fractalgram is totally open source, which you can see in the Github [repository](https://github.com/sim31/fractalgram). You learn many more exciting details about Fractalgram by watching [EF 35](https://edenfractal.com/35), [EF 36](https://edenfractal.com/36) and reading this [story](https://edenfractal.com/36#737afbddb529489684b873ad1ac4d5e0).

### Introductory Video

[https://youtu.be/Ggpfi55eKEw](https://youtu.be/Ggpfi55eKEw)

How do we use the OP Mainnet to play the Respect Game? We demonstrate Fractalgram and our intuitive webapp that helps communities reach consensus while having fun!

- 
    
    
    ## Fractalgram on Optimism
    
    Fractalgram is a component of the OP Fractal Stack that makes it easier to play Respect Games on Optimistic blockchains, such as the OP Mainnet. It is currently being used in weekly Optimism Fractal and Eden Fractal meetings. You can watch an introductory walkthrough of Fractalgram during the first Optimism Fractal meeting at [34:05](https://youtu.be/UxZIcui76Po?si=pOtDI6akHsu3w1Es&t=2045) in the following video.
    
    [https://youtu.be/UxZIcui76Po?si=pOtDI6akHsu3w1Es&t=2045](https://youtu.be/UxZIcui76Po?si=pOtDI6akHsu3w1Es&t=2045)
    

## Next Generation Fractalgram App

Development of the next generation Fractalgram web app began in mid-2024, introducing exciting new features to the Optimism Fractal ecosystem. This will provide many improvements over the current telegram web app. Abraham Becker initiated this project during Onchain Summer, with Howard joining the collaboration in September. 

They are building a comprehensive web application with features that include:

- Wide-ranging wallet connection integrations for seamless user access
- Custom usernames for a personalized experience
- Robust voting functionality to facilitate community decision-making
- Integration with Hats Protocol for enhanced role management
- Planned integration with [ORDAO](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f.md) smart contracts for advanced governance features
- Foundations for an all-in-one app to streamline community interactions

You can see a demo of this application [here](https://youtu.be/WCWNgR6_HV4?si=atcQHLTzBzbrfakI&t=1299) and find more details about their work in this [application](https://devfolio.co/projects/-d3a5) for Onchain Summer. You can see updates from Abraham and Howard at Optimism Fractal weekly events by watching this [playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lk5Aavi98CqFj7ryM42bvbP).

- 
    
    
    Since mid-2024, development has been underway on the next generation Fractalgram app, bringing exciting new features to the Optimism Fractal ecosystem.
    
    Abraham Becker started developing the next generation Fractalgram app during Onchain Summer and has built many exciting features, including a wide range of wallet connection integrations, custom user names, and the foundations of an all-in-one app with voting functionality. Howard started collaborating with Abraham to build this app in September and has started to integrate Hats Protocol. They are planning to integrate the app with the [ORDAO](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f.md) smart contracts. You can see a demo of this application [here](https://youtu.be/WCWNgR6_HV4?si=atcQHLTzBzbrfakI&t=1299) and find more details about their work in this [application](https://devfolio.co/projects/-d3a5) for Onchain Summer. 
    
    You can see updates from Abraham and Howard at Optimism Fractal weekly events by watching this [playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lk5Aavi98CqFj7ryM42bvbP).
    
    Key developments include:
    
    - A demo of the application available [here](https://youtu.be/WCWNgR6_HV4?si=atcQHLTzBzbrfakI&t=1299)
    - Detailed information about their work in this Onchain Summer [application](https://devfolio.co/projects/-d3a5)
    - Regular updates from Abraham and Howard at Optimism Fractal weekly events, viewable in this [playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lk5Aavi98CqFj7ryM42bvbP)
    
     This comprehensive web application includes:
    
    A wide range of wallet connection integrations for seamless user access
    
    - Custom usernames to personalize the experience
    - Robust voting functionality to facilitate community decision-making
    - Integration with Hats Protocol for enhanced role management
    - Planned integration with [ORDAO](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f.md) smart contracts for advanced governance features
    - Foundations for an all-in-one app to streamline community interactions
    
    You can learn more in our article about [Fractalgram](Fractalgram%20198c4a23def749669d9bab38283ef66e.md).
    

![Invite Participants 1.jpg](Fractalgram%20198c4a23def749669d9bab38283ef66e/Invite_Participants_1.jpg)

![End Screen 1.jpg](Fractalgram%20198c4a23def749669d9bab38283ef66e/End_Screen_1.jpg)

# More Resources

The following resources provide more historical information about Fractalgram for anyone who is interested. The following video shows when Tadas first introduced Fractalgram to the Eden Fractal community: 

![[https://edenfractal.com/36](https://edenfractal.com/36)](Fractalgram%20198c4a23def749669d9bab38283ef66e/ef_pentagon_hands_1_more_squar_155.png)

[https://edenfractal.com/36](https://edenfractal.com/36)

### [EF 36: Fractalgram, Cagendagram, and Proxies!](https://edenfractal.com/36)

After Eden+Fractal, Tadas demos Fractalgram and the group explores how the new app helps communities cooperate. Fractalgram is an innovative telegram web app that helps communities cooperate with fractally or Eden style consensus meetings. You can watch Tadas’ introduce the new app and demonstrate how it works at [1:19:18](https://youtu.be/d6KXgSlFDrQ?t=4758). You can view the timestamps below to navigate thoughtful discussions amongst several community members for the following half hour.

You can read learn more about Fractalgram by reading the introductory [blog post](https://peakd.com/dao/@sim31/introducing-fractalgram), watching Tadas share the first [demo](https://www.youtube.com/watch?v=SyI8ghnXznI&t=1891s) during week 34, and joining the fractalgram [telegram group](https://t.me/+AgHQ4qT31qw0NDJk). The app features smooth integrations with the Eden Fractal [web app](https://edenfracfront.web.app/) and you can hear about on-chain compatibility [here](https://www.youtube.com/watch?v=MRMOd8YnnLE&t=3447s). The client side code is totally open source, which you can see in the Github [repository](https://github.com/sim31/fractalgram). You can see Tadas announce Fractalgram in the Eden Fractal telegram group [here](https://t.me/edenfractal/959). 

- Fractal Apps
    
    
    Pascal also wrote a new [article](https://hive.blog/thiagore/@thiagorewards/fractalgram-a-tool-to-facilitate-fractal-consensus-building-on-eos) about Fractalgram on ThiagoRe. More details coming soon!
    
    ### Fractal Apps
    
    We offer two complementary apps that empower communities with fun meetings and independent community computing infrastructure. The apps are called Fractal and Fractalgram.
    
    - Fractalgram enables anyone to easily play consensus games by voting to give respect and elect leaders in Telegram polls.
    
    - Fractal provides a simple web3 interface to securely post results on independent community computers, such as EOS and Ethereum.
    
    Fractal and Fractalgram are tightly integrated, so players can enjoy playing consensus games during community meetings and then post their scores on a blockchain in just two clicks. These apps unleash the benefits of Web3 with a fun and intuitive Web2 experience that anyone can enjoy.
    
    ![tools1 Eden ƒractal cardioid with gradient overlay 2.png](Fractalgram%20198c4a23def749669d9bab38283ef66e/tools1_Eden_ractal_cardioid_with_gradient_overlay_2.png)
    

## Repositories

You can see the original Fractalgram Optimystics repository [here](https://github.com/optimystics). You can find Abraham’s repository in the application linked above.

- 
    
    You can see original the [Fractalgram repository](https://github.com/sim31/fractalgram) here. It works well with Eden Fractal software for the [Original Smart Contract](https://github.com/James-Mart/eden-fractal-contract) and [Original User Interface](https://github.com/lennarlehestik/fractalvotingsystem). 
    

# Related Posts

[Untitled](Fractalgram%20198c4a23def749669d9bab38283ef66e/Untitled%2010d074f5adac807596b7e718e9ae6fb4.csv)