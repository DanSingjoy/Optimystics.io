# @farcasteradmin.eth’s Launchcaster: "$MEMECOINS - create your own memecoin in 4 clicks"

AI summary: This document contains a discussion about creating memecoins and the launch platform for them. It also includes links to relevant resources and comments from users.
Published?: No
URL: https://www.launchcaster.xyz/p/6580a2c4c2cc6b930fc8d1c9

gm degens, the TIME HAS COMETH you can now create YOUR OWN MEMECOIN in like 4 clicks!!! go to [memecoins.science](https://memecoins.science/) now — that's all you need to do to generate an ERC20 memecoin then you'll get the mint link that all your fellow degens can use to mint!!! $FARTS $FARCATS $PURPLE $POINTS $WHATEVER you have the power!!

![@farcasteradmin%20eth%E2%80%99s%20Launchcaster%20$MEMECOINS%20-%20cr%207bf7ef9c33e44af998d3ae5684f292fe/og.jpg](@farcasteradmin%20eth%E2%80%99s%20Launchcaster%20$MEMECOINS%20-%20cr%207bf7ef9c33e44af998d3ae5684f292fe/og.jpg)

[@farcasteradmin.eth](https://www.launchcaster.xyz/launchers/0xbf74483DB914192bb0a9577f3d8Fb29a6d4c08eE)

3w

also FOSS under MIT: [github.com/Borodutch/memecoins-frontend](https://github.com/Borodutch/memecoins-frontend) [github.com/Borodutch/memecoins-contract](https://github.com/Borodutch/memecoins-contract) "WHAT THE HELL I THOUGHT GIVING THINS AWAY FOR FREE WAS ILLEGAL" yeah? THINK AGAIN

[@farcasteradmin.eth](https://www.launchcaster.xyz/launchers/0xbf74483DB914192bb0a9577f3d8Fb29a6d4c08eE)

3w

JUST LOOK AT THIS BEAUTY you can even UPGRADE THEM FFS WHAT THE HELL MY FEET ARE LITERALLY BURNING AND MIND IS BLOWN AAAAAAAAAAAAAA

[@0xsatori](https://www.launchcaster.xyz/launchers/0xdcf37d8Aa17142f053AAA7dc56025aB00D897a19)

3w

Why create a new coin when we have $wowow frens? FOCUS WOWOW

[@farcasteradmin.eth](https://www.launchcaster.xyz/launchers/0xbf74483DB914192bb0a9577f3d8Fb29a6d4c08eE)

3w

cc @0xen, NO CODING REQUIRED

[@jrf](https://www.launchcaster.xyz/launchers/0x10676738Db9601C5AF144A17C3A48C8eBDA7E353)

3w

Memecoins down to a science 😉

[@ddrtst](https://www.launchcaster.xyz/launchers/0xfb4eecef04f1d45ead80a7a471d60b38b14eaa9a)

3w

everyone deserves a memecoin

This is cool - maybe Merkle list for claims rather than manual airdrop?

[@farcasteradmin.eth](https://www.launchcaster.xyz/launchers/0xbf74483DB914192bb0a9577f3d8Fb29a6d4c08eE)

3w

happy to review a pull request

3w

Finally, the perfect platform for my $DICKINU coin!

[@farcasteradmin.eth](https://www.launchcaster.xyz/launchers/0xbf74483DB914192bb0a9577f3d8Fb29a6d4c08eE)

3w

go make it

[@farcasteradmin.eth](https://www.launchcaster.xyz/launchers/0xbf74483DB914192bb0a9577f3d8Fb29a6d4c08eE)

3w

make this one too

[@greg](https://www.launchcaster.xyz/launchers/0x179A862703a4adfb29896552DF9e307980D19285)

3w

nerd question from solidity noob - why have `initialize()` instead of just having those params be part of the [Memecoin.sol](https://memecoin.sol/) constructor?

[@farcasteradmin.eth](https://www.launchcaster.xyz/launchers/0xbf74483DB914192bb0a9577f3d8Fb29a6d4c08eE)

3w

the contracts are upgradeable :) so `initialize` is the new constructor

[@samantha](https://www.launchcaster.xyz/launchers/0xD5b472FfAF39476F83B8975667169AB6F9216dCD)

3w

Lol how did I know 😆😆

[@lishousesq4rz](https://www.launchcaster.xyz/launchers/0x44d9ec4cbd88556b706be3079e3762a2e5a3315f)

3w

meowow WOW

[@blankspace](https://www.launchcaster.xyz/launchers/0x5d2b7f517ea0c3a68e58c32f97b2b2c080ea3d6f)

3w

wowow it's science

[@farcasteradmin.eth](https://www.launchcaster.xyz/launchers/0xbf74483DB914192bb0a9577f3d8Fb29a6d4c08eE)

3w

OK I ADDED OP TOO

[@chrismartz](https://www.launchcaster.xyz/launchers/0x224e69025a2f705c8f31efb6694398f8fd09ac5c)

3w

creating monsters lol be safe out there

[@farcasteradmin.eth](https://www.launchcaster.xyz/launchers/0xbf74483DB914192bb0a9577f3d8Fb29a6d4c08eE)

3w

been doing this since 2017 when i made fondu.io

[@twifarcaster.eth](https://www.launchcaster.xyz/launchers/0x6f25a0dd4c3bd4ef1a89916b3e0162061249885a)

3w

Daym Boro [https://twitter.com/lmrankhan/status/1729612004707455209?t=PbzgUrypxjYSjerI2Q1s_w&s=19](https://twitter.com/lmrankhan/status/1729612004707455209?t=PbzgUrypxjYSjerI2Q1s_w&s=19)

[@wwill](https://www.launchcaster.xyz/launchers/0xea8b5f7128ac329f5c38da6f191686dd531459db)

3w

$POINTS⁉️⁉️⁉️⁉️