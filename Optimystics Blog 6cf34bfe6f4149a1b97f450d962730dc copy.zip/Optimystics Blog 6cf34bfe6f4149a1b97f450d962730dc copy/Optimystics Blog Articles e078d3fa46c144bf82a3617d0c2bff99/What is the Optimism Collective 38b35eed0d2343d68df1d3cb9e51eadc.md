# What is the Optimism Collective?

AI summary: The Optimism Collective is a community-driven initiative focused on promoting positivity and resilience in individuals and society.
Published?: No

Optimism 

[https://www.youtube.com/playlist?list=PLa5URJF9l5lnG4TEQj-57IX6dFtC3LAvt](https://www.youtube.com/playlist?list=PLa5URJF9l5lnG4TEQj-57IX6dFtC3LAvt)