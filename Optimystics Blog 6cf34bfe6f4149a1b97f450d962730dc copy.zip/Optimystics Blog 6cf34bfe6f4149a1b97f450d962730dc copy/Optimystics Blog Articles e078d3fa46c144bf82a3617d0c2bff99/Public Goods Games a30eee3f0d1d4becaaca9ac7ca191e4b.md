# Public Goods Games

Displays on Pages:: Cagendas, Octant, Optimism Town Hall, Our Fractal Journey to Optimism, Respect, Respect Game, RetroPitches, cignals, games, optopics
AI summary: This document discusses Public Goods Games, a concept that fosters collaboration and coordination among creators to support the Optimism Collective. It highlights various games, their purposes, and how they can help promote public goods and engage communities.
AI summary 1: In this blog post, we explore the innovative concept of Public Goods Games, designed to foster collaboration and creativity within the Optimism Collective. Similar to the Olympic Games, these tournaments invite talented creators to compete, collaborate, and contribute towards the common good, enhancing community engagement and public goods development. We delve into various aspects, including the mechanics of the Respect Game, the exciting format of RetroPitches, and how these games can empower individuals and communities alike. Join us as we uncover the potential of these games to create meaningful impact and promote a thriving ecosystem for public goods creation.
Description: Imagine epic tournaments where talented creators compete, collaborate, and coordinate to help the Optimism Collective. Like the Olympic Games, but for creating public goods. 
Published?: Yes

![Untitled](Public%20Goods%20Games%20a30eee3f0d1d4becaaca9ac7ca191e4b/Untitled.png)

GM Optimists,

Today we ask three important questions and invite you to join joyful competitions to optimize the growth of Optimism!

1. How can public goods creators stand out from the crowd and be recognized for their work?

1. How can citizens fairly reward everyone creating a positive impact to the Optimism Collective?

1. What is the best way to share fun, inspiring experiences that help everyone enjoy the benefits of Optimism?

The answer dear friends is Public Goods Games. Imagine epic tournaments where talented creators compete, collaborate, and coordinate to help the Optimism Collective. Like the Olympic Games, but for creating public goods. 

Imagine groups of builders, artists, and entrepreneurs coming together from around the world to share their work and award public goods creators who grow Optimism. A community gathering of optimistic leaders playing innovative consensus games to spread the [Optimistic Vision](https://www.optimism.io/vision), summon Ether’s Phoenix, and create a better future for all.

We’re excited to share exciting new types of games that creates profound benefits for everyone on the Superchain. Onchain Social Games. Consensus games.  Public Goods Games!

- Enhancing article
    
    
    ## Enhancing RetroPGF with Public Goods Games
    
    RetroPGF is a groundbreaking mechanism to reward public goods creators and grow communities, but it has a key problem that public goods games can solve. You can explore this [article](https://optimystics.io/enhancing-retropgf-with-optimism-fractal) to learn how Optimism Fractal can relieve burden from badgeholders, raise awareness public goods creators, and help the citizens fairly reward impact in the Optimism Collective.
    
    ![[https://optimystics.io/enhancing-retropgf-with-optimism-fractal](https://optimystics.io/enhancing-retropgf-with-optimism-fractal)](../enhancing_retropgf_with_optimism_fractal_no__text.png)
    
    [https://optimystics.io/enhancing-retropgf-with-optimism-fractal](https://optimystics.io/enhancing-retropgf-with-optimism-fractal)
    

- TOC, Respect Game, RetroPitches, Where to play, where to watch,
    
    
    **Table of Contents**
    
    ## Respect Game
    
    The Respect Game is a simple and profoundly helpful game that anyone can play to grow their community. This consensus game is at the heart of Optimism Fractal and our work at Optimystics. You can watch intro videos and learn more about the Respect Game in this [article](https://optimystics.io/respectgame). 
    
    ![[https://optimystics.io/respectgame](https://optimystics.io/respectgame)](../respect_game_1.png)
    
    [https://optimystics.io/respectgame](https://optimystics.io/respectgame)
    
    ## RetroPitches
    
    RetroPitches feature fun, friendly competitions where RetroPGF applicants present their projects and participants rank their pitches. These games give public goods creators a great opportunity to promote their RetroPGF grant and provide citizens with an easy way to learn about exciting work in the Optimism Collective. You can learn more about RetroPitches in this [article](https://optimystics.io/retropitches).
    
    ![[https://optimystics.io/retropitches](https://optimystics.io/retropitches)](Public%20Goods%20Games%20a30eee3f0d1d4becaaca9ac7ca191e4b/Untitled%201.png)
    
    [https://optimystics.io/retropitches](https://optimystics.io/retropitches)
    
    ## Where to Play Public Goods Games?
    
    Optimism Fractal provides a perfect place to collaborate with talented optimists and earn awards for helping the Optimism Collective. Optimism Fractal is dedicated to fostering collaboration and awarding public goods creators on Optimism. You can register for weekly email reminders at [event page](http://lu.ma/optimismfractal) and find details at [OptimismFractal.com](http://optimismfractal.com/). 
    
    You can explore other communities that are playing these public goods games on our [events](https://lu.ma/optimystics) and [communities](https://optimystics.io/communities) pages. In addition, our [tools](https://optimystics.io/tools) are all open-source so anyone can play the Respect Game at their events. We’re happy to help you get started, so feel free to reach out with any questions or comments!
    
    ![[http://lu.ma/optimismfractal](http://lu.ma/optimismfractal)](Public%20Goods%20Games%20a30eee3f0d1d4becaaca9ac7ca191e4b/optimism_fractal_thursday_17_.png)
    
    [http://lu.ma/optimismfractal](http://lu.ma/optimismfractal)
    
    ## Where to Watch Public Goods Games?
    
    Lights, camera, action! We create videos of events that we host to help communities grow with Optimism.  You can explore show notes for each episode and watch more on our [videos](https://optimystics.io/videos) page and [youtube channel](https://www.youtube.com/@Optimystics_).  In addition you can also explore hundreds of videos of Respect Gameplay on the Eden Creators [youtube channel,](https://www.youtube.com/@EdenCreators) [OptimismFractal.com/media](http://OptimismFractal.com/media), and [EdenFractal.com/videos](http://EdenFractal.com/videos). You can watch the video below for an example of how public goods games can help communities thrive. Enjoy!
    
    ![[https://optimystics.io/videos](https://optimystics.io/videos)](The%20Respect%20Game%2044c6b16009074f2da6185024c7e48e5c/optimystics_videos.webp)
    
    [https://optimystics.io/videos](https://optimystics.io/videos)
    

## Explore Public Goods Games

You can explore the article below to learn about amazing onchain social games for fostering public goods, including the Respect Game, Cagendas, and RetroPitches. Remember to join our [weekly events](https://lu.ma/optimystics) to start playing! 

[Untitled](Public%20Goods%20Games%20a30eee3f0d1d4becaaca9ac7ca191e4b/Untitled%20a93246c5aece42b3809412cf562f1dd9.csv)

## Media

![[https://warpcast.com/rosmari/0xefa02b02](https://warpcast.com/rosmari/0xefa02b02)](Public%20Goods%20Games%20a30eee3f0d1d4becaaca9ac7ca191e4b/image.png)

[https://warpcast.com/rosmari/0xefa02b02](https://warpcast.com/rosmari/0xefa02b02)

## PGG Videos

Lights, camera, action! Watch videos of public goods games at [Optimystics.io/videos](http://Optimystics.io/videos). Here are a some videos about public goods games that we recommend:

![[https://optimismfractal.com/7](https://optimismfractal.com/7)](Public%20Goods%20Games%20a30eee3f0d1d4becaaca9ac7ca191e4b/optimism_fractal_7_thumbnail_final_.png)

[https://optimismfractal.com/7](https://optimismfractal.com/7)

### [**OF 7: The Regen Games**](https://optimismfractal.com/7)

How can we regenerate society through gaming? We innovate and grow Optimism with fun onchain coordination games like Respect Game and RetroPitches ⚽️✨

![[https://youtu.be/wFc02QUdLjg](https://youtu.be/wFc02QUdLjg)](Public%20Goods%20Games%20a30eee3f0d1d4becaaca9ac7ca191e4b/retropgf_pitches_3_thumbnail_final.png)

[https://youtu.be/wFc02QUdLjg](https://youtu.be/wFc02QUdLjg)

### [RetroPitches 3](https://youtu.be/wFc02QUdLjg)

How can public goods creators spread the word about their work? RetroPGF applicants share presentations then judges vote on the most impactful, exciting, heartwarming, and fun pitches 🎤 🏟️ ✨

![[https://edenfractal.com/56](https://edenfractal.com/56)](Cignals%2050abfee5a9f449138263b8c109f72b38/EF_56_final_thumbnail.png)

[https://edenfractal.com/56](https://edenfractal.com/56)

### [**EF 56: Gamifying Public Goods**](https://edenfractal.com/56)

Aloha! In our fourth public goods pitch session, we ride the groovy waves of collaboration and play Cignals to rank the most fun and beneficial pitches! 🌴 🌊 🏄🏽‍♂️

![[https://edenfractal.com/55](https://edenfractal.com/55)](Cignals%2050abfee5a9f449138263b8c109f72b38/EF_55_final.png)

[https://edenfractal.com/55](https://edenfractal.com/55)

### [EF 55: **Inventing Games for Public Goods!**](https://edenfractal.com/55)

Jumping out with our third public goods session where we share and rank amazing pitches from Eden Fractal community members with the new Cignals app! 🪴 🌈 🌞

![[https://optimismfractal.com/6](https://optimismfractal.com/6)](../../OptimismFractal%20com%20c238e1244229466ba8b7753b74104b6f/Optimism%20Fractal%20Website%20Database%20f636c69e7a3a4435a2163516c9e87249/Media%20eac86b8f965a415c9a69c2b58aa97103/optimism_fractal_6_thumbnail_final_.png)

[https://optimismfractal.com/6](https://optimismfractal.com/6)

### [OF 6: Public Goods Games](https://optimismfractal.com/6)

What are the best ways to promote public goods creators and help citizens fairly reward impact? We play the Respect Game and RetroPGF Pitch Game to measure the output of outstanding buidlers in the Optimism Collective 🏟️ 🔴 ✨

![[https://youtu.be/I0Y-j1nEGQA](https://youtu.be/I0Y-j1nEGQA)](Public%20Goods%20Games%20a30eee3f0d1d4becaaca9ac7ca191e4b/retropgf_pitches_2_thumbnail_draft.png)

[https://youtu.be/I0Y-j1nEGQA](https://youtu.be/I0Y-j1nEGQA)

### RetroPitches 2

How can public goods games grow Optimism? In the second RetroPitch event we give a spotlight for RetroPGF applicants and participants rank the most helpful, exciting, and fun pitches  🌱 🔴 🏟️

![[https://optimismfractal.com/5](https://optimismfractal.com/5)](../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Optimystics%20Videos%204aa0cc0fe82f46fd8fb6a8548b7a5732/optimism_fractal_5_thumbnail_final.png)

[https://optimismfractal.com/5](https://optimismfractal.com/5)

### [**OF 5: Respect Games and RetroPitches!**](https://optimismfractal.com/5)

How can consensus games create profound benefits for all? We set the stage at Optimism Fractal for a joyful Respect Game and the first RetroPGF Pitch Game to amplify the power of public goods creators ⚡️🌞 🔴