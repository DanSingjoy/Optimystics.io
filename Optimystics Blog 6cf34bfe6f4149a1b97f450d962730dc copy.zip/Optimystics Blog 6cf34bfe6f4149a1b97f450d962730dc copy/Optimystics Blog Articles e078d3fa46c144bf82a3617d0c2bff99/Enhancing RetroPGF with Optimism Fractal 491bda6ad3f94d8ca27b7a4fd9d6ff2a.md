# Enhancing RetroPGF with Optimism Fractal

Displays on Pages:: RetroPGF, citizens' house, contribution measurement, governance, impact evaluation
AI summary: This document discusses the integration of Optimism Fractal into RetroPGF to enhance its functionality and improve various governance-related metrics. It aims to provide insights into contribution measurement and impact evaluation within the context of citizens' engagement.
AI summary 1: In this blog post, we explore the innovative integration of Optimism Fractal into the RetroPGF framework. This enhancement aims to improve the functionalities and effectiveness of RetroPGF, a project focused on participatory governance and impact evaluation. We will delve into the key features of this integration, its implications for citizens' engagement, and how it can transform the measurement of contributions within various governance contexts. Join us as we unpack the potential benefits and applications of this exciting development.
Published?: No

![enhancing retropgf with optimism fractal no  text.png](Enhancing%20RetroPGF%20with%20Optimism%20Fractal%20491bda6ad3f94d8ca27b7a4fd9d6ff2a/enhancing_retropgf_with_optimism_fractal_no__text.png)

RetroPGF is a groundbreaking mechanism to reward public goods creators. [The idea to reward based on past impact instead of future promises makes sense for a lot of reasons](https://medium.com/ethereum-optimism/retroactive-public-goods-funding-33c9b7d00f0c). However, there's one issue that keeps popping up in discussions with RetroPGF that we don't believe is solved yet.

I'll simply quote an [article](https://optimism.mirror.xyz/7v1DehEY3dpRcYFhqWrVNc9Qj94H2L976LKlWH1FX-8) from the Optimism Foundation about learnings from RetroPGF Round 2 to introduce the problem:

> The most consistent feedback from badgeholders during the evaluation process was around the overwhelming quantity of projects to review.

“Smooth experience, but way too many projects.”

 “...this is really about it being unmanageable for badgeholders.”

In this round, 195 projects were eligible for voting. In comparison, Round 1 of RetroPGF had 76 eligible projects.
> 

So the amount of projects to review for badgeholders was a problem in round 2 with 195 projects eligible for voting. Now that season 3 has 644 projects eligible for voting ([source](https://retrolist.app/)), it is fair to expect that the situation is not getting any better. While round 3 introduces some [changes](https://gov.optimism.io/t/retropgf-3-round-design/6802) that help with the review process and how applications are presented, these changes don’t address the issue at the fundamental level. Unfortunately, this is a situation where RetroPGF is a victim of its own success: the more successful it becomes at public goods funding, the more applications it will attract and the more burden it will have to put on the badgeholders.

[Optimism Fractal](https://optimismfractal.com/) is a community dedicated to fostering collaboration and awarding public good creators on Optimism. Since the initial conception of Optimism Fractal, we saw huge potential for synergy with RetroPGF. Now the picture is slowly becoming clearer about how Optimism Fractal can help RetroPGF.

Optimism Fractal can relieve a large amount of the burden from badgeholders by incentivizing a decentralized community effort to figure out the value of public good contributions. All that is needed is a simple weekly meeting which would produce consensus among community members as output. And this kind of meeting is already at the core of Optimism Fractal.

## How Optimism Fractal works

At the core of Optimism Fractal is a weekly meeting where we play something we call the Respect Game, which works as follows.

First, all the meeting participants are distributed into groups of 3-6 people. In each group, participants take turns to introduce their work, explain how it relates to Optimism, and say what they did in the past week that helped the Optimism Collective. Each participant can take up to 4 minutes to do this. The players then try to reach consensus on who did the most to help Optimism in the past week, then who helped the second most, the third most, and so forth. The goal of the game is to determine the relative value of each contribution. Once the group reaches consensus on the ranking of contributions they have to signal it onchain. If at least 2/3rds of group participants signal the same ranking then a non-transferable token called “Respect” is distributed. The biggest contributor in the group gets the most Respect and all other contributors receive different amounts based on the ranking of their contribution.

This is the essence of the Optimism Fractal and it takes only about an hour per week. Now how can this integrate with RetroPGF?

## How Optimism Fractal can help RetroPGF

The idea behind the Respect Game should be clearer by now: to produce a distribution of Respect tokens that represent the opinion of the community on the individual contributors and their projects. This can be taken as a signal by systems like RetroPGF in order to help make informed decisions regarding who to reward.

Now when it comes to details, there are many ways for Optimism Fractal and RetroPGF to work together. Ultimately it will be up to the Optimism Collective and Optimism Fractal to determine that and at this point, it would be premature to prescribe one particular way. Here we will present just a couple of ways in which RetroPGF could make use of Optimism Fractal in order to illustrate the available potential and why it is worth it.

### Evidence of work being valued by the community

The most simple and least impactful way for Optimism Fractal and RetroPGF to integrate would be for Respect tokens to be used as evidence submitted by the applicants that their work is seen as valuable by the community. Badgeholders could use it as additional information that helps them make their voting decisions. Additionally, [Lists](https://gov.optimism.io/t/retropgf-3-round-design/6802#lists-scaling-the-evaluation-of-projects-3) could be created that take into account Respect scores and help other badgeholders incorporate that information into their decision-making.

### Prioritization of projects based on Respect distribution

A step further would be for RetroPGF to order applications based on their Respect from Optimism Fractal, so that badge-holders would look at the most Respected projects first and maybe give them more attention in general.

Additionally, since badgeholders would prioritize applications based on consensus from the community, it might be justified to limit the number of applications reviewed by the effort available from the badgeholders rather than trying to cover all applications. Optimism Fractal is welcoming to all participants who pitch their contributions and help reach consensus, giving them all a chance to earn Respect. So all legitimate projects would have a good opportunity to boost up their applications for RetroPGF, which would make it fair even if not all applications are reviewed.

### Qualification of projects based on Respect distribution

A step even further could be to require at least some minimum amount of Respect in order for a project to become eligible for voting in RetroPGF.

Any serious project should have at least one person who is able to pitch it in an online meeting. So it should not be too much to ask for projects to participate in these Optimism Fractal meetings. Not to mention that it can benefit them as well by providing a platform to present their work.

An Optimism Fractal meeting is like a pitching session with the addition that participants also try to reach consensus on the rankings among each other. This effort spent on pitching and reaching consensus could be seen as a fee requested from projects that want to be eligible in RetroPGF. **In fact, since badgeholders are expected to spend their valuable time and effort in the review process and the amount of effort to be spent by badgeholders directly correlates with the amount of applications, one could argue that this kind of fee is exactly what RetroPGF currently lacks.** Applicants obviously can't be asked to pay a monetary fee - if they could they would not need RetroPGF. Therefore they should pay in some other way and helping build consensus on which projects deserve the most attention is one way to pay this cost.

### Place for badgeholders to learn about projects to nominate

RetroPGF could change its approach altogether and say that instead of making promises on behalf of badgeholders to review all the applications regardless of who submitted them, we simply say that only badgeholders can nominate projects. Optimism Fractal could then become a meeting point between badgeholders and any up-and-coming projects which are not yet known. So badgeholders (at least some of them, but ideally most of them) would be expected to participate in Optimism Fractal meetings where they would be able to join a different group every week and get to hear about different set of projects every week. Once they hear an interesting project, they would make a new nomination at which point other badgeholders could review and vote on it as well.

So in this model, all that we would ask of badgeholders is to participate in a 45-minute meeting every week where they would simply have their ears open for anything interesting while people present their projects. We think this is much more manageable for most than having to review hundreds of applications in text. This could also benefit badgeholders themselves since they would be able to present their own work as well. They would also get to see how others see the projects they are evaluating and be able to ask questions to project contributors directly.

Badgeholders participating in Optimism Fractal meetings is the only thing that is needed to jump-start this, because if they come then applicants will follow them for the opportunity to get seen by them.

## Decoupling recognition from financial rewards

The general idea can be summarized as such: Optimism Fractal recognizes (awards) public good contributors, while RetroPGF rewards them[¹](https://optimystics.io/enhancingretropgf#block-4f43a4a5158c4fecbe01f17231122ac6). Optimism Fractal ensures that noteworthy projects get the attention they deserve (and an onchain record of that recognition), while RetroPGF makes decisions about who should be compensated for their contributions and how much.

In order to fairly reward builders you first need to figure out which builders deserve your attention and this is a big problem that deserves a solution in its own right. This is where RetroPGF currently has the most problems. This is where Optimism Fractal can help.

## Conclusion

Above we presented just a few of ways in which Optimism Fractal can help RetroPGF manage the amount of projects to review. Ultimately it is up to Optimism community to decide the best way forward. Optimism Fractal has a governance structure that we believe is flexible enough to adapt its process according to the needs of Optimism community.

---

1. On the difference between rewards and awards: [https://www.grammar-monster.com/easily_confused/award_reward.htm](https://www.grammar-monster.com/easily_confused/award_reward.htm)

*Optimism Fractal provides a perfect place to collaborate with talented builders and earn awards for helping the Optimism Collective. You’re welcome to join our weekly [events](https://lu.ma/optimismfractal) on Thursdays at 17 UTC, watch our previous [episodes](https://optimystics.io/videos), and explore our [blog](http://optimystics.io/blog) to learn more about how Optimism Fractal can create profound benefits for the Optimism Collective.* 

*We encourage you to explore our articles and videos about the [Respect Game](https://optimystics.io/respectgame) to gain a deeper understanding of how Optimism Fractal can enhance RetroPGF. We build open source tools to help all communities enjoy the benefits of the Respect Game and grow with Optimism. You can learn about our tools [here](https://optimystics.io/tools). We’d appreciate your support in our RetroPGF Grant. Feel free to reach out with any comments in our discord or the [forum post](https://gov.optimism.io/t/enhancing-retropgf-with-optimism-fractal/7175). Thank you for reading!*

## Related Posts

[Untitled](Enhancing%20RetroPGF%20with%20Optimism%20Fractal%200336a2c82d094dd59fc21f13da792b38/Untitled%201ac3cfb8ea7c4380836ed9d082cb5bba.csv)