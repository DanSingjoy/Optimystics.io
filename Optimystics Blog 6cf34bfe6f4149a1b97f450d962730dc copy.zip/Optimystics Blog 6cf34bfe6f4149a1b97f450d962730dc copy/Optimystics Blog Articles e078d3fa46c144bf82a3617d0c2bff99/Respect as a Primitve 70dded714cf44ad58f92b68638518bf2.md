# Respect as a Primitve

AI summary: Respect is an elegant and composable primitive that can enhance the functionality of smart contracts on Optimism, providing a fair and fun way to distribute decision-making power throughout communities.
Published?: No

## What is Respect?

Respect is an elegant, composable, and highly useful primitive that can enhance the functionality of many other smart contracts on Optimism. Players can earn varying amounts of Respect by playing Respect Games in weekly meetings. For example, you can see how players can earn respect in Optimism Fractal meetings at [OptimismFractal.com/details](http://OptimismFractal.com/details).

All communities are faced with decisions about how to allocate resources and decision making power to maximize mutual benefit. Our social games in live meetings provides an optimal distribution of points/tokens that fairly distributed in a simple, credibly neutral, and fun way. You can learn more about respect in the Fractally [whitepaper](https://fractally.com/whitepaper/fractally_en.pdf)  (pages 9-18 and 22-25), the ƒractally [keynote video](https://youtu.be/cJclki0MnnI?si=N61iI9eVQRcw_x4s&t=136), and this [article](https://edencreators.com/tools#20c2ce9e90b24d3c88773f62d53bc7dd).

## Respect as a Primitive

We believe that the combination of Respect as a primitive and the social cohesion of fun weekly meetings provides the best way to distribute decision making power throughout communities at root level. 

By establishing a baseline of Respect during weekly meetings, many other composable smart contracts can become far more effective, fair, and democratically legitimate. This can include distribution of rewards on social media apps like [Farcaster](https://www.farcaster.xyz/) or assignment of Roles with coordination protocols like [Hats Protocol](https://www.hatsprotocol.xyz/) and [Roles & Reputations](https://app.charmverse.io/op-grants/page-23303127376120303) from ATX DAO. This can also enhance the functionality of many other apps/protocols like Attestation Station, Ethereum Attestation Service, Charmverse, and Snapshot. Each of these compositions can lead to more smart contracts on the OP mainnet. 

This powerful root primitive for coordination improves all the functionality of all dApps, so our social games contribute greatly to both the quantity and quality of smart contracts on Optimism. Our proposal to start Optimism Fractal and release the first iteration of EVM based fractal tools creates an immense opportunity for Optimism developers to build smart contracts on top of the Respect primitive.

- 
    
    **Will your project be composable with other projects on Optimism? If so, please explain:**
    
    Yes, Optimism Fractal will be highly composable with other projects on Optimism:
    
    - All game data is open and onchain for easy integration
    - Our reputation and contribution data could help inform grants distribution and public goods funding through composability with tools like RetroPGF
    - Unique identity verification collaborations with services like the Attestation Station improves integrity
    - New games and apps could be built on top of our core coordination primitives
    - Shared incentive systems could align wider Optimism communities
    - Relationships formed could enable collaborative opportunities across projects
    - The concept of respect points earned in social consensus games provides a powerful primitive for novel coordination mechanisms
    
    We aim for modular interoperable design that makes it easy to build on top of our cooperation stack and share data/incentives across Optimism.
    

![graphic-RespectEarned@4x.png](Respect%206357d339d30b425997f3da4dd6f75f32/graphic-RespectEarned4x.png)

- 
    
    Our technical deliverables in this proposal are limited because our developers want to use the time to gather feedback for future development most suited for Optimism and we are a relatively small team with limited resources. Funding from the Grants Council can enable us to have a highly successful first season that inspires EVM developers and helps grow our team with many more builders who can build smart contracts with a much wider scope
    
    our original answer about the composability of respect in our proposal in the toggle below: