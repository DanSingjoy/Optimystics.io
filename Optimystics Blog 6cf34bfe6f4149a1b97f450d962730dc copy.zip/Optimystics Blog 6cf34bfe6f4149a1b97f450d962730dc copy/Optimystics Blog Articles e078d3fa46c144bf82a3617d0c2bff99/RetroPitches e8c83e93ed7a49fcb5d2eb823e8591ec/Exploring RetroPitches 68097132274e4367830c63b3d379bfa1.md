# Exploring RetroPitches

![retropgf pitches draft image2.png](../RetroPitches%206ad7444631c046dcb909d7752a907f92/retropgf_pitches_draft_image2.png)

## Welcome

This article provides an exploration of the history and future of RetroPitches, a consensus game where participants coopete to promote their RetroPGF projects and grow Optimism. You can see [Optimystics.io/retropitches](http://Optimystics.io/retropitches) for the shorter announcement post and the most up to date details. Enjoy!

![edencreators_microphone_stand._podium_spotlight_engaging_and_fu_76f847c2-cc12-49f8-8d51-3c3024929fdf.png](Exploring%20RetroPitches%2068097132274e4367830c63b3d379bfa1/edencreators_microphone_stand._podium_spotlight_engaging_and_fu_76f847c2-cc12-49f8-8d51-3c3024929fdf.png)

## Overview

The RetroPitch games give public goods creators a great opportunity to promote their RetroPGF grant and provide citizens with an easy way to learn about exciting projects in the Optimism Collective. RetroPitches will feature fun, friendly competitions where optimists pitch their grants then rank each other’s pitches to shine a light on public goods!

In the RetroPitch games participants are be challenged to pitch and judge grants in a variety of categories, such as the most positive impact for the Collective and the most amusing presentations. The events take place on zoom calls and videos are produced to create a spectacular new kind of gameshow focused on promoting public goods creators and providing educational resources to inspire the world with Optimism. Each RetroPGF project owner will have up to five minutes on stage to promote their work and all qualified attendees can play as judges to help determine the scores for each player.  

The videos are shared across Web3 social networks to raise awareness for public goods on Optimism and the scores from each game may be used to help badgeholders allocate funding in RetroPGF. You can watch videos of previous pitch games and learn more about this awesome public goods game at [Optimystics.io/RetroPitches](http://Optimystics.io/retropitches).

- 
    
    # Originally Synced Content from [Create Announcement Post for RetroPGF Pitch Games](https://www.notion.so/Create-Announcement-Post-for-RetroPGF-Pitch-Games-f13b949323b841a5867905643ad36ad4?pvs=21)
    
    This content was synced for the first week of writing, then i unsynced it so i can sync individual parts on different pages. I probably won’t use the following since the most recent writing is happening on [Create Announcement Post for RetroPGF Pitch Games](https://www.notion.so/Create-Announcement-Post-for-RetroPGF-Pitch-Games-f13b949323b841a5867905643ad36ad4?pvs=21) or the other pages
    
    ### Introducing RetroPGF Pitch Games!
    
    Maybe retitle or break into multiple posts?
    
    Introducing RetroPGF Pitches and the Public Goods Games!
    
    Introducing RetroPitches and the Public Goods Games!
    
    Hey optimists,
    
    Today we ask three important questions and invite you to join joyful competitions to optimize the growth of Optimism!
    
    1. How can public goods creators stand out from the crowd and be recognized for their work?
    
    1. How can citizens fairly reward everyone creating a positive impact to the Optimism Collective?
    
    1. What is the best way to share fun, inspiring experiences that help everyone enjoy the benefits of Optimism?
    
    The answer dear friends is Public Goods Games. Imagine epic tournaments where talented creators compete, collaborate, and coordinate to help the Optimism Collective. Like the Olympic Games, but for creating public goods. 
    
    Imagine groups of builders, artists, and entrepreneurs coming together from around the world to share their work and award public goods creators who grow Optimism. A community gathering of optimistic leaders playing innovative consensus games to spread the [Optimistic Vision](https://www.optimism.io/vision), summon Ether’s Pheonix, and create a better future for all.
    
    We’re pleased to announce the first RetroPGF Pitch Games, aka RetroPitches! 
    
    ![retropgf pitches draft image2.png](Exploring%20RetroPitches%2068097132274e4367830c63b3d379bfa1/retropgf_pitches_draft_image2.png)
    
    - 
        
        RetroPitches will feature fun, friendly competitions where optimists pitch their grants then rank each other’s pitches to shine a light on public goods. The RetroPitch games will give public goods creators a great opportunity to promote their RetroPGF grant and provide citizens with an easy way to learn about exciting projects in the Optimism Collective!
        
    
    The RetroPitch games will give public goods creators a great opportunity to promote their RetroPGF grant and provide citizens with an easy way to learn about exciting projects in the Optimism Collective. RetroPitches will feature fun, friendly competitions where optimists pitch their grants then rank each other’s pitches to shine a light on public goods!
    
    Over the next three weeks participants will be challenged to pitch and judge grants in a variety of categories, such as the most positive impact for the Collective and the most amusing presentations. The events will take place on zoom calls and videos produced to create a spectacular new kind of gameshow focused on promoting public goods creators and providing educational resources to inspire the world with Optimism. 
    
    Each RetroPGF project owner will have up to five minutes on stage to promote their work and all qualified attendees can play as judges to help determine the scores for each player. All participants will receive commemorative awards and the winners will earn special prizes, including the first onchain art ever minted by Optimystics. The videos will be shared across Web3 social networks to raise awareness for public goods on Optimism and the scores from each game may be used to help badgeholders allocate funding in RetroPGF. 
    
    Everyone is welcome to join the first RetroPitch games for the next three Mondays at 18 UTC at Optimism Fractal. If you’d like to pitch your grant in any of the first three RetroPitch games, please [sign up here](https://www.notion.so/create-a-typeform-258eb6b178ea4efeae4119f09f3cd382?pvs=21) to reserve your spot. Spots are limited to five grantees per game, so act fast to ensure that you’ll be able to pitch. You can watch videos of previous pitch games and learn more about this awesome public goods game at [Optimystics.io/RetroPitches](http://Optimystics.io/retropitches).
    
    - [ ]  Consider adding a page to the sign up form saying that I consent to be on video or that i’m cool with it being recorded on video and shared on social media
    - [ ]  Maybe add question if they’re willing to be on camera
        - Maybe we should filter according to who is willing to be on camera
        - It would also be cool if they’d like to share their screen, though
    
    - 
        
        
        - [ ]  add these notes to [RetroPitches](../RetroPitches%20e8c83e93ed7a49fcb5d2eb823e8591ec.md) article
        
          All participants will receive the first ever collectible art awards/NFTs from the Optimystics 
        
        (as judges) (for their favorite/best pitches) to help determine the most helpful and amusing pitches
        
        The RetroPitch games will occur on the November 13th, November 20th, November 27th, and December 4th.
        
        By  the experience with great awards and producing the video to create a new kind gameshow, RetroPitches will also provide amazing educational resources to inspire the world with Optimism. 
        
         fellow optimists at the meeting rank  share the best pitches and 
        
        Over the next three weeks, public goods creators will coopete to win the hearts of peers and share most impactful, most amusing, largest Gap in the fairness ratio, and more challenges
        
        RetroPitches will bring out the best in public goods creators by featuring a friendly competition where RetroPGF applicants compete to pitch their work and win awards by sharing impactful and amusing pitches. including a fun competitive aspect to win the top awards and an awesome new kind of gameshow will be produced of the event to help provide educational resources that inspire the world with Optimism.
        
    
    ![retropgf pitches draft image5.png](Exploring%20RetroPitches%2068097132274e4367830c63b3d379bfa1/retropgf_pitches_draft_image5.png)
    
    - [ ]  Consider - I think it might be best to saving this part of the post for a second post in the next week
    
    - We can share a shorter versio
    
    - 
        
        
        ## Optimism Fractal and the Respect Game
        
        We will play the Respect Game an hour before RetroPitches
        
        Before playing RetroPitches, we will play the Respect Game
        
        We’ve been developing the Respect game for years with hundreds of talented builders and we’re thrilled to share it with you. Everyone is welcome to join the 
        
        The Respect Game is at the heart of Optimism Fractal. 
        
        At the heart of Optimism Fractal is a public goods game called the Respect Game. We’ve been developing the Respect game for years with hundreds of talented builders and we’re thrilled to share it with you. Everyone is welcome to join the 
        
        The Optimystics have been pioneering consensus games with hundreds of talented builders in another Web3 ecosystem for years and we started Optimism Fractal last month to help optimists perform fruits with Optimism./
        
        We started Optimism Fractal last month to consensus games to supercharge  enable the future of creative collaboration and provide a stage for the amazing innovators in the Optimism Collective.
        
        create profound benefits for the Optimism Collective
        
        Optimystics specialize in consensus games that empower communities and we started Optimism Fractal last month to create profound benefits for the Optimism Collective
        
        The RetroPitch games are hosted at Optimism Fractal, a community with fun weekly events dedicated to fostering collaboration and awarding public goods creators on Optimism. The events are hosted by Optimystics, a team of gardeners growing Optimism with 
        
        It is an innovative consensus game that we’ve been developing for years with hundreds of talented builders and we’re thrilled to share it with you.
        
        Enable the future of collaboration and spotlight public goods creators in the Optimism Collective
        
    
    The RetroPitch games are hosted by Optimystics at Optimism Fractal, a community with fun weekly events dedicated to fostering collaboration and awarding public goods creators on Optimism. In addition to RetroPitches, we also play another wonderful public goods game at Optimism Fractal meetings!
    
    At the heart of Optimism Fractal is the Respect Game. We’ve been pioneering this innovative consensus game for years with hundreds of talented Web3 builders and we started Optimism Fractal last month to grow Optimism with the profound benefits of the Respect Game. We play the Respect Game at Optimism Fractal on Mondays at 17 UTC (which is an hour before the RetroPitch games) and everyone is welcome to join.
    
    The Respect Game provides a perfect place to collaborate with visionary optimists and earn respect for helping the Optimism Collective. In this game, each player gets to introduce themselves and share their work with a friendly group of optimists. After each player takes their turn, they try to reach consensus in ranking their contributions to Optimism and then they post the rankings to the OP Mainnet with our intuitive web app. All players who reach consensus earn Respect, a soulbound token that can give you mystical powers and help badgeholders understand your impact in future seasons of RetroPGF. 
    
    You can join our weekly [events](https://lu.ma/optimismfractal), watch our previous [episodes](http://optimismfractal.com/media), and explore our [blog](http://optimystics.io/blog) to learn more about how the Optimism Fractal Respect Game can create profound benefits for the Optimism Collective. While RetroPitches has a limited amount of spots for public goods creators to pitch their grants, we can accommodate any amount of players in the Respect Game due to it’s fractal nature where we split up into breakout groups. You can find tutorials and learn more about the wonders of the this magical community  game at [Optimystics.io/RespectGame](http://Optimystics.io/RespectGame).
    
    - 
        - [ ]  add these notes to [Respect Game](../../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Games%20a87953a98246402da3e171f43811bfda/Fractal%20Games%20958dadb96fc940c1a6789e663d36a2c5/Respect%20Game%2097fc60fcf6944c3095df07a64e86b481.md) article
        
        bring out the best 
        
        Everyone is welcome to join the event at 17 UTC to play the Respect Game for an hour before RetroPitches. The Respect Game is at the core of Optimism Fractal. We have been refining this game for years with hundreds of talented builders and provides a perfect environment to collaborate with brilliant innovators in the Optimism Collective.
        
        While the RetroPtiches 
        
        We are hosting 
        
        The RetroPitch games will be hosted by Optimystics at Optimism Fractal, a community with fun weekly events dedicated to fostering collaboration, awarding public goods creators, and growing Optimism!
        
        We created Optimism Fractal a month ago
        
        Our team specializes in innovative consensus games that amplify the power of public goods creators and we created Optimism Fractal to grow Optimism 
        
        Everyone is welcome to join Optimism Fractal meetings an hour before the RetroPitch games to play the Respect Game
        
        Everyone is welcome to join the Respect Game an hour before RetroPitches and experience the benefits of this game for yourself.
        
        The RetroPitch games will be hosted at Optimism Fractal, a community with fun weekly events dedicated to fostering collaboration, awarding public goods creators, and growing Optimism!
        
        profound benefits for the Optimism Collective
        
        Our Optimystics team specializes in innovative consensus games that empower public goods creators and we created Optimism Fractal to grow Optimism.
        
        Optimystics team 
        
        Our team specializes in innovative consensus games that amplify the power of public goods creators in the Optimism Collective. 
        
        Everyone is welcome to join Optimism Fractal meetings on Mondays at 17 UTC to play the Respect Game and experience it for yourself. The Respect Game will be played an hour before the RetroPitches game for the next three weeks. 
        
        The RetroPitch games will be hosted at Optimism Fractal, a community with fun weekly events dedicated to fostering collaboration and awarding public goods creators on Optimism. 
        
        Optimism Fractal is based around the Respect Game
        
    - 
        
        
        - [ ]  add these notes to [Respect Game](../../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Games%20a87953a98246402da3e171f43811bfda/Fractal%20Games%20958dadb96fc940c1a6789e663d36a2c5/Respect%20Game%2097fc60fcf6944c3095df07a64e86b481.md) article
        
         and give you special powers in future Optimism 
        
        In addition to the RetroPGF Pitch Game, you’re welcome to join Optimism Fractal at 17 UTC to play the Respect Game. This fun consensus game provides a perfect opportunity to collaborate with fellow optimists and earn Respect for helping the Optimism Collective. Respect is a soulbound token on the OP Mainnet that can give you special powers in the Optimism Fractal games and help badgeholders better understand your impact on future seasons of RetroPGF. It provides a powerful and composable primitive
        
         on the OP Mainnet with our fractal app. our OP Fractal tools.  
        
        then then cooperate to rank their recent contributions to Optimism.
        
        Players will use our Fractalgram app with the tools 
        
        reach consensus on the rankings of contributions.
        
        tools built on the OP Mainnet 
        
        Everyone is welcome to join the Respect Game an hour before RetroPitches and experience it’s many wonders for yourself. In addition to providing the perfect place to collaborate with fellow optimists, it also 
        
        use an app we created called Fractalgram to post the scores on the OP mainnet
        
        Uses tools on the OP Mainnet 
        
         It provides the perfect place to network and collaborate with brilliant innovators in the Optimism ecosystem.
        
        Our weekly meetings provide a perfect place to collaborate with talented builders, creators, and innovators in the Optimism Collective.
        
        Everyone is welcome to join Optimism Fractal at 17 UTC (an hour before the RetroPitches game) to be 
        
        Optimism Fractal is pioneering state of the art consensus games and cooperation mechanisms to grow Optimism while sharing amazing experiences. 
        
        Everyone is welcome to join Optimism Fractal meetings at 17 UTC to play the Respect Game. 
        
        We welcome you
        
        Everyone is welcome  
        
        The Respect Game provides a perfect place to collaborate with visionary optimists and earn respect for helping the Optimism Collective.
        
        next level
        
        At the heart of Optimism Fractal is a wonderful public goods game called the Respect Game. We’ve been pioneering the Respect Game for years with hundreds of Web3 builders and we started Optimism Fractal last month to unleash its profound benefits to the Optimism Collective.
        
        Optimystics specialize in public goods games that empower communities and we started Optimism Fractal last month to create profound benefits for the Optimism Collective. At the core of Optimism Fractal is an innovative consensus game that we’ve been developing for years with hundreds of talented builders. It’s called the Respect Game and we play it in Optimism Fractal meetings on Mondays at 17 UTC. 
        
        You can learn more about the Respect Game 
        
        Due to the fractal nature of the Respect Game, 
        
        the fractal nature of the Respect Game
        
        breakout rooms
        
        You can watch a tutorial video and learn the benefits of this innovative consensus game at [Optimystics.io/respectgame](http://Optimystics.io/RespectGame). To learn more about Optimism Fractal, you can watch our first three episodes at [OptimismFractal.com/media](http://optimismfractal.com/media) and learn more about our roots in this [article](https://optimystics.io/blog/the-roots-of-optimism-fractal). You can [register](https://lu.ma/optimismfractal) to join our weekly events, join our discord, and follow us on Farcaster for updates.
        
        You’re welcome to join Optimism Fractal events [here](https://lu.ma/optimismfractal), watch our previous [episodes](http://optimismfractal.com/media), and explore our [blog](http://optimystics.io/blog) to learn more about how Optimism Fractal can create profound benefits for the Optimism Collective. We’d greatly appreciate your support in our [RetroPGF Grant](https://vote.optimism.io/retropgf/3/application/0xfd664805607a6c8e26bed11d372f794ac465462bc171a4b6992b84143876cc3a) to help us grow Optimism. 
        
    
    - [ ]  Consider adding Respect Game image here
        - Maybe it the respect game hard should be somewhere in the image below
    
    ![optimism fractal mondays at 17 utc 1.png](Exploring%20RetroPitches%2068097132274e4367830c63b3d379bfa1/optimism_fractal_mondays_at_17_utc_1.png)
    
    Feel free to reach out with any questions or comments below or in our [discord](https://discord.gg/avqDXdgz).
    
    support the amazing public goods creators in our community
    
    “This kind of pitch session can provide us with opportunities to quickly learn about each other’s work and support the amazing public goods creators in our community. 
    
    We understand that there are many important exciting things to do. The full event with both games is scheduled to last about 90 minutes and you are welcome to join for just a part of the event or one of the games.
    
    We also produce and promote videos from both public goods games to help raise awareness for public goods creators on Optimism. 
    
    Full filled event. Introductory presentation starting at 17 UTC, Respect Game starts at 17:10 UTC, and RetroPitches game starts at 18 UTC. 
    
    Feel free to join just one of the games or both. Anyone can join the Optimism Fractal Respect Game, since breakout rooms. If you’d like to participate in RetroPGF Pitch Games, please remember to [sign up here](https://www.notion.so/create-a-typeform-258eb6b178ea4efeae4119f09f3cd382?pvs=21) to reserve your spot. Spaces are limited, so act now to make sure that you’ll have the chance to promote your grant in the first ever RetroPitch games. 
    
    The combination of RetroPitches and the Respect Game provide a powerful, playful way to grow the Optimism Collective. In alignment with the core principles of Web3, the Respect Game and RetroPitches are consensus games. Humanity and all of our communities needs better ways to coordinate to navigate a rapidly changing future and create mutual benefit. Consensus games with Optimism offer a new paradigm to enable joyful and effective rewarding for the Optimism Collective.
    
    Whether you’re a public goods creator who wants to spread the word about your RetroPGF grant, a citizen trying to fairly reward positive impact, or just someone who’s interested in learning more about Optimism. These games help achieve the four intents of the Optimism Collective: Improving governance and technical decentralization with fractal democracy, provides  provide a wonderful way for consumers to joyfully interact with the network, consumer enjoyment , and eventually OP Stack.
    
    RetroPitches, Respect Games, and Optimism Fractal are brought to you by Optimystics. You can learn more about our work at [Optimystics.io](http://Optimystics.io) and support our [RetroPGF grant](https://vote.optimism.io/retropgf/3/application/0xfd664805607a6c8e26bed11d372f794ac465462bc171a4b6992b84143876cc3a) to help us grow Optimism. (As relatively new community members, we really appreciate your support)
    
    We look forward to meeting you and can’t wait to hear all the amazing RetroPitches!
    
    Embed intro tweet from Optimystics 
    
    ![edencreators_microphone_stand._podium_spotlight_engaging_and_fu_76f847c2-cc12-49f8-8d51-3c3024929fdf.png](Exploring%20RetroPitches%2068097132274e4367830c63b3d379bfa1/edencreators_microphone_stand._podium_spotlight_engaging_and_fu_76f847c2-cc12-49f8-8d51-3c3024929fdf%201.png)
    
    retropitches can also include pitches for grants on other public goods platforms such as gitcoin and giveth, but priority will be given to public goods creators with grants in RetroPGF round 3.
    
    ![retropgf pitches draft image.png](Exploring%20RetroPitches%2068097132274e4367830c63b3d379bfa1/retropgf_pitches_draft_image.png)
    
    ![retropgf pitches draft image6.png](Exploring%20RetroPitches%2068097132274e4367830c63b3d379bfa1/retropgf_pitches_draft_image6.png)
    
    ## Next Steps
    
    - [ ]  Review and refine the messaging above
    
    - [ ]  Review the notes below and see which ones should be included here or moved to [RetroPitches](../RetroPitches%20e8c83e93ed7a49fcb5d2eb823e8591ec.md) or [Respect Game](../../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Games%20a87953a98246402da3e171f43811bfda/Fractal%20Games%20958dadb96fc940c1a6789e663d36a2c5/Respect%20Game%2097fc60fcf6944c3095df07a64e86b481.md) or elsewhere
    
    - [ ]  Refine articles for [RetroPitches](../RetroPitches%20e8c83e93ed7a49fcb5d2eb823e8591ec.md) and [Respect Game](../../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Games%20a87953a98246402da3e171f43811bfda/Fractal%20Games%20958dadb96fc940c1a6789e663d36a2c5/Respect%20Game%2097fc60fcf6944c3095df07a64e86b481.md)
    
    - [ ]  consider best strategy to share quickly without spending too much time on blog articles. How much time will it take to get these blog articles ready?
        - I think i could get them ready in like an hour, which seems worth it.
    
    - Also producing content specifically for Respect Game and Optimism Fractal
    
    - 90 minutes in same meeting
    
    - Same purpose or different purpose
    
    - Feel free to join
    
    - Tadas can’t join on the 20th of November
    
    # Notes
    
    In alignment with the foundational principles of Web3, the Respect Game and RetroPitches are consensus games. This is a new type of game . Humanity and all of our communities needs better ways to coordinate to navigate a rapidly changing future and create mutual benefit. Consensus games 
    
    As Bitcoin pioneered proof of work and Ethereum merged to proof of stake consensus algorithms, we have a different kind of consensus algorithm. It’s for people and fun. Consensus games.
    
    picture
    
    Imagine that the Optimism Collective hosted epic games where talented builders, creators, and innovators compete and collaborate to create public goods and grow Optimism. Like the Olympic Games, but for public goods.
    
    Gameshow
    
    Improving governance and technical decentralization with fractal democracy, provides  provide a wonderful way for consumers to joyfully interact with the network, consumer enjoyment , and eventually OP Stack 
    
    Review the four intents and Write how respect game helps with each 
    
    - 
        
        
        Optimism Fractal is the flagship product of the Optimystics. We’ve been building and refining the respect game for years with hundreds of builders and are excited to empower optimism 
        
        Everyone is welcome to join Optimism Fractal meetings on Mondays at 17 UTC 
        
        Optimism Fractal. 
        
        If you’re not yet familiar with Optimism Fractal, 
        
        You can think of the Public Goods Games like the Olympic Games, but for public goods. 
        
        The Public Goods Games are like the Olympic Games, but focused on creating public goods for the benefit of Optimism and humanity as a whole. 
        
         will be held 
        
        `
        
        ### Welcome to RetroPGF Pitch Games!
        
        ### Introducing RetroPitches!
        
        The videos will provide an easy way for badgeholders and anyone else to view your work 
        
    
    “This kind of pitch session can provide us with opportunities to quickly learn about each other’s work and support the amazing public goods creators in our community. This can also be a great way to promote Eden Fractal with the unique benefits of cagendas consensus games for collaboration, networking, and video creation.`
    
    Five minutes per pitch 
    
    videos will be produced to help you raise awareness for your project and grow optimism 
    
    Feel free to share your screen to show us your work 
    
    Each pitch will be ranked according to the helpfulness of your project and the amusement of your presentation, (so you can get extra rewards by) delight the judges and making it more fun
    
    Each participant will have to opportunity to both share their work and be a judge for other projects (so you can play both roles and help determine the most helpful public goods for the optimism collective 
    
    - [ ]  review how we wrote it in pitches and speech’s games
    - [ ]  Consider porting over the pitches and speeches article to Optimystics games page and linking it here
    - [ ]  Test to see if there’s any way we can create a list. If six then consider creating list(s) from optimism fractal and also including the fact that people can get on lists from participating here
    - [ ]  Create medals and trophies art. Perhaps with sunny and ethers Pheonix and impact=profit and
    
    In addition to the RetroPGF Pitch Game at 18 UTC, you’re welcome to join us for the Respect Game at 17 UTC. This fun, innovative consensus game provides a perfect opportunity to meet/collaborate with fellow optimists and earn Respect for helping the Optimism Collective. Respect is a nontransferrable token that can (give you special powers in the Optimism (Fractal) community) and help badgeholders better understand your impact on future seasons of RetroPGF.
    
    you can earn by participating in optimism fracfal meetings each week 
    
    onchain awarded to public goods creators
    
    We invite you to join both portions of the event to raise awareness for your public goods and __, though you’re welcome to just join either part
    
    Will be awarded with respect and beautiful art minted on the OP Mainnet 
    
    All participants in the RetroPGF Pitch Game will earn beautiful art minted on the OP Mainnet and the (top three) winners of each week will earn special awards. (Trophies or medals) (Those can also help provide a signal for badge holders and wider community that you’re public goods should be supported)
    
    All participants in the Optimism Fractal 
    
    These games will form the first ever Public Goods Games (aka RetroPGG) at Optimism Fractal. 
    
    We are committed to growing Optimism with fun consensus games that foster collaboration and award public goods creators in the Collective. 
    
    Stay tuned for more announcements of other fun games that can help promote your work and spread the word about Optimism (pairwise game etc)
    
    For more about Optimism Fractal, explore [OptimismFrActal.com](http://OptimismFractal.com) and [Optimystics.io](http://Optimystics.io). Discord Luma twitter . First few episodes video at media page and intro in first episode 
    
    ### Introducing RetroPGF Pitch Games!
    
    The answer, our friends... is Public Goods Games. We’re pleased to announce the first RetroPGF Pitch Games, aka RetroPitches! 
    
    Today we pose three questions and invite you to a playful ly powerful opportunity to optimize the growth of Optimism! 
    
    We’re excited to invite you to Optimism Fractal RetroPGG
    
    The Public Goods Games at Optimism Fractal, presented by Optimystics
    
    RPGG
    
    We’ll play two innovative consensus games : respect game and pitches games 
    
    Agenda 
    
    Welcoming presentation 17 utc 
    
    Respect game 17:15 UTC
    
    Pitches game 18 utc 
    
    The meeting is planned to last for 90 minutes 
    
    After an introductory presentation about Optimism, Optimism Fractal, and the items on the agenda, we’ll jump into the respect game. In this game players will be randomly grouped into breakout rooms with up to five other players and each given the opportunity to share their recent work for the collective. Players will rank each the positive impact of each others work to help Optimism and each player who reached consensus will receive respect. Varying amounts of respect. 2/3rd must agree . You can join each week to earn more respect and build deep connections with amazing optimists.This respect score forms a composable, Sybil resistant reputation score be used by badge holders to assess impact in future seasons of retropgf.
    
    After the respect game, we’ll play the pitches game. Each player will be given up to three minutes to pitch their RetroPGF grant or othe public goods that they’re creating for Optimism. This can help you spread awareness of your retropgf grant among badge holders in attendance or watching the recorded video. Each player will vote to determine their favorite pitches and the winner will be awarded with respect and or nfts 
    
    Ask Tadas - can we post consensus results for pitch games with the same software without confusing it with the respect game scores
    
    The respect score can be used in the future for retropgf lists , voting power in future games , and special abilities or power with the optimism collective and optimism fractal communities
    
    Both of these events provide
    
    You are welcome to join us for the full event or  hop in for just one of the games
    
    Should pitches game have a different name? 
    
    How about what you earn ? Do you earn respect or pitches collectibles or trophies? Of medals? 
    
    We believe in making public goods fun and greater data and better experience , promoting our work and growing optimsim together. Join us for a 
    
    Maybe it should just be optimism fractal pgg rather than retropgg 
    
    Public Goods Games 
    
    Optimism FractalPGG
    
    This is a great opportunity to prompt and share your work 
    
    Come in and share your pitch 
    
    Let everyone know what you’re doing 
    
    Share your knowledge and experiences
    
    RetroPitches 
    
    Both of these games are designed to 
    
    Two innovative consensus games designed to help project owners promote their work and help badge holders understand their impact to the Optimism Collective 
    
    Come Toot your horn and let’s hear how you have helped the Optimism Collective 
    
    Stand out amongst all 628 projects
    
    Watch yo understand 
    
    Share innovators show what you’re doing, showcase your work
    
    A video will be recorded and produced to help promoting 
    
    Optimism Public goods games 
    
    Optimism Public Goods Games at Optimism Fractal
    
    RetroGames
    
    Introducing Optimism RetroPGF Pitch Games!
    
    These pitch games will be hosted during the second half of optimism fractal events 
    
    18 Utc 
    
    All participants are wleocme to join the respect game for the previous hour to 
    
    We’d like to invite all innovators to RetroPGF eligible projects
    
    Come and share 
    
    - [ ]  Update luma link to include additional time?
        - I think it still makes sense to just keep the same luma link
    
    Make a different post for the RetroPGF channels focused on RetroPGF pitch games . Then respect game is mentioned but the pitch game is front and center in focus 
    
    Introducing The RetroPGF Games
    
    Introducing the Optimism RetroPGF Pitch Games
    
    Introducing the Optimism RetroPGF Games
    
    We’d like to help your promote your project
    
    We’re providing you with the opportunity help share your project and promote your public goods for the optimism ecosystem  
    
    We’d like to help you promote your work
    
    Consider reaching out to proof of integrity and offering to collaborate 
    
    Pitches is a social coordination game where players compete to share the best pitches about public goods and their peers rank each others’ pitches! 
    
    where public goods creators had opportunities to promote their grants. These pitch sessions can be a great place to promote your work, learn about exciting projects, and network with other public goods creators!
    
    One of our favorite parts of pitch sessions is how they can inspire cool shows. these pitch sessions provide natural opportunities for communities to collaboratively create media with the power of [DAMS](https://www.notion.so/DAMS-ee6c42b9544b433b8fd1dcd9571ea73a?pvs=21).
    
    pitches and speeches game links
    
    All participants will receive commemorative awards and the winners can earn special prizes, including the first onchain art ever minted by Optimystics.
    
    Everyone is welcome to join the first RetroPitch games at Optimism Fractal. If you’d like to pitch your grant in any of the first RetroPitch games, please [sign up here](https://www.notion.so/create-a-typeform-258eb6b178ea4efeae4119f09f3cd382?pvs=21) to reserve your spot. Spots are limited to five grantees per game, so act fast to ensure that you’ll be able to pitch. 
    

![retropgf pitches draft image5.png](Exploring%20RetroPitches%2068097132274e4367830c63b3d379bfa1/retropgf_pitches_draft_image5.png)

# Exploring RetroPitches

## RetroPitches Season 1

### Videos

RetroPitch games are recorded and shared on social media to further raise awareness for public goods creators. You can watch episodes of RetroPitches below and watch full episodes of Optimism Fractal with more public goods games on our [videos](../../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Optimystics%20Videos%204aa0cc0fe82f46fd8fb6a8548b7a5732.md) page.

![[https://youtu.be/I0Y-j1nEGQA](https://youtu.be/I0Y-j1nEGQA)](retropgf_pitches_2_thumbnail_draft.png)

[https://youtu.be/I0Y-j1nEGQA](https://youtu.be/I0Y-j1nEGQA)

### [RetroPitches 2](https://youtu.be/I0Y-j1nEGQA)

How can public goods games grow Optimism? In the second RetroPitch event we give a spotlight for RetroPGF applicants and participants rank the most helpful, exciting, and fun pitches  🌱 🔴 🏟️

![[https://youtu.be/IYwhREMx84Y](https://youtu.be/IYwhREMx84Y)](retropgf_pitches_1_thumbnail.png)

[https://youtu.be/IYwhREMx84Y](https://youtu.be/IYwhREMx84Y)

### [RetroPitches 1](https://youtu.be/IYwhREMx84Y)

We debut the RetroPitch games to help public goods creators promote their RetroPGF grant and give citizens an easy way to learn about exciting projects in the Optimism Collective 🔴 🌟

![[https://optimismfractal.com/6](https://optimismfractal.com/6)](../../../OptimismFractal%20com%20c238e1244229466ba8b7753b74104b6f/Optimism%20Fractal%20Website%20Database%20f636c69e7a3a4435a2163516c9e87249/Media%20eac86b8f965a415c9a69c2b58aa97103/optimism_fractal_6_thumbnail_final_.png)

[https://optimismfractal.com/6](https://optimismfractal.com/6)

### [OF 6: Public Goods Games](https://optimismfractal.com/6)

What are the best ways to promote public goods creators and help citizens fairly reward impact? We play the Respect Game and RetroPGF Pitch Game to measure the output of outstanding buidlers in the Optimism Collective 🏟️ 🔴 ✨

![[https://optimismfractal.com/5](https://optimismfractal.com/5)](../../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Optimystics%20Videos%204aa0cc0fe82f46fd8fb6a8548b7a5732/optimism_fractal_5_thumbnail_final.png)

[https://optimismfractal.com/5](https://optimismfractal.com/5)

### [**OF 5: Respect Games and RetroPitches!**](https://optimismfractal.com/5)

How can consensus games create profound benefits for all? We set the stage at Optimism Fractal for a joyful Respect Game and the first RetroPGF Pitch Game to amplify the power of public goods creators ⚡️🌞 🔴

### Tweets

![[https://twitter.com/optimystics_/status/1731876823393271985](https://twitter.com/optimystics_/status/1731876823393271985)](Exploring%20RetroPitches%2068097132274e4367830c63b3d379bfa1/Untitled.png)

[https://twitter.com/optimystics_/status/1731876823393271985](https://twitter.com/optimystics_/status/1731876823393271985)

![[https://twitter.com/optimystics_/status/1731521546038956121](https://twitter.com/optimystics_/status/1731521546038956121)](Exploring%20RetroPitches%2068097132274e4367830c63b3d379bfa1/Untitled%201.png)

[https://twitter.com/optimystics_/status/1731521546038956121](https://twitter.com/optimystics_/status/1731521546038956121)

## The History of RetroPitches

### Eden Fractal Pitch Sessions

Prior to the RetroPitch games in October of 2023, there were early versions of the RetroPitches game played in three live events. We called these Eden Fractal Pitch Sessions. 

Eden Fractal Pitches is a social coordination game where players compete to share the best pitches about public goods and their peers rank each others’ pitches. The first three games were played with approximately fifteen participants in Eden Fractal meetings, which you can see in the videos and show notes below. You can see these first games in action to gain a better understanding of the benefits the RetroPitches can provide for the Optimism Collective.

We held our first two Eden Fractal Pomelo Pitch Sessions with great success and heard amazing pitches to create public goods in [week 41](https://edenfractal.com/41) and [42](https://edenfractal.com/42) of [Eden Fractal](https://edenfractal.com/). After that, we did two more in [week 55](https://edenfractal.com/55) and [week 56](https://edenfractal.com/56). You can watch all sessions and explore show notes in the links below. 

- 
    
    These pitch sessions provided great place to promote work, learn about exciting projects, and network with other public goods creators.
    

![[https://edenfractal.com/56](https://edenfractal.com/56)](../Cignals%2050abfee5a9f449138263b8c109f72b38/EF_56_final_thumbnail.png)

[https://edenfractal.com/56](https://edenfractal.com/56)

### [**EF 56: Gamifying Public Goods**](https://edenfractal.com/56)

Aloha! In our fourth public goods pitch session, we ride the groovy waves of collaboration and play Cignals to rank the most fun and beneficial pitches! 🌴 🌊 🏄🏽‍♂️

![[https://edenfractal.com/55](https://edenfractal.com/55)](../Cignals%2050abfee5a9f449138263b8c109f72b38/EF_55_final.png)

[https://edenfractal.com/55](https://edenfractal.com/55)

### [EF 55: **Inventing Games for Public Goods!**](https://edenfractal.com/55)

Jumping out with our third public goods session where we share and rank amazing pitches from Eden Fractal community members with the new Cignals app! 🪴 🌈 🌞

![[https://edencreators.com/pitches](https://edencreators.com/pitches)](Exploring%20RetroPitches%2068097132274e4367830c63b3d379bfa1/eden_fractal_pomelo_pitch_sessions_4.png)

[https://edencreators.com/pitches](https://edencreators.com/pitches)

### [Pitch Sessions Article](https://www.notion.so/Pitches-ee53d6ef729542b1900e349313d5396c?pvs=21)

An introduction to Eden Fractal Pitch Sessions, a recurring event where players compete to share awesome pitches about public goods!

## The Future of RetroPitches

### Scaling Video Production

In the next rounds of RetroPGF, we aim to create short clips of each presentation to promote everyone’s project with short videos. This will provide a service where everyone can get high quality videos of their pitches and create short form educational video content to inspire the world with Optimism. The short video clips can be shared on social media services to help promote public goods creators in the Optimism Collective to a wider audience and help citizens review applicants more effectively. 

![[https://optimystics.io/videos](https://optimystics.io/videos)](../The%20Respect%20Game%2044c6b16009074f2da6185024c7e48e5c/optimystics_videos.webp)

[https://optimystics.io/videos](https://optimystics.io/videos)

### Onchain Gameplay Integrations

Our experience so far has provided a valuable proof of concept and we are excited to develop onchain integrations to improve the next season of games.  In the first season of RetroPitches we used a web2 application called Slido to facilitate voting. Now, we’re now are aiming to build integrations with an app called we are developing called [Cignals](../Cignals%2050abfee5a9f449138263b8c109f72b38.md). 

This can enable powerful onchain features like increased voting weights for respected community leaders, which could help make the games more helpful for assessing impact with the wisdom of the crowd and creating [lists](https://gov.optimism.io/t/retropgf-3-round-design/6802#lists-scaling-the-evaluation-of-projects-3) based on the game scores. For example, this app will allow realtime voting with [Respect](../Respect%206357d339d30b425997f3da4dd6f75f32.md) scores from the [Respect Game](../../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Games%20a87953a98246402da3e171f43811bfda/Fractal%20Games%20958dadb96fc940c1a6789e663d36a2c5/Respect%20Game%2097fc60fcf6944c3095df07a64e86b481.md) and other onchain attestations on the OP Mainnet.  

This app is designed to be useful in many contexts and enable all communities to enjoy the benefits of consensus games. We are currently researching the best technical solutions to enhance the functionalities of the RetroPitch games with these kinds of onchain integrations. 

![[https://optimystics.io/cignals](https://optimystics.io/cignals)](Exploring%20RetroPitches%2068097132274e4367830c63b3d379bfa1/cignals_op_1.png)

[https://optimystics.io/cignals](https://optimystics.io/cignals)

### [Cignals](https://optimystics.io/cignals)

Share delightful experiences and get a new kind of feel for the room with Cignals, an innovative app that helps communities coordinate by playing fun consensus games!

- 
    
    Pitches are played with the new [Cignals](https://www.notion.so/Cignals-edfd78c4e37f4fc49ce9c17b93e13665?pvs=21) app, which enables communities to express consensus more effectively than ever before. One of our favorite parts of pitch sessions is how they can inspire cool shows. Similar to [ideathons](https://www.notion.so/Ideathons-00188ac5b5964add9c7c864da91ca046?pvs=21) and other [FractalJoy](https://fractaljoy.io/) games, these pitch sessions provide natural opportunities for communities to collaboratively create media with the power of [DAMS](https://www.notion.so/DAMS-ee6c42b9544b433b8fd1dcd9571ea73a?pvs=21). For example, we’ve hosted four Pomelo Pitch Sessions at Eden Fractal meetings. 
    
    RetroPitches can now be played by any community on Optimism.
    
      The players successfully tested the alpha version of the [Cignals](../Cignals%2050abfee5a9f449138263b8c109f72b38.md) app, which can be used in the future to enable players to use greater voting power based on the [Respect](../Respect%206357d339d30b425997f3da4dd6f75f32.md) that they earn in [Respect Games](../../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Games%20a87953a98246402da3e171f43811bfda/Fractal%20Games%20958dadb96fc940c1a6789e663d36a2c5/Respect%20Game%2097fc60fcf6944c3095df07a64e86b481.md).
    
    Over time we aim to update the game with the following:
    
    - 
    
    - 
    
    Much more coming soon!
    

- 
    
    ## Media
    
    ![Untitled](Exploring%20RetroPitches%2068097132274e4367830c63b3d379bfa1/Untitled%202.png)
    

## Related Posts

![[https://edencreators.com/games](https://edencreators.com/games)](../../../FractalJoy%202e05dda30cf04fff8b79aa508ca208a4/FractalJoy%20Projects%2019dd74928ad34a0a9f998a205667ddbf/Write%20Introductory%20Mirror%20Post(s)%20for%20Optimism%20Fra%201e0c8a20efb94bf4b46a9f38e35c195d/Blogs%20and%20Mirror%20Posts%20for%20Optimystics%20and%20Optimis%20ac6c23bd91e442159fa3181aa000b8a0/Introducing%20Optimism%20Fractal%20301842292f8643fe91ea0d5a0af53d3d/EC_Cosmo_Stadium12game21.png)

[https://edencreators.com/games](https://edencreators.com/games)

### [Games](https://www.notion.so/Games-00cc77dfa2bd41068c8d08715a05d8a8?pvs=21)

An introduction to some of our favorite games and a philosophical exploration of how games can create profound benefits for all! Written by our partners, Eden Creators. 

[Untitled](Exploring%20RetroPitches%2068097132274e4367830c63b3d379bfa1/Untitled%20c566b03778d34e0bb22a2c19838e64ff.csv)