# Optimism Fractal Season 3

Displays on Pages:: Cagendas, Optimism Town Hall, events, optimism fractal, optopics
AI summary: Optimism Fractal Season 3 is an upcoming event that will feature posts from the end of Season 2 and new writing related to the optimism fractal. It is currently unpublished.
Published?: No

- [ ]  add posts from end of Season 2 like proposal and video

- [ ]  add writing from the article below

[Optimism Fractal Season 3](https://gov.optimism.io/t/optimism-fractal-season-3/8095)

![optimism fractal 25 promo image final.png](Optimism%20Fractal%20Season%203%20eebf48d660814cc68a7e80cd2c25f20b/optimism_fractal_25_promo_image_final.png)

## Related Posts