# Instructions for testing ORDAO mainnet version during OF meeting

The idea is that each breakout room in addition to submitting consensus to the old contract submits results to the new (candidate) one (through of.frapps.xyz).

1. We play Respect game during our meeting as we always do;
2. After making onchain submissions through [https://optimismfractal.web.app/](https://optimismfractal.web.app/), create another fractalgram account prompt for Optimism (exactly the same way as you did in the beginning of fractalgram session);
3. People who want to use a different account in the new version reply with the new account they want to use. People who are ok using the same account as in the old version, do not have to do anything;
4. Generate new consensus results message for submitting through [https://of.frapps.xyz/](https://of.frapps.xyz/) . See image below for what option to choose.
5. Use the generated link to submit through the new app;
The 3rd step is for people who want to do key rotations. If you don't know what it is or why you should do it, you don't have to do anything at this step - consensus message will have your old address that you submitted at the beginning of respect game in Fractalgram.

[This is based on the upgrade plan which I have outlined in more detail here](https://github.com/sim31/frapps/blob/main/concepts/apps/of2/UPGRADE_PATH.md)