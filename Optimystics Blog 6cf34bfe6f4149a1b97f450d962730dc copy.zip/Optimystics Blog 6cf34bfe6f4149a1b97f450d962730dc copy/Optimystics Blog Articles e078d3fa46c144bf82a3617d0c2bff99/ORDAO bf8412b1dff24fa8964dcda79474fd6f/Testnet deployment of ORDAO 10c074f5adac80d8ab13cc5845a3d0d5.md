# Testnet deployment of ORDAO

### **Frontends**

Submission app: [https://test2.frapps.xyz/](https://test2.frapps.xyz/)

Console: [https://test2-console.frapps.xyz/](https://test2-console.frapps.xyz/)

### **Contracts**

Orec contract: [https://optimism-sepolia.blockscout.com/address/0x430f3F482831898Bc83c7Fe11948b3ADBE025B66](https://optimism-sepolia.blockscout.com/address/0x430f3F482831898Bc83c7Fe11948b3ADBE025B66)

Respect1155 contract: [https://optimism-sepolia.blockscout.com/address/0xF7640995eAffAf5dB5ABEa7cE1F06Be968BFF5e5](https://optimism-sepolia.blockscout.com/address/0xF7640995eAffAf5dB5ABEa7cE1F06Be968BFF5e5)

### **Configuration**

- `voting_period` - 180 seconds;
- `veto_period` - 12 hours;
- `prop_weight_threshold` - 34 Respect
- `max_live_votes` - 4
- `respect_contract` - 0x6b11FC2cec86edeEd1F3705880deB9010F0D584B

Respect contract here currently has only assigned Respect to Optimystics team. Let me know if you want to test with Respect (without it you'll still be able to vote but your vote won't have weight).

There's currently a proposal to change voting period to be 12 hours as well.