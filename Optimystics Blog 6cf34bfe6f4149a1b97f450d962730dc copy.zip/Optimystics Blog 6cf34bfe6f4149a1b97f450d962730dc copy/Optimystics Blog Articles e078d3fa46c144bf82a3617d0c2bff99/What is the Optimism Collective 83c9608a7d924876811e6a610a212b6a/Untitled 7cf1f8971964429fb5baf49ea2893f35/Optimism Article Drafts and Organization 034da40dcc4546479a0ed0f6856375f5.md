# Optimism Article Drafts and Organization

Created: October 29, 2023 9:37 PM
Published?: No

Consider- 

Maybe this should be organized into database(s)?
• Funding Opportunities
• Key Concepts
• Key people and thought leaders
• Events
• Podcasts
• Super Chain and OP Stack

# Overview

## Introduction

## Table of Contents

- What is Optimism?
- Funding Opportunities
- 

# Funding Opportunities

## Intro

[https://community.optimism.io/docs/governance/get-a-grant/](https://community.optimism.io/docs/governance/get-a-grant/)

**Collective Grants** support specific projects to be completed in the future. All Collective Grants are made in OP and are locked for one year, except growth experiments grants which may pass OP directly through to the end-users. Collective Grants may be distributed upon completing the milestones specific to your grant application.

There are four different types of Collective Grants.

## RetroPGF

[RetroPGF](https://www.notion.so/RetroPGF-3ae2017c32a54cedb36b34b6517666b6?pvs=21) 

[https://app.optimism.io/retropgf](https://app.optimism.io/retropgf)

[https://optimism.mirror.xyz/oVnEz7LrfeOTC7H6xCXb5dMZ8Rc4dSkD2KfgG5W9cCw](https://optimism.mirror.xyz/oVnEz7LrfeOTC7H6xCXb5dMZ8Rc4dSkD2KfgG5W9cCw)

- 
    
    ![Untitled](Optimism%20Article%20Drafts%20and%20Organization%20034da40dcc4546479a0ed0f6856375f5/Untitled.png)
    

## Grants Council

- 
    
    ![Untitled](Optimism%20Article%20Drafts%20and%20Organization%20034da40dcc4546479a0ed0f6856375f5/Untitled%201.png)
    

## Missions

- 
    
    ![Untitled](Optimism%20Article%20Drafts%20and%20Organization%20034da40dcc4546479a0ed0f6856375f5/Untitled%202.png)