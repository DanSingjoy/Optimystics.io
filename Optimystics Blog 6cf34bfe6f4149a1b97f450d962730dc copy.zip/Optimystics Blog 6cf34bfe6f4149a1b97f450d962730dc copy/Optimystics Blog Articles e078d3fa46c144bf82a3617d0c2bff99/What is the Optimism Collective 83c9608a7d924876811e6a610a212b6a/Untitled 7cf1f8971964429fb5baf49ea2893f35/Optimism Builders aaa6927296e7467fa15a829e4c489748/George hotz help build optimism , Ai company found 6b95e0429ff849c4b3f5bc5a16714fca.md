# George hotz help build optimism , Ai company founder

[https://x.com/realgeorgehotz?s=11&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/realgeorgehotz?s=11&t=xP2VArgrZ3VqnY5S2s8WeQ)

we may not agree on many things, but this is one of the easiest changes the US can make that radically brightens our potential future. it's literally free money for our country. and I don't know about you, but I like living in a rich country with smart people.

Quote

one of the easiest policy wins i can imagine for the US is to reform high-skill immigration. the fact that many of the most talented people in the world want to be here is a hard-won gift; embracing them is the key to keeping it that way. hard to get this back if we lose it.

I'm offering due diligence as a service. Before you invest millions into an AI or hard tech startup, hire me for $10K. I will evaluate feasibility of idea and realisticness of timeline given founder. Send money before reach out, PayPal geohot@gmail.com. Will refund if not a fit

## George Hotz

[https://en.wikipedia.org/wiki/George_Hotz](https://en.wikipedia.org/wiki/George_Hotz)