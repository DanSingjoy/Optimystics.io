# Optimism Builders

Created: October 29, 2023 9:37 PM
Published?: No

[George hotz help build optimism , Ai company founder](Optimism%20Builders%20aaa6927296e7467fa15a829e4c489748/George%20hotz%20help%20build%20optimism%20,%20Ai%20company%20found%206b95e0429ff849c4b3f5bc5a16714fca.md)