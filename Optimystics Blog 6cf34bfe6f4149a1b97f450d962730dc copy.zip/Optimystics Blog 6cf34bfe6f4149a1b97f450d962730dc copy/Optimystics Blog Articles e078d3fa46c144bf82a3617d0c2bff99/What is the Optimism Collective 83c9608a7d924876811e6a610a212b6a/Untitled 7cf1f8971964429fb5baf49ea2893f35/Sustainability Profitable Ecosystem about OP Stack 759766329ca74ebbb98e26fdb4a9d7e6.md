# Sustainability / Profitable Ecosystem about OP Stack

Created: October 29, 2023 9:37 PM
Published?: No

[Profitable optimism’s l2. Base is making 78 million per year  . Revenue](https://www.notion.so/Profitable-optimism-s-l2-Base-is-making-78-million-per-year-Revenue-9ff4785dc7e34debbd54e60da138d6af?pvs=21)