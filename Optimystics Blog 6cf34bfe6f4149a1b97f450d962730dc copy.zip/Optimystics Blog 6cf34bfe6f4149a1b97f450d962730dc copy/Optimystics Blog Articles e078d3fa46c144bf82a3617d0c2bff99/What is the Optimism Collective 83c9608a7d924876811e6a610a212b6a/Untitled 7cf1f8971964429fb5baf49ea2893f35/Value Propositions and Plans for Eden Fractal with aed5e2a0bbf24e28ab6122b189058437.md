# Value Propositions and Plans for Eden Fractal with Optimism

Created: October 29, 2023 9:37 PM
Published?: No

## **Value Propositions for Eden Fractal with Optimism**

• Opportunities for all of us
• Funding and growth opportunities
• Helpful and aligned network
• Goal for Fractal OP Stack
• We can help promote each other there

## **Plans for Eden Fractal with Optimism**

• Eden Fractal posts consensus to optimism
• Eden Fractal creates public goods for optimism
• Eden Fractal helps create Optimism Fractal