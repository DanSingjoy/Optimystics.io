# Links for Optimism Presentation

Created: October 29, 2023 9:37 PM
Published?: No

**Links for Presentation:**

[https://app.optimism.io/announcement](https://app.optimism.io/announcement) - great page
[https://www.optimism.io/](https://www.optimism.io/)
[https://community.optimism.io/docs/governance/](https://community.optimism.io/docs/governance/)
[https://www.optimism.io/vision](https://www.optimism.io/vision)
Esthers pheonix article or podcast
[https://app.optimism.io/retropgf](https://app.optimism.io/retropgf) - great page
Vitalik’s post [Vitalik Buterin](https://www.notion.so/Vitalik-Buterin-572270b79f6244c981bd27b5c6f6aaf4?pvs=21)
vitalik’s summary
Season 2 recap video
Season 3 announcement [https://optimism.mirror.xyz/oVnEz7LrfeOTC7H6xCXb5dMZ8Rc4dSkD2KfgG5W9cCw](https://optimism.mirror.xyz/oVnEz7LrfeOTC7H6xCXb5dMZ8Rc4dSkD2KfgG5W9cCw)
More funding sources: [https://gov.optimism.io/](https://gov.optimism.io/), grants council, missions, etc
[https://community.optimism.io/docs/governance/get-a-grant/](https://community.optimism.io/docs/governance/get-a-grant/)
Community calls: [https://gov.optimism.io/c/updates-and-announcements/55-category/55](https://gov.optimism.io/c/updates-and-announcements/55-category/55)
[app.optimism.io/superchain](http://app.optimism.io/superchain)