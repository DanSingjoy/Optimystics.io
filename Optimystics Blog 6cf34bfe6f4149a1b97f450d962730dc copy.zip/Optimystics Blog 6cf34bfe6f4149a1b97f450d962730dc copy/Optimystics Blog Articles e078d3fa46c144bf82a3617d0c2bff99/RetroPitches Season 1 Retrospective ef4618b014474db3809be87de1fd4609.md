# RetroPitches Season 1 Retrospective

AI summary: RetroPitches Season 1 Retrospective is a document that is currently unpublished and requires a one to two sentence summary.
Published?: No

## RetroPGF Applicants

You can see the speakers, their RetroPGF applications, and the timestamps of their presentations below:

### BasePaint

[Presentation](https://www.youtube.com/watch?v=wFc02QUdLjg&t=870s) by Winter

[RetroPGF Application](https://vote.optimism.io/retropgf/3/application/0x91bba885bafc9e5144c7577f7159778277e17eb6073d4f6adf5acd3b31c9f1fc)

### DeepDAO

[Presentation](https://www.youtube.com/watch?v=I0Y-j1nEGQA&t=443s) by Eyal

[RetroPGF Application](https://vote.optimism.io/retropgf/3/application/0xfaaed11baa954ccc12629031eeaf8dbfb8041b73f0e050614152b0d1b6beaed7)

### EVM Finance

[Presentation](https://www.youtube.com/watch?v=I0Y-j1nEGQA&t=986s) by Alex

[RetroPGF Application](https://vote.optimism.io/retropgf/3/application/0xeb6a80070c1f94ee5bd855e4703d92bb41b44796b866c26c3be72bb74656a290)

### Giveth

[Presentation](https://www.youtube.com/watch?v=I0Y-j1nEGQA&t=1298s) by Almond

[RetroPGF Application](https://vote.optimism.io/retropgf/3/application/0x17cfb81d50a65a6ef3e7ecfdf8e4ca428514d77e74ca3c650d4ba9926f9e67ac)

### L2Beat

[Presentation](https://www.youtube.com/watch?v=wFc02QUdLjg&t=2945s) by Krzysztof

[RetroPGF Application](https://vote.optimism.io/retropgf/3/application/0xc754e70f8d64d1923e4fb7591e0cad3790d4e164b3b11a8db1c1356714037792)

### Copin.io

[Presentation](https://www.youtube.com/watch?v=wFc02QUdLjg&t=2436s) by Nam Tran

[RetroPGF Application](https://vote.optimism.io/retropgf/3/application/0x2f13f29404a2aa8725336f24fcda2eadd5f15ef510db6063b5b0e5b49968c40d)

### EIP Fun

[Presentation](https://www.youtube.com/watch?v=wFc02QUdLjg&t=1298s) by Chloe

[RetroPGF Application](https://vote.optimism.io/retropgf/3/application/0x74bb2fd6c1dacf0d3556a80af369e620df5ee6f348a8435b0b977064c79bc50d)

### LX DAO

[Presentation](https://www.youtube.com/watch?v=wFc02QUdLjg&t=1697s) by Mike

[RetroPGF Application](https://vote.optimism.io/retropgf/3/application/0x79aaf24aab7a9cffbaffd2003b262aa452d31b5a07fb17c54021479284c564be)

### My First Layer 2

[Presentation](https://www.youtube.com/watch?v=wFc02QUdLjg&t=2027s) by Logic

[RetroPGF Application](https://vote.optimism.io/retropgf/3/application/0x0126dfee34af34334c909eb12d6c1695a42146f5c421ae747cd4b9f8a77cb33f)

### InBest Program

[Presentation](https://www.youtube.com/watch?v=wFc02QUdLjg&t=495s) by Alberto

[RetroPGF Application](https://vote.optimism.io/retropgf/3/application/0x50a46b0a2eb26fc734d5429337e6446d068451fb903c86b1dfc79bef41eebaee)

### The Optimist

[Presentation](https://www.youtube.com/watch?v=wFc02QUdLjg&t=495s) by Subli

[RetroPGF Application](https://vote.optimism.io/retropgf/3/application/0x1fe1cb0ecbc5bf8e3ca770babf4404e0f28da2e08dc17d71fffe6b9a627ee6de)

### Optimystics

Presentations by Dan ([1](https://www.youtube.com/watch?v=IYwhREMx84Y&t=1103s), [2](https://www.youtube.com/watch?v=I0Y-j1nEGQA&t=1976s), [3](https://www.youtube.com/watch?v=wFc02QUdLjg&t=3545s))

[RetroPGF application](https://vote.optimism.io/retropgf/3/application/0xfd664805607a6c8e26bed11d372f794ac465462bc171a4b6992b84143876cc3a)