# Next Steps for the OP Fractal Stack

AI summary: This document discusses the next steps for the OP Fractal Stack, including the development of fractal tools and their potential impact on community growth and collaboration within the Optimism ecosystem.
Published?: No

![edencreators_high_tech_tool_computer_with_fractal_garden_and_fl_74655de1-1e18-4f09-ae70-6869dc0d11b8.png](The%20Respect%20Game%2044c6b16009074f2da6185024c7e48e5c/edencreators_high_tech_tool_computer_with_fractal_garden_and_fl_74655de1-1e18-4f09-ae70-6869dc0d11b8.png)

## Next Steps

As you can see in our blog posts about [The Roots of Optimism Fractal](https://optimystics.io/blog/the-roots-of-optimism-fractal) and [Our Fractal Journey to Optimism](https://optimystics.io/blog/our-fractal-journey-to-optimism), we’ve been building fractal tools with talented hundreds of builders for over three years. Our toolset is highly refined as a result of many iterations with testing in public each week on [video](../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Optimystics%20Videos%204aa0cc0fe82f46fd8fb6a8548b7a5732.md) recordings during live meetings.

You can learn about some of the tools that we’ve been developing in the articles featured [here](https://optimystics.io/tools#72901682be5c444591f88e0261694568). Though some of our tools have been built in other Web3 ecosystems, all of our tools are blockchain agnostic and can be built on Optimism. The research, development, and iterative testing of these tools provide an invaluable foundation for versions of these tools on the OP Stack. We look forward to porting the most helpful tools and inspiring the next generation of optimistic developers to further expand upon this new foundation for community growth.

After testing the initial toolset that we’ve delivered with the Optimism community at weekly [Optimism Fractal](http://OptimismFractal.com) meetings, we aim to build many more features for fractal cooperation on the OP Stack that we’ve been researching/developing and compose with many helpful tools on Optimism. We believe that our fractal tools will become an essential component of the OP Stack and help millions of communities grow. 

- 
    
    
    [EVM Community Coordination Tools for Eden](https://www.notion.so/EVM-Community-Coordination-Tools-for-Eden-0f81bb81abd34ba8b77573999fbc5cb2?pvs=21) [EVM Community Coordination Tools ](https://www.notion.so/EVM-Community-Coordination-Tools-54bd9ccaf27c4c2c921cabccc9a610c7?pvs=21)
    
    and creating collaborations and integrations with OP Stack and Optimism Community 
    
    Though many of our tools have been built in other Web3 ecosystems, all of our tools are blockchain agnostic and the testing, iteration, design are invaluable for Optimism and the OP Stack. 
    
    - [ ]  link to [edenCreators.com/tools](http://edenCreators.com/tools) for more details?
    
- 
    
    
    We’ve been building open source tools for fractal cooperation in another Web3 ecosystem (EOS/Antelope) for the past several years. We’ve been developing EVM tools for the past year Testing, researching. Many talented developers testing in public each week with videos. Now we’re focused on porting over the tools the ecosystems and building the best possible fractal 
    
    Bringing tools from research and development to practical application, such as Cignals, Respect trees and firmament. Uniting all for the benefit of OP Stack and Superchain and everyone
    
- 
    
    ### OP Fractals 1.0: Roots
    
    So far already released the first iteration/version. OP Fractal Stack 1.0 : Roots. This includes smart contracts, web interface, and fractalgram. Any community can now empower their community with Fractal tools on OP Stack. Already being using by Optimism Fractal and Eden Fractal, which you can learn more about in our [Events](../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Events%20ea9e175f88f5452f9bd834bbabcab0a4.md). Much more is coming soon and we’re stoked for this relase. 
    
    [**Learn More**](OP%20Fractal%20Stack%20b89a9aa230c540e899d7dcece7ecc163.md)
    
    [**Repository**](https://github.com)