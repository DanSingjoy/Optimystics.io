# First Generation OPF Software

Displays on Pages:: Tools
AI summary: This document provides an overview of the first generation of Optimism Fractal software developed by Optimystics, which includes an open-source toolset for the Respect Game. It highlights the features of the toolset and encourages community engagement through various resources.
AI summary 1: In this blog post, we delve into the first generation of Optimism Fractal software, developed by Optimystics in late 2023. This software includes a comprehensive open-source toolset designed specifically for facilitating the Respect Game, a unique approach to community engagement and contribution. We explore the features of the toolset, its practical applications, and the benefits it brings to users. Additionally, we provide insight into how these tools empower individuals to collaborate effectively while having fun. Join us as we outline the capabilities of this innovative software and its role in shaping community dynamics.
Description: An overview of the first generation of Optimism Fractal software developed by Optimystics in late 2023, which includes an open-source toolset designed for the Respect Game.
Published?: Yes

![op fractal stack 1.png](First%20Generation%20OPF%20Software%2010d074f5adac8012b864f78e7512e918/op_fractal_stack_1.png)

## Overview of Current Toolset

In September 2023, the Optimystics created an open source toolset that enables anyone to grow their community by playing the [Respect Game](https://optimystics.io/respectgame) on Optimism. This toolset has been in use since the beginning of Optimism Fractal and you can join Optimism Fractal [weekly events](https://lu.ma/4ggdpzyp) to try it out. 

This toolset includes [smart contracts](https://github.com/sim31/op-fractal-sc) for ranking contributions, a [webapp](https://optimismfractal.web.app/) to submit votes while playing consensus games, and an app called [Fractalgram](Fractalgram%20198c4a23def749669d9bab38283ef66e.md) to provide an intuitive experience for all players on during community events. The consensus games that these tools implement are used to distribute a non-transferable token called [Respect](https://optimystics.io/respect), which represents contribution of an individual to a common goal. The tools that we build are all open source, so developers can use the code in our [repositories](https://github.com/optimystics) and anyone can now start playing the Respect Game at their community events. 

You can watch the short video clip below for a basic introduction to the game that these tools enable and explore the articles below for many exciting details. We encourage you to watch [videos](https://www.notion.so/Videos-3e3eba6903524c0e8ae9aa47be6cd682?pvs=21) of Optimism Fractal events and explore our [blog](../../Optimystics%20Blog%206cf34bfe6f4149a1b97f450d962730dc.md) to gain a better understanding of the profound benefits these tools can create. 

### Introductory Video

[https://youtu.be/Ggpfi55eKEw](https://youtu.be/Ggpfi55eKEw)

How do we use the OP Mainnet to play the Respect Game? The Optimystics demonstrate the first version of Fractalgram and our intuitive webapp that helps communities reach consensus while having fun!

## Next Generation Software

Explore the articles below for details about the next generations of Optimism Fractal software:

[Untitled](First%20Generation%20OPF%20Software%2010d074f5adac8012b864f78e7512e918/Untitled%2010d074f5adac808892c1f23131a27a85.csv)