# Deliberative democracy and sortition

[https://x.com/claudiachwalisz/status/1831689060592574585?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/claudiachwalisz/status/1831689060592574585?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/claudiachwalisz/status/1831689060592574585?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/claudiachwalisz/status/1831689060592574585?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)