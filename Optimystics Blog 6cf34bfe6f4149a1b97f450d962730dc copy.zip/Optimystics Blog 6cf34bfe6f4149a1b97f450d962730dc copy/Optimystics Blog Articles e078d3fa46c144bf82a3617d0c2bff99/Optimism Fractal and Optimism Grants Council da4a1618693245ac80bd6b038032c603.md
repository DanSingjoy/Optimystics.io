# Optimism Fractal and Optimism Grants Council

Displays on Pages:: 2023, EF 68, Optimism Missions, Roots of Optimism Fractal, missions
AI summary: This article shares insights and experiences from a proposal made to the Optimism Grants Council for launching Optimism Fractal, summarizing key takeaways from a live discussion during the 68th Eden Fractal meeting.
AI summary 1: In this blog post, we delve into our journey of proposing the Optimism Fractal to the Optimism Grants Council. We reflect on our learnings and experiences from the process, highlighting key discussions held during the 68th Eden Fractal meeting. This article aims to provide insights into the motivations behind the Optimism Fractal initiative, the community's engagement, and the potential impact of our proposal. Whether you're a seasoned member of the Optimism Collective or a newcomer, this overview will guide you through the essential elements of our mission and the collaborative spirit that drives us forward.
Description: We share our learnings and experience making a proposal for the Optimism Grants Council to start Optimism Fractal! 🌻
Published?: Yes

![Optimism Fractal Mission Grant Proposal 1.png](Optimism%20Fractal%20and%20Optimism%20Grants%20Council%20da4a1618693245ac80bd6b038032c603/Optimism_Fractal_Mission_Grant_Proposal_1.png)

### Hello fellow traveller, thanks for stopping by! 🎩

This article provides an overview of our learnings and experience making a proposal for the Optimism Grants Council to start Optimism Fractal. If you’re not yet familiar with the Optimism Collective, you can check out this educational [guide](https://optimystics.io/blog/growing-with-optimism) to learn about it and explore our blog for more. The following was written in September 2023 and provides timestamps from a live discussion with community leaders during the 68th Eden Fractal meeting, which you can see below or in the original [show notes](https://edenfractal.com/68). Enjoy!

![edencreators_create_a_red_sky_and_sunset_rays_08ae4909-3500-401e-bb25-f3f64bb241c2.png](Optimism%20Fractal%20and%20Optimism%20Grants%20Council%20da4a1618693245ac80bd6b038032c603/edencreators_create_a_red_sky_and_sunset_rays_08ae4909-3500-401e-bb25-f3f64bb241c2.png)

### Key Takeaways from Eden Fractal Meeting on Optimism Grants

Dan Singjoy collated several pages with key information in this topics [page](https://www.notion.so/Optimism-Fractal-Proposal-Updates-9c50a92243c04f2ab9190fd4deba9b75?pvs=21) which shows an overview of the feedback from reviewers, alongside rubric scores used for evaluation of the Season 4 Cycle 15 grants. This was first being given an overview between [39:12](https://youtu.be/QcWcW2meiTg?t=2352) - [49:51](https://youtu.be/QcWcW2meiTg?t=2991), and later discussed widely at [2:08:32](https://youtu.be/QcWcW2meiTg?t=7712). You can check out the feedback from the Optimism Fractal grantees to the grant reviewers in this Notion [article](https://www.notion.so/Optimism-Fractal-Proposal-Feedback-e276fd1673f141c3884f65d5c021f4b4?pvs=21).

This delved into each of the written page responses created as a response to the preliminary feedback, which were shared with the reviewers. These pages were giving more information about the sections on ‘Development of OP stack’, ‘Likelihood of Success’, ‘Builder Draw’ and more. Dan gives more clarity on the scope of the proposal at [2:14:10](https://youtu.be/QcWcW2meiTg?t=8050) including EVM based community synergies, ideas on respect tokens and governance tools as social games ported over to Optimism’s ecosystem.

The following clip shows an overview of the Optimism Fractal proposal from this event:

[https://www.youtube.com/watch?v=IFNjgReIV0c](https://www.youtube.com/watch?v=IFNjgReIV0c)

The pages within the article aim to help reviewers better understand the value of the grant scope, while establishing the importance of Optimism Fractal. In [1:45:54](https://youtu.be/QcWcW2meiTg?t=6354), the reviewers’ feedback was initially introduced. Dan goes through the [rubric](https://app.charmverse.io/op-grants/page-13972604474186334) for Proposals for builders sub-committee between [2:00:00](https://youtu.be/QcWcW2meiTg?t=7215) - [2:07:53](https://youtu.be/QcWcW2meiTg?t=7673), including the Builders’ Cycle 15 Preliminary [Roundup](https://gov.optimism.io/t/cycle-15-grants-preliminary-roundup/6772) review, amongst which was Optimism Fractal. For more clarity, Dan shows the comments section of the grant proposal page at [2:07:53](https://youtu.be/QcWcW2meiTg?t=7673) where you can find the original correspondence.

The main outcome at the end of the Eden Fractal meeting was that the preliminary feedback is a great resource of reflection into the way that the grant is presented, and what might be the sections for improvement. Taking in account the possibility to cohesively apply to future grants as a collaborative whole discussed at [1:47:12](https://youtu.be/QcWcW2meiTg?t=6432) which was brought up by Perry. Thank you to everyone for your support 🌱

### Full Episode

Watch the full episode below for all the exciting discussions about our experience with Optimism Grants and check out this [article](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6.md) for more details about the roots of Optimism Fractal!

[https://youtu.be/QcWcW2meiTg](https://youtu.be/QcWcW2meiTg)

**EF 68: Planting Optimism Fractal**

What are the best growth opportunities for communities creating public goods? We explore the new Optimism Fractal grant proposal, RetroPGF, and other grants to fund public goods creators in the Optimism Ecosystem 🌱