# EasyRetropgf.xyz from owocki and west gitcoin team

[https://x.com/owocki/status/1745848091217912143?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/owocki/status/1745848091217912143?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/owocki/status/1745848091217912143?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/owocki/status/1745848091217912143?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[Forum post ](EasyRetropgf%20xyz%20from%20owocki%20and%20west%20gitcoin%20team%20130d46083b3d4c92802f16a99318f0b7/Forum%20post%207b97208be52b4c2fb4728e8b376e516e.md)