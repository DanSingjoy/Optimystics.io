# Mission Request for

**Delegate Mission Request Summary:**

*Mission Requests should be tightly scoped and well-specified. You can see examples [here](https://github.com/ethereum-optimism/ecosystem-contributions/issues?q=is%3Aissue+is%3Aopen+RFP). You should describe your Mission Request in 1-2 sentences.*

**S5 [Intent](https://gov.optimism.io/t/collective-intents-season-5/6883) Please list the Intent your Request aligns with here:**

**Proposing Delegate:** *Delegate name/pseudonym, linked to delegate profile*

**Proposal [Tier](https://gov.optimism.io/t/collective-trust-tiers/5877)**: *Please specify the Tier required for Mission Applications under this Request (ie. applications must be submitted by teams at the Fledging Tier)*

**Baseline grant amount:** *This amount should reflect the minimum amount required to execute the Mission. Additional rewards may be received via RetroPGF, based on impact/outperformance. We recommend a 50/50 split between Mission/RetroPGF rewards in Season 5 to incentivize quality execution. Over time, the proportion of baseline grants to retroactive rewards should shift towards RetroPGF until everything is funded by RetroPGF.*

**Should this Foundation Mission be fulfilled by one or multiple applicants:** *Select from: “One,” “Up to X” or “Multiple*”

**Submit by:** *To be set by Grants Council*

**Selection by:** *To be set by Grants Council*

**Start date:** *If applicable*

**Completion date:** *If applicable. Please note Missions must be completed within 12 months (i.e. marked as `done`).*

### **Specification**

**How will this Delegate Mission Request help accomplish the above Intent?**

**Please explain alignment with the relevant Intent**

**What is required to execute this Delegate Mission Request?**

**Please list responsibilities and/or expected deliverables**

**How should the Token House measure progress towards this Mission?**

*These measures should focus on progress towards completion. Including expected completion dates for each is recommended*

*Please be as specific as possible in defining measures of progress so that Token House delegates can accurately track execution*

**How should badgeholders measure impact upon completion of this Mission?**

*These measures should be focused on performance and may be used by badgeholders to assess your Misson’s impact in the next round of RetroPGF*

*Please be as specific as possible in defining measures of impact so that Citizens’ House badgeholders can accurately measure the grant’s impact*

**Have you engaged a Grant-as-a-service provider for this Mission Request?***If so, please disclose the details of this arrangement, to the extent possible.*

***Has anyone other than the Proposing Delegate contributed to this Mission Request?** If so, who, and what parts of this application did they contribute to?*