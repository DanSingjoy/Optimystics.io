# Create RetroPGF UI with application sorting based on community attestations

Checked: No
Intent: Intent 4: Improve governance accessibility
Status: Not started
Status 1: Not started
Status 2: Not started
Summary: This document outlines a mission request to improve governance accessibility for RetroPGF. The request aims to make it easier for badgeholders to understand impact, reduce burden, and make it easier for projects to get discovered. The document also includes information about the intent, measurements, and examples of delegate mission requests related to governance accessibility.

## Alternate Names

- Improve Impact Evaluation for RetroPGF
- Improve RetroPGF Review Process with Optimism Fractal

## Mission Request

**Delegate Mission Request Summary:** *Mission Requests should be tightly scoped and well-specified. You can see examples [here 7](https://github.com/ethereum-optimism/ecosystem-contributions/issues?q=is%3Aissue+is%3Aopen+RFP). You should describe your Mission Request in 1-2 sentences here.*

- 
    
    Im
    
    Make it easier for badgeholders to understand impact , reduce burden
    
    make it easier for projects to get discovered
    
    important for scaling as RetroPGF grows with more proejcts
    

**S5 [Intent 5](https://gov.optimism.io/t/collective-intents-season-5/6883):** Improve governance accessibility

**Proposing Delegate:** *Delegate name/pseudonym, linked to delegate profile*

**Proposal [Tier 7](https://gov.optimism.io/t/collective-trust-tiers/5877):** *Please specify the Tier required for Mission Applications under this Request (ie. applications must be submitted by teams at the Fledging Tier)*

**Baseline grant amount:** *This amount should  reflect the minimum amount required to execute the Mission. Additional rewards may be received via RetroPGF, based on impact/outperformance. We recommend a 50/50 split between Mission/RetroPGF rewards in Season 5 to incentivize quality execution. Over time, the proportion of baseline grant to retroactive rewards should shift towards RetroPGF until everything is funded by RetroPGF.*

**Should this Foundation Mission be fulfilled by one or multiple applicants:** *Select from: “One,” “Up to X” or “Multiple”*

**Submit by:** *To be* s*et by Grants Council*

**Selection by:** *To be set by Grants Council*

**Start date:** *If applicable*

**Completion date:** *If applicable. Please note Missions must be completed within 12 months (i.e. marked as `done`).*

### Specification

**How will this Delegate Mission Request help accomplish the above Intent?**

- *Please explain alignment with the relevant Intent*

**What is required to execute this Delegate Mission Request?**

- *Please list responsibilities and/or expected deliverables*

**How should the Token House measure progress towards this Mission?**

- *These measures should focus on progress towards completion. Including expected completion dates for each is recommended*
- *Please be as specific as possible in defining measures of progress so that Token House delegates can accurately track execution*

**How should badgeholders measure impact upon completion of this Mission?**

- *These measures should be focused on performance and may be used by badgeholders to assess your Misson’s impact in the next round of RetroPGF*
- *Please be as specific as possible in defining measures of impact so that Citizens’ House badgeholders can accurately measure the grant’s impact*

- **Have you engaged a Grant-as-a-service provider for this Mission Request?** If so, please disclose the details of this arrangement, to the extent possible:

- **Has anyone other than the Proposing Delegate contributed to this Mission Request?** If so, who, and what parts of this application did they contribute to?

### **Application Instructions:**

*To be defined by the Grants Council in accordance with their internal operating procedures. Mission Applications must collect email addresses and twitter handles. Applications should specify whether they are applying for a growth or builders grants or a combination of the two (in which case, the proportion of rewards should be clear.)* Suggested Template [here 3](https://gov.optimism.io/t/mission-applicant-guide-how-to-submit-a-mission-application/6899).

## Intents

![Untitled](Improve%20RetroPGF%20Review%20Process%20Mission%20Request%20Dr%2044f584bbd4e542729d11987136cd0e41/Untitled.png)

## Intent 4: Improve governance accessibility

Optimism Governance decides on protocol upgrades, allocates the token
 treasury, and stewards Collective profit. Optimism’s two-house system 
is designed to create healthy checks and balances and expand ownership 
to a diverse set of governance participants. For more on the scope and 
responsibilities of Optimism’s governance system, see the [Future of Optimism Governance 4](https://gov.optimism.io/t/the-future-of-optimism-governance/6471).

The Collective must prioritize accessibility in order to create 
governance structures that welcome a broad range of Optimists to 
participate. “Accessibility” includes enabling a diversity of 
perspectives to participate in governance, facilitating better knowledge
 sharing to develop more informed voters, and lowering barriers to 
participation for more culturally diverse involvement in the governance 
process. Increasing the votable supply and reducing the concentration of
 voting power are important byproducts of improved accessibility.

**Collective Measurements**

- Delegated supply of OP
- Average OP voted per governance proposal

**How the Governance Fund Supports Intent #4:**

The Governance Fund will support the majority of Mission Requests that advance this Intent.

**Examples of * Delegate Mission Requests:**

- Contributions that educate the broader community about Optimism governance and RetroPGF
- Contributions that increase the resiliency of core governance infrastructure
- User friendly interfaces to interact with governance programs
- Contributions that promote and maintain a welcoming governance community
- Contributions that increase the understandability of the governance system for new entrants
- Contributions that create transparency and accountability for grant recipients and governance participants

[EasyRetropgf.xyz from owocki and west gitcoin team](Create%20RetroPGF%20UI%20with%20application%20sorting%20based%20%20e0ec853fabea468fbf6491f89ff95010/EasyRetropgf%20xyz%20from%20owocki%20and%20west%20gitcoin%20team%20130d46083b3d4c92802f16a99318f0b7.md)