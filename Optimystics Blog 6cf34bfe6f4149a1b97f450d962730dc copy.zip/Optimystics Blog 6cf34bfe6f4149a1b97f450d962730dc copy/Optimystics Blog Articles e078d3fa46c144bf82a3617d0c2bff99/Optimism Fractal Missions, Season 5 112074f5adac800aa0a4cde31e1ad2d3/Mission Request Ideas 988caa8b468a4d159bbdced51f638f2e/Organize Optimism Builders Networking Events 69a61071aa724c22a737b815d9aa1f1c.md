# Organize Optimism Builders Networking Events

Checked: No
Intent: Intent 2: Grow the Superchain
Status: Not started
Status 1: Not started
Status 2: Not started
Summary: This document outlines a mission request to organize optimism builders networking events with the intent to grow the Superchain. The request includes a description, alternate names, and specifications for executing the mission. It aligns with Intent 2 of the Collective and proposes the use of the Governance Fund to support developer growth on OP Mainnet. The document also provides examples of delegate mission requests and mentions the importance of measuring active builders on the Superchain.

## Description

## Alternate Names

- Draw 50 builders to Optimism networking events

## Mission Request

**Delegate Mission Request Summary:** *Mission Requests should be tightly scoped and well-specified. You can see examples [here 7](https://github.com/ethereum-optimism/ecosystem-contributions/issues?q=is%3Aissue+is%3Aopen+RFP). You should describe your Mission Request in 1-2 sentences here.*

**S5 [Intent 5](https://gov.optimism.io/t/collective-intents-season-5/6883):** *Please list the Intent your Request aligns with here*

**Proposing Delegate:** *Delegate name/pseudonym, linked to delegate profile*

**Proposal [Tier 7](https://gov.optimism.io/t/collective-trust-tiers/5877):** *Please specify the Tier required for Mission Applications under this Request (ie. applications must be submitted by teams at the Fledging Tier)*

**Baseline grant amount:** *This amount should  reflect the minimum amount required to execute the Mission. Additional rewards may be received via RetroPGF, based on impact/outperformance. We recommend a 50/50 split between Mission/RetroPGF rewards in Season 5 to incentivize quality execution. Over time, the proportion of baseline grant to retroactive rewards should shift towards RetroPGF until everything is funded by RetroPGF.*

**Should this Foundation Mission be fulfilled by one or multiple applicants:** *Select from: “One,” “Up to X” or “Multiple”*

**Submit by:** *To be* s*et by Grants Council*

**Selection by:** *To be set by Grants Council*

**Start date:** *If applicable*

**Completion date:** *If applicable. Please note Missions must be completed within 12 months (i.e. marked as `done`).*

### Specification

**How will this Delegate Mission Request help accomplish the above Intent?**

- *Please explain alignment with the relevant Intent*

**What is required to execute this Delegate Mission Request?**

- *Please list responsibilities and/or expected deliverables*

**How should the Token House measure progress towards this Mission?**

- *These measures should focus on progress towards completion. Including expected completion dates for each is recommended*
- *Please be as specific as possible in defining measures of progress so that Token House delegates can accurately track execution*

**How should badgeholders measure impact upon completion of this Mission?**

- *These measures should be focused on performance and may be used by badgeholders to assess your Misson’s impact in the next round of RetroPGF*
- *Please be as specific as possible in defining measures of impact so that Citizens’ House badgeholders can accurately measure the grant’s impact*

- **Have you engaged a Grant-as-a-service provider for this Mission Request?** If so, please disclose the details of this arrangement, to the extent possible:

- **Has anyone other than the Proposing Delegate contributed to this Mission Request?** If so, who, and what parts of this application did they contribute to?

### **Application Instructions:**

*To be defined by the Grants Council in accordance with their internal operating procedures. Mission Applications must collect email addresses and twitter handles. Applications should specify whether they are applying for a growth or builders grants or a combination of the two (in which case, the proportion of rewards should be clear.)* Suggested Template [here 3](https://gov.optimism.io/t/mission-applicant-guide-how-to-submit-a-mission-application/6899).

## Builders Season 4

- [ ]  Review how it is written and consider writing something similar here
    - [ ]  [https://app.charmverse.io/op-grants/page-13972604474186334](https://app.charmverse.io/op-grants/page-13972604474186334)

## Intent 2: Grow the Superchain

Over the past year, Optimism has seen an exciting amount of ecosystem
 growth across many different verticals and communities, and across both
 OP Mainnet and OP Chains.

In Season 5, the Collective will focus on developer growth across the
 Superchain. Crypto is closer than ever to reaching its full potential, 
and it’s the Collective’s responsibility to create the conditions for 
developers around the globe to keep working towards a new version of the
 internet that puts power in the hands of people.

As Optimism expands and the Superchain grows, this Collective Intent 
is targeted at developer growth across the entire Collective: we care 
about developers deploying new applications on OP Mainnet; teams or 
ecosystems adding new OP Chains to the Superchain; and the growth of new
 and existing OP Chains.

**Collective Measurements**

Active Builders on the Superchain, defined as:

- Unique contract deployers across all OP Chains
- Unique contract deployers of contracts with interaction from >50 unique addresses

**How the Governance Fund Supports Intent #2:**

The Governance Fund will support this Intent in a limited capacity:

- The Governance Fund should focus on Mission Requests and/or grants
that advance developer growth on OP Mainnet. The Governance Fund should
not focus on grants to grow other specific OP Chain ecosystems.
- The Governance Fund may support projects that support developer experience on OP Mainnet and across the Superchain.
- The Governance Fund is a small, finite supply of tokens intended to
bootstrap the Collective as it evolves to be supported primarily via
retroPGF; RetroPGF, along with other mechanisms, is better suited to
support the growth of other individual OP Chain ecosystems.

**Examples of * Delegate Mission Requests:**

- Builder and/or growth incentive grants for projects deploying on OP Mainnet
- Interoperability research
- Developer tooling that improves users’ ability to build, test, and deploy applications
- Contributions that improve wallet, block explorer, RPC, or other dev-centric product integrations
- Contributions that support development and adoption of account abstraction wallets
- Frontends to increase access to Optimism’s canonical bridge contracts

![Untitled](Create%20a%20Collaborative%20Space%20for%20Superchain%20Develo%2010b62fb3a136446a8c7c450d3cd03fa6/Untitled.png)