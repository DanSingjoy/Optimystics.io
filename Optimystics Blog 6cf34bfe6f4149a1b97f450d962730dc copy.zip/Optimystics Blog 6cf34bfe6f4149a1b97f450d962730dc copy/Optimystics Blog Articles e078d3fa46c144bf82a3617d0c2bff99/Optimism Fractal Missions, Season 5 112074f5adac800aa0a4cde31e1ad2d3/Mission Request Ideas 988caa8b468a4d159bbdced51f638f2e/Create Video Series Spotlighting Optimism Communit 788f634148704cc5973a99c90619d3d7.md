# Create Video Series Spotlighting Optimism Community Members

Checked: No
Intent: Intent 3: Improve the Consumer Experience
Status: Not started
Status 1: Not started
Status 2: Not started
Summary: This document outlines a mission request to create a video series spotlighting Optimism community members. The request aligns with Intent 3: Improve the Consumer Experience and aims to onboard more users to the Optimism network by showcasing practical use cases and enhancing the user experience. The document provides details on the mission request, required deliverables, measures of progress, and impact. It also mentions the involvement of a Grant-as-a-service provider and contributions from other individuals.

## Description

## Alternate Names

- Grow the Optimism Collective with Interactive Events
- Draw 100 people to onchain social gaming events

## Mission Request

**Delegate Mission Request Summary:** *Mission Requests should be tightly scoped and well-specified. You can see examples [here 7](https://github.com/ethereum-optimism/ecosystem-contributions/issues?q=is%3Aissue+is%3Aopen+RFP). You should describe your Mission Request in 1-2 sentences here.*

**S5 [Intent 5](https://gov.optimism.io/t/collective-intents-season-5/6883):** *Please list the Intent your Request aligns with here*

**Proposing Delegate:** *Delegate name/pseudonym, linked to delegate profile*

**Proposal [Tier 7](https://gov.optimism.io/t/collective-trust-tiers/5877):** *Please specify the Tier required for Mission Applications under this Request (ie. applications must be submitted by teams at the Fledging Tier)*

**Baseline grant amount:** *This amount should  reflect the minimum amount required to execute the Mission. Additional rewards may be received via RetroPGF, based on impact/outperformance. We recommend a 50/50 split between Mission/RetroPGF rewards in Season 5 to incentivize quality execution. Over time, the proportion of baseline grant to retroactive rewards should shift towards RetroPGF until everything is funded by RetroPGF.*

**Should this Foundation Mission be fulfilled by one or multiple applicants:** *Select from: “One,” “Up to X” or “Multiple”*

**Submit by:** *To be* s*et by Grants Council*

**Selection by:** *To be set by Grants Council*

**Start date:** *If applicable*

**Completion date:** *If applicable. Please note Missions must be completed within 12 months (i.e. marked as `done`).*

### Specification

**How will this Delegate Mission Request help accomplish the above Intent?**

- *Please explain alignment with the relevant Intent*

**What is required to execute this Delegate Mission Request?**

- *Please list responsibilities and/or expected deliverables*

**How should the Token House measure progress towards this Mission?**

- *These measures should focus on progress towards completion. Including expected completion dates for each is recommended*
- *Please be as specific as possible in defining measures of progress so that Token House delegates can accurately track execution*

**How should badgeholders measure impact upon completion of this Mission?**

- *These measures should be focused on performance and may be used by badgeholders to assess your Misson’s impact in the next round of RetroPGF*
- *Please be as specific as possible in defining measures of impact so that Citizens’ House badgeholders can accurately measure the grant’s impact*

- **Have you engaged a Grant-as-a-service provider for this Mission Request?** If so, please disclose the details of this arrangement, to the extent possible:

- **Has anyone other than the Proposing Delegate contributed to this Mission Request?** If so, who, and what parts of this application did they contribute to?

### **Application Instructions:**

*To be defined by the Grants Council in accordance with their internal operating procedures. Mission Applications must collect email addresses and twitter handles. Applications should specify whether they are applying for a growth or builders grants or a combination of the two (in which case, the proportion of rewards should be clear.)* Suggested Template [here 3](https://gov.optimism.io/t/mission-applicant-guide-how-to-submit-a-mission-application/6899).

## Intent 3: Improve the Consumer Experience

*Intent #3 has been set by Token House delegates, with the help of Simona Pop.*

To onboard more users to the Optimism network, we must make it easier
 to engage with practical use cases. This improvement will be vital in 
expanding our reach and impact.

**Collective Measurements**

- Number of new wallet addresses with a verified anti-sybil check
- Number of repeat transactions from new addresses
- Number of transactions from new addresses that occur via non-DeFi applications

**How the Governance Fund Supports Intent #3:** Intent #3 will be primarily supported by the Governance Fund.

**Example * Delegate Mission Requests:**

- Development of practical use cases covering areas like gaming,
encrypted on-chain data ownership for companies and individuals, digital identity, ZK application infrastructure, social applications, and
remittance/transfer infrastructure.
- Experience enhancements that may include fiat on/off ramps, UX
improvements (e.g., EIP 6551 and EIP 4337), web2 profile import to web3
profiles, and innovations that streamline on-chain activities.

![Untitled](Create%20a%20Gameshow%20featuring%20Optimism%20Community%20Mem%20368ae109cad34c1c9d5bf369c7e3d6e0/Untitled.png)

[Create Video Series Spotlighting Superchain Developers](Create%20Video%20Series%20Spotlighting%20Optimism%20Communit%20788f634148704cc5973a99c90619d3d7/Create%20Video%20Series%20Spotlighting%20Superchain%20Develo%209555f58f96654c0597cfa4b915697e8e.md)