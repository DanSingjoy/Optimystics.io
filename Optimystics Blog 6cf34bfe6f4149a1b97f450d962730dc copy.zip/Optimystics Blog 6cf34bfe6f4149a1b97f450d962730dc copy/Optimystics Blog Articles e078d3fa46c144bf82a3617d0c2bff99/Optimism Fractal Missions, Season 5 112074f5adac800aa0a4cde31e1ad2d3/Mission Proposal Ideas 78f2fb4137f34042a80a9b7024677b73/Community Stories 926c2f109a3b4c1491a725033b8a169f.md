# Community Stories

Tags: Events and Shows
Description: An innovative show exploring perspectives about communities, social structures and more

## Overview

An innovative show exploring perspectives about communities, social structures and more. Hosted by [Rosmari](https://twitter.com/RosmariDigital).

Learn more and watch episodes at [https://edencreators.com/communitystories](https://edencreators.com/communitystories)

![Untitled](Community%20Stories%20926c2f109a3b4c1491a725033b8a169f/Untitled.png)