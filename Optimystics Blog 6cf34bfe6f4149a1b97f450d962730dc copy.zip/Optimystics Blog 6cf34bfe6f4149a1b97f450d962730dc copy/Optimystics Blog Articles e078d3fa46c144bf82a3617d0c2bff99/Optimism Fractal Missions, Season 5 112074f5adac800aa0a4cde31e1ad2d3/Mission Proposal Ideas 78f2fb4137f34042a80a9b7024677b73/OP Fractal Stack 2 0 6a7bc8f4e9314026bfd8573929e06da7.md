# OP Fractal Stack 2.0

Tags: Tools
Description: The next generation of an open source toolset that enables anyone to grow their community by playing the Respect Game on Optimism.

## Overview

The next generation of an open source toolset that enables anyone to grow their community by playing the [Respect Game](https://optimystics.io/respectgame) on Optimism.

The Respect Game provides a fun new way to foster collaborations, raise awareness for public goods creators, and help the Optimism Collective fairly reward impact. It also introduces revolutionary governance system and enables communities to coordinate to achieve shared goals more efficiently than ever before.

The Respect Game is at the heart of [Optimism Fractal](http://optimismfractal.com/) and our work at Optimystics. We’ve been pioneering this innovative consensus game for years with hundreds of talented builders and we created Optimism Fractal to grow Optimism with weekly events featuring the Respect Game.

You can see details at [Optimystics.io/tools](http://Optimystics.io/tools) and see the articles at the bottom about iterations

![Untitled](OP%20Fractal%20Stack%202%200%206a7bc8f4e9314026bfd8573929e06da7/Untitled.png)

[Features](OP%20Fractal%20Stack%202%200%206a7bc8f4e9314026bfd8573929e06da7/Features%202b3e8ddf2715428e8ea04c6a8d6b1c21.csv)