# Firmament

Tags: Tools
Description: A community cooperating system for independent computing infrastructure

## Overview

A system for empowering communities with fractal cooperation, consensus games, and independent community computing infrastructure

You can find more details at [https://optimystics.io/firmament](https://optimystics.io/firmament)

![Untitled](Firmament%2082d5bbb2721f4e4cabbdf93adf2107d0/Untitled.png)