# Optimism Fractal

Tags: Events and Shows
Description: A community dedicated to fostering collaboration and awarding public goods creators in the Optimism Collective.

## Overview

A community dedicated to fostering collaboration and awarding public goods creators in the Optimism Collective.

Learn more at [OptimismFractal.com](http://OptimismFractal.com) 

![twitter cover photo2 edencreators_no_objects_859cbcae-19c3-40d4-9a95-2b6720f2f77f121212.png](Optimism%20Fractal%20eaecce61afb94736b860213856108026/twitter_cover_photo2_edencreators_no_objects_859cbcae-19c3-40d4-9a95-2b6720f2f77f121212.png)