# Fractal App

Tags: Tools
Description: A comprehensive web app for fractal communities

## Overview

A comprehensive web app for fractal communities and organizations. 

Features include WebRTC integration for video meetings, automatic video recording, member induction system, custom token distribution, RESPECT distribution, dynamic permission system of the contract based on member’s Respect, on-chain randomization of members into breakout groups during weekly meetings, and on-chain ranking validation.

Learn more at [https://optimystics.io/fractal-app](https://optimystics.io/fractal-app)

![Untitled](Fractal%20App%20dbba77a83ab743f0a7139ecf747110f5/Untitled.png)