# Fractal Apple/Sunny Show

Tags: Events and Shows
Description: An educational and musical live show about public goods in Optimism

## Overview

An educational and musical live show about public goods and games on Optimism.

You can see an example of a similar show that we created here: [https://edencreators.com/apple](https://edencreators.com/apple)

[https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/c47b95d8-dd33-4e5b-b08a-2476af8bbd19/3_v14144/w=3840,quality=80](https://images.spr.so/cdn-cgi/imagedelivery/j42No7y-dcokJuNgXeA0ig/c47b95d8-dd33-4e5b-b08a-2476af8bbd19/3_v14144/w=3840,quality=80)

## [**Fractal Apple #3: A Tale of Public Goods!**](https://edencreators.com/apple/3)

Blimey! Dan and Rosmari embark on a mythic quest to empower communities, fund public goods, and sing hearty Irish songs! 🍀

[https://www.youtube.com/watch?v=N0z4OX3H-bE](https://www.youtube.com/watch?v=N0z4OX3H-bE)

[data:image/svg+xml,%3csvg%20xmlns=%27http://www.w3.org/2000/svg%27%20version=%271.1%27%20width=%27432%27%20height=%2794.8785046728972%27/%3e](data:image/svg+xml,%3csvg%20xmlns=%27http://www.w3.org/2000/svg%27%20version=%271.1%27%20width=%27432%27%20height=%2794.8785046728972%27/%3e)

## **Fractal Apple #2: The Jolly, Giving Spirit!**

It's the most wonderful time of the year! Join us as Dan shares the holiday spirit, play classic carols, and gives 500 EOS to public goods creators on Pomelo! 🎄