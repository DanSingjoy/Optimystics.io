# Cagendas

Tags: Tools
Description: A social coordination game that helps communities create agendas, choose discussion topics, and make decisions together

## Overview

A social coordination game that helps communities create agendas, choose discussion topics, and make decisions together

Learn more at [EdenCreators.com/cagendas](http://EdenCreators.com/cagendas) 

![Untitled](Cagendas%20352c52eed95a4549b8b7e6a9c72bca91/Untitled.png)