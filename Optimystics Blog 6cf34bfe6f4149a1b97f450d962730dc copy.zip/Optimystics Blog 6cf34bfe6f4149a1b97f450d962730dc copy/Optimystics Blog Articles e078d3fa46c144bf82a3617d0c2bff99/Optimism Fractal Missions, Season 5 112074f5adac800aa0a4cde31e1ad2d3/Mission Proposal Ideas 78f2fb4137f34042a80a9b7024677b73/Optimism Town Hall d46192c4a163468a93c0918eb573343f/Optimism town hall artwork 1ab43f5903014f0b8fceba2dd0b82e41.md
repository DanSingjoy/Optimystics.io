# Optimism town hall artwork

[https://x.com/ens_dao/status/1735012707751837945?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/ens_dao/status/1735012707751837945?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)

[https://x.com/ens_dao/status/1735012707751837945?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/ens_dao/status/1735012707751837945?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)