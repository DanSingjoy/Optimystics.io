# Creator Talk

Tags: Events and Shows
Description: A talk show about creativity, collaboration, and Optimism

## Overview

Creators talk about creativity, collaboration, and Optimism. Hosted by [Dan Singjoy](https://twitter.com/DanSingjoy).

![creator talk 1 waverider71 moving5.png](Creator%20Talk%20622a4d2f87384666b01bb3391a42aaaf/creator_talk_1_waverider71_moving5.png)

[CreatorTalk.Show](http://CreatorTalk.Show) - fix site

[https://www.youtube.com/watch?v=ufnHMt2QRPM](https://www.youtube.com/watch?v=ufnHMt2QRPM)

[https://www.youtube.com/watch?v=rzDWtE8A_58](https://www.youtube.com/watch?v=rzDWtE8A_58)

[https://www.youtube.com/watch?v=SagAwK2md0M](https://www.youtube.com/watch?v=SagAwK2md0M)