# https://app.fractalframework.xyz/ might be something similar to Optimism Fractal or fractally in general?

AI summary: The text describes Fractal, a platform that extends Safe treasuries into on-chain hierarchies of permissions, token flows, and governance, allowing teams to operate with on-chain efficiency and choose governance structures.
Published?: No
URL: https://app.fractalframework.xyz/

![hero_image.png](https%20app%20fractalframework%20xyz%20might%20be%20something%20%2022e5dba407d14dbdabf52fdca1b10a0a/hero_image.png)

Are you outgrowing your Multisig? Fractal extends Safe treasuries into on-chain hierarchies of permissions, token flows, and governance.

Structure

Start with any Safe Multisig. Connect teams in flexible sub-Safe hierarchies for agile delivery.

Operate

Unleash on-chain efficiency with reuseable, streamed, and permissioned transactions.

Govern

Choose a governance per sub-Safe. Create and authorize proposals. Decentralize on any timeline.

Explore the Docs to see how Fractal works

Featured Organizations

Here are some projects using Fractal to convert their Safe Multisig into DAOs as they decentralize:

Decent DAO

We are an open-source collective that unites builders toward global decentralization.

[Explore >](https://app.fractalframework.xyz/daos/0xD26c85D435F02DaB8B220cd4D2d398f6f646e235)