# A History of Fractal Communities

Displays on Pages:: Intro to Optimism, Octant, Respect, Respect Game, Roots of Optimism Fractal, public goods games
AI summary: This document explores the history and development of fractal communities, particularly focusing on the Optimism Fractal initiative, which aims to foster collaboration and public good creation through innovative governance processes. It outlines the contributions of key figures in the field and highlights the potential benefits of these communities for collective growth and cooperation.
AI summary 1: This blog post delves into the rich history and evolution of fractal communities, culminating in the formation of Optimism Fractal. It highlights the foundational concepts and key figures that have shaped the development of fractal democracy, including the pioneering work of Daniel Larimer. The article explores how these communities have thrived through innovative frameworks and collaborative practices, emphasizing the profound benefits they offer to participants and the broader ecosystem. Readers will gain insights into the journey of fractal communities, their successes, challenges, and the exciting future that lies ahead as they continue to foster cooperation and public good creation.
Description: Explore the history of fractal communities that led to Optimism Fractal with hundreds of builders for over three years. This article provides an overview of our past work and how these fractal innovations can create profound benefits for all.
Published?: Yes

![fractal history.png](A%20History%20of%20Fractal%20Communities%20786c478b02c84177b02583cfe103eaec/fractal_history.png)

## Overview

Fractal communities are rooted in profound wisdom designed to help communities thrive and the [Respect Game](https://optimystics.io/respectgame) has been honed by hundreds of the world’s most talented builders for countless hours. You can explore a brief overview of our story below to gain a deeper understanding of how fractal communities playing Respect Game can provide profound benefits for all. This article was written by Dan Singjoy in late 2023.

**Table of Contents**

![fractal history 3.png](A%20History%20of%20Fractal%20Communities%20786c478b02c84177b02583cfe103eaec/fractal_history_3.png)

## Intro to Fractal Democracy

The initial concept for [fractal democracy](https://fractally.com/blog/what-is-fractal-democracy) was created by [Daniel Larimer](https://fractally.com/bio/daniel-larimer), a visionary innovator who interacted with Satoshi Nakamoto in 2009 and invented the concept of [DACs](https://blog.ethereum.org/2014/05/06/daos-dacs-das-and-more-an-incomplete-terminology-guide) (aka DAOs) as Decentralized Autonomous Companies in 2013. Daniel is a prolific founder who created the world’s first decentralized exchange (Bitshares), the first stablecoin (BitUSD), the first Web3 social media app (steemit/hive), and designed the software for the largest ICO of all time (EOS). 

Each of these projects were among the world’s most successful blockchain projects for a period of time and continue to grow today with decentralized, autonomous communities of countless talented builders. These innovations provided immense inspiration for industry leaders and paved the path for the largest sectors of Web3 today. You can learn more about each of these projects and Daniel’s outstanding track record in this [infographic](https://optimystics.io/daniel-larimer).

![curating_more_equal_animals_122.png](A%20History%20of%20Fractal%20Communities%20786c478b02c84177b02583cfe103eaec/curating_more_equal_animals_122.png)

## More Equal Animals & The Roots of Eden

In 2021 Daniel Larimer wrote a revelatory book called [More Equal Animals: The Subtle Art of True Democracy](https://moreequalanimals.com/posts/book-launch), which provided a blueprint for humanity to cooperate peacefully with a novel concept called fractal democracy. You can listen to the [audiobook](https://www.youtube.com/watch?v=xepUoQbOzr4&t=10s&pp=ygUSbW9yZSBlcXVhbCBhbmltYWxz) and find more resources in this [article](http://edencreators.com/mea). 

This book inspired the formation of [Eden on EOS](https://www.edenoneos.com/), a community with hundreds of members who have been pioneering fractal democracy with [Eden Elections](https://www.edenelections.com/) for over two years. This community attracted over 400 members and [raised](https://medium.com/edenoneos/first-blockchain-election-using-eden-on-eos-receives-grant-from-eos-foundation-3447221d8980) approximately $1.5 million to distribute for builders via onchain fractal democracy elections. For a high level overview introduction, you can watch this [summary](https://www.youtube.com/watch?v=jh5o7yLojqU) by a community filmmaker, an election [recap](https://youtu.be/dVHW2-frxz8?si=n1DnYYU5vW2gyqTH) from prominent a news outlet, and a [news show](https://www.youtube.com/live/g5Qxh8ZVPDw?si=wbSFpiGO_ObeADS9) hosted by Dan Singjoy following his election as a chief delegate. 

For a more detailed exploration of how this community provided enormous inspiration for many builders, you can watch the first election with 182 registrants [here](https://www.youtube.com/live/rP-1A9rL2ro?si=n604OEQYbNAcSNAD), many historic [videos](https://www.youtube.com/@EdenOnEOS/featured) on the original youtube channel, and many more in our [repository](https://edencreators.com/dams#905e1b1bfe3a44288b89b99481208475) of YouTube playlists. 

![eden cooperating since222.png](A%20History%20of%20Fractal%20Communities%20786c478b02c84177b02583cfe103eaec/eden_cooperating_since222.png)

## Going Fractally

The learnings from these experiments inspired Daniel Larimer’s team to create [fractally](https://fractally.com/), a profoundly helpful framework for the next generation of DAOs. Their [keynote video](https://youtu.be/cJclki0MnnI?si=N61iI9eVQRcw_x4s&t=136) gives an excellent introduction and the [whitepaper](https://bit.ly/fractally-whitepaper) provides a manual for decentralized, autonomous communities to create public goods and mutual aid in ways that were never before possible. 

We collaborated closely with the fractally team and about 130 other participants in a 30 week experiment pioneering the fractally processes called the [Genesis Fractal](https://edencreators.com/genesisfractal). There was an average of 37 participants in each meeting and the large majority of participants experienced tremendous benefits. Our founder Dan Singjoy recorded videos of each weekly Genesis Fractal meeting (as you can see in this [playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lm1R8bZ9g4Lg5nyElSUYfVN)) and earned the third most respect in the consensus games, as you can see in a comprehensive [dashboard](https://t.me/gofractally/10791) created by an esteemed engineer in the community.

![Untitled](A%20History%20of%20Fractal%20Communities%20786c478b02c84177b02583cfe103eaec/Untitled.png)

## Eden Fractal

[Eden Fractal](http://EdenFractal.com) was founded in May of 2022. Many of the most respected members of the Genesis Fractal were cooperative visionaries who wanted to experiment with the new processes of Fractally in the Eden community. You can learn how Dan Singjoy started Eden Fractal and explore detailed show notes about our first meeting [here](https://edenfractal.com/1). 

The Eden Fractal community has met every week since then with an average of ten weekly participants and many of the community members have experienced life-changing benefits. Eden Fractal has hosted over 100 events as a grassroots, self-funded community and is trailblazing the future of collaboration for the benefit of all. The community inspired talented builders to create invaluable open source [tools](Optimystics%20Tools%20369941be584c452aac7ce45623b92d06.md) for cooperation and produce hundreds of educational [videos](https://www.youtube.com/playlist?list=PLa5URJF9l5lkX4t8YMZ7wytDZggdXeFor). You can also learn more about Eden Fractal in 50 [episodes](https://www.youtube.com/playlist?list=PLa5URJF9l5lkuncdjNnoOsFMMJtRFLuws) of Eden Town Hall. 

The Eden Fractal formed consensus on it’s [vision](https://edenfractal.com/vision) in late 2023 and it’s [mission](https://edenfractal.com/mission) in 2024. Since it’s inception, Eden Fractal has educated hundreds of people about fractal decision-making processes, fostered countless fruitful collaborations, and inspired the creation of dozens of fractal [communities](Fractal%20Communities%20f2787813deac4a3587874410c3745254.md).

- 
    
    more about Eden Fractal at [EdenFractal.com](http://EdenFractal.com) and watch discussions with community leaders
    
    Many of the most respected members of the Genesis Fractal were cooperative visionaries who wanted to experiment with the new processes of Fractally in the Eden community. You can learn how [Dan Singjoy](https://dansingjoy.com/) started Eden Fractal and explore detailed show notes about our first meeting [here](https://edenfractal.com/1). The Eden Fractal community has met every week since then with an average of 15 weekly participants and many of the community members have experienced immense benefits that changed their lives. Eden Fractal has created tremendous success for over 78 weeks as a grassroots, self-funded community of volunteers and is trailblazing the future of collaboration for the benefit of all. The community inspired Vlad, Tadas, and many other brilliant builders to create invaluable open source [tools](http://EdenCreators.com/tools) and architect new paradigms in human cooperation. A few notable milestones involving Optimism Fractal team members include the initiation of our [Eden+Fractal](https://edencreators.com/plus) consensus process created by Tadas, the proposal to start [Alien Worlds Fractal](https://edencreators.com/alienworldsfractal) by Vlad, the introduction of [Cagendas](https://edencreators.com/cagendas) and election of Dan as moderator in our [28th](https://edenfractal.com/28#06bc2809a32d4048be8a810880ff0fcc) meeting, and our introduction to Rosmari in the [35th meeting](https://edenfractal.com/35) (which also saw the introduction of [Fractalgram](https://edencreators.com/fractalgram)). You can watch every Eden Fractal meeting in this [playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lkX4t8YMZ7wytDZggdXeFor), read detailed show notes for many meetings [here](http://EdenFractal.com/videos), and explore articles linked on [EdenFractal.com](http://EdenFractal.com) for an overview of various public goods and (amazing experiences!) shared by Eden Fractal community members.
    

![eden fractal ocean 11115.png](A%20History%20of%20Fractal%20Communities%20786c478b02c84177b02583cfe103eaec/eden_fractal_ocean_11115.png)

## Gardening Troughs

Though our fractal consensus games have created profound benefits for over two years and we are on track to greatly empower all communities, the trajectory of our success was slowed by the environment where we’ve been growing. Most of our work was focused in the [Antelope](https://antelope.io/) (formerly EOS.io) ecosystem, which emerged from the largest ICO of all time in 2017 and has seen it’s flagship token (EOS) decrease in market value by over 97% after the company that conducted the ICO stopped supporting the network. As a result, there is a huge community of talented, veteran builders and a very limited amount of funding opportunities in the Antelope ecosystem.

The organic success of Eden Fractal is attributed to builders who have heroically volunteered thousands of hours and are intrinsically motivated by deep conviction in our ability to create positive change. A few other factors that hindered growth included time needed to refine our processes, the lack of compatibility with market leading EVM software, and the ability convey fractal democracy in a way that is easily accessible and fun for all. In late 2023, a group of leaders from the Eden Fractal community named the Optimystics created Optimism Fractal, which is now on the precipice of a major breakthrough in growth of fractal communities. Eden Fractal and Optimism Fractal are well positioned to create profound benefits for all.

- 
    
    For example, Eden Fractal bootstrapped it’s innovations for almost two years with less than $20k in self-funding from community members. 
    

![sprouting colorful hands55551.png](A%20History%20of%20Fractal%20Communities%20786c478b02c84177b02583cfe103eaec/sprouting_colorful_hands55551.png)

## Optimism Fractal

[Optimism Fractal](https://optimismfractal.com/) is a community dedicated to fostering collaboration and awarding public good creators on Optimism. We host weekly events where builders in Superchain network, promote their work, and evaluate each other’s impact with onchain attestations in an innovative social game. 

The Optimism Fractal community is pioneering the next generation of consensus processes to optimize collective governance with a council formed with [Respect](Respect%206357d339d30b425997f3da4dd6f75f32.md), a soulbound reputation token earned by helping Optimism. All events are recorded and produced with show notes for educational purposes, as you can [watch here](https://optimismfractal.com/videos). So far we’ve hosted 28 weekly events where 39 industry leaders have made hundreds of onchain attestations with Optimism Fractal software ([source](https://optimism.blockscout.com/token/0x53C9E3a44B08E7ECF3E8882996A500eb06c0C5CC?tab=token_transfers)). 

You’re welcome to join [weekly events](https://lu.ma/optimismfractal) on Thursdays at 17 UTC to participate in Optimism Fractal and explore many community projects our [notion site](https://bit.ly/optimismfractalnotion) to get more involved. Optimism Fractal developing in the perfect environment and the stage is now set for an epic adventure!

- 
    
    The original developers of Fractally decided to stop pursuing their original vision with the Genesis Fractal to focus on related initiatives for fractal cooperation called [Psinq](https://psinq.com/). Meanwhile, Eden Fractal has used a non-transferable form of respect and focused on building unique [innovations](https://edenfractal.com/61) to protect community members from legal liability. 
    
    In addition to a lack of funding, the regulatory climate has also introduced challenges that have slowed our growth. 
    

![[https://optimismfractal.com/](https://optimismfractal.com/)](A%20History%20of%20Fractal%20Communities%20786c478b02c84177b02583cfe103eaec/optimism_fractal_23_promo_image.png)

[https://optimismfractal.com/](https://optimismfractal.com/)

## Optimystic Future

The community of fractal enthusiasts volunteered for years to lay the seeds and nourish the growth of countless innovations that are profoundly helpful for all communities. Though tremendously successful on a grassroots level, their work didn’t have the right kind of environment to fully blossom. So many of our innovations are being developed like roots underneath the surface of a primordial garden and are nearly ready to emerge to create wonderful effects for all. 

After years of refining these models and demonstrating strong product-market fit with communities like Eden Fractal, the time is ripe for massive growth. We are stoked about how the [Optimism Collective](https://optimystics.io/blog/growing-with-optimism) and Ethereum can perfectly nourish this growth. We’re confident Optimism Fractal will rapidly blossom into a flourishing ecosystem under these ideal conditions. The synergies are truly unique here. For example, we can imagine so many exciting ways that RetroPitches and other exciting Optimism Fractal games can enhance RetroPGF.

By combining Optimism’s ethos of empowering builders who create public goods with our proven tools for coordinating with community consensus, we expect exponential results. The ‘ROI’ of fractal communities from a public goods perspective is incredibly high and we are very excited to see what can become possible with the philosophical alignment and ample funding opportunities in Optimism. We firmly believe this collaboration will unleash unprecedented creation of sustainable value for the entire world. The technology is mature, the community is ready, and we have the expertise to smoothly execute. 

We started [Optimism Fractal](https://optimismfractal.com/) in October of 2023 and built open-source [tools](https://optimystics.io/tools) to empower all communities with the Respect Game on EVM blockchains. The feedback from the Optimism and Ethereum communities has been incredible. It's as if millions of years of biological evolution have prepared the perfect conditions for a new species to propagate rapidly. We are thrilled to be on the precipice of a new paradigm and exponential breakthrough in how cooperative ecosystems are structured for the benefit of humanity.

![optimism fractal 1 thumbnail demo.png](A%20History%20of%20Fractal%20Communities%20786c478b02c84177b02583cfe103eaec/optimism_fractal_1_thumbnail_demo.png)

- 
    
    
    *Optimism Fractal provides a perfect place to collaborate with talented builders and earn awards for helping the Optimism Collective. You’re welcome to join our weekly [events](https://lu.ma/optimismfractal) on Thursdays at 17 UTC, watch our previous [episodes](https://optimystics.io/videos), and explore our [blog](http://optimystics.io/blog) to learn more about how Optimism Fractal can create profound benefits for the Optimism Collective.* 
    
    *We encourage you to explore our articles and videos about the [Respect Game](https://optimystics.io/respectgame) to gain a deeper understanding of how Optimism Fractal can enhance RetroPGF. We build open source tools to help all communities enjoy the benefits of the Respect Game and grow with Optimism. You can learn about our tools [here](https://optimystics.io/tools). We’d appreciate your support in our RetroPGF Grant. Feel free to reach out with any comments in our discord or the [forum post](https://gov.optimism.io/t/enhancing-retropgf-with-optimism-fractal/7175). Thank you for reading!*
    
    ## An Overview of our History and Future with Optimism
    
    Fractal communities are rooted in profound wisdom designed to help communities thrive and our processes have been honed by hundreds of the world’s most talented builders for countless hours. It’s helpful to learn about our history to better understand the immense potential of Eden Fractal, Optimism Fractal, and other communities cooperating with our innovative social games. We encourage you to explore a brief overview of our story below to gain a deeper understanding of how fractal communities will provide profound benefits for the Optimism Collective.
    
    The initial concept for fractal democracy was created by [Daniel Larimer](https://fractally.com/bio/daniel-larimer), a visionary innovator who interacted with Satoshi Nakamoto in 2009 and invented the concept of [DACs](https://blog.ethereum.org/2014/05/06/daos-dacs-das-and-more-an-incomplete-terminology-guide)/DAOs as Decentralized Autonomous Companies to describe Bitcoin in 2013. Daniel is a prolific founder who created the world’s first decentralized exchange (Bitshares), the first stablecoin (BitUSD), the first Web3 social media app (steemit/hive), and designed the software for the largest ICO of all time (EOS). Each of these projects were among the world’s most successful blockchain projects for a period of time and continue to grow today with decentralized, autonomous communities of countless talented builders. These innovations provided immense inspiration for industry leaders and paved the path for the largest sectors of Web3 today. You can learn more about each of these outstanding projects and Daniel’s track record in this [infographic](https://cdn.discordapp.com/attachments/974165882311946320/1153705492955271209/Meet-Fracallys-Founder-Daniel-Larimer-01312022-B.png).
    
    In 2021 Daniel Larimer wrote a revelatory book called [More Equal Animals: The Subtle Art of True Democracy](https://moreequalanimals.com/posts/book-launch), which provided a blueprint for humanity to cooperate peacefully with a novel concept called fractal democracy. This book inspired the formation of [Eden on EOS](https://www.edenoneos.com/), a community with hundreds of members who have been pioneering fractal democracy with upvote [elections](https://www.edenelections.com/) for over two years. For a high level overview introduction, you can watch this [summary](https://www.youtube.com/watch?v=jh5o7yLojqU) by a community filmmaker, an election [recap](https://youtu.be/dVHW2-frxz8?si=n1DnYYU5vW2gyqTH) from prominent a news outlet, and a [news show](https://www.youtube.com/live/g5Qxh8ZVPDw?si=wbSFpiGO_ObeADS9) hosted by Dan Singjoy following his election as a chief delegate. For a more detailed exploration of how this community provided enormous inspiration for many builders, you can watch the first election with 182 registrants [here](https://www.youtube.com/live/rP-1A9rL2ro?si=n604OEQYbNAcSNAD), many historic [videos](https://www.youtube.com/@EdenOnEOS/featured) on the original youtube channel, hundreds of hours of fascinating discussions with community leaders at our [Eden Town Halls](https://www.youtube.com/playlist?list=PLa5URJF9l5lkuncdjNnoOsFMMJtRFLuws), and many more in our [repository](https://edencreators.com/dams#905e1b1bfe3a44288b89b99481208475) of YouTube playlists. 
    
    The learnings from these experiments inspired Daniel Larimer’s team to create [fractally](https://fractally.com/), a profoundly helpful framework for the next generation of DAOs. Their [keynote video](https://youtu.be/cJclki0MnnI?si=N61iI9eVQRcw_x4s&t=136) gives an excellent introduction and the [whitepaper](https://fractally.com/whitepaper/fractally_en.pdf) provides a manual for decentralized, autonomous communities to create public goods and mutual aid in ways that were never before possible. We collaborated closely with the fractally team and about 130 other participants in a 30 week experiment pioneering the fractally processes called the [Genesis Fractal](https://edencreators.com/genesisfractal). There was an average of 40 participants in each meeting and the large majority of participants experienced tremendous benefits. Our founder Dan Singjoy recorded videos of each weekly Genesis Fractal meeting (as you can see in this [playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lm1R8bZ9g4Lg5nyElSUYfVN)) and earned the third most respect in the consensus games, as you can see in a comprehensive [dashboard](https://t.me/gofractally/10791) created by an esteemed engineer in the community.
    
    Many of the most respected members of the Genesis Fractal were cooperative visionaries who wanted to experiment with the new processes of Fractally in the Eden community. You can learn how Dan Singjoy started Eden Fractal and explore detailed show notes about our first meeting [here](https://edenfractal.com/1). The Eden Fractal community has met every week since then with an average of 15 weekly participants and many of the community members have experienced immense benefits that changed their lives. Eden Fractal has created tremendous success for over 78 weeks as a grassroots, self-funded community of volunteers and is trailblazing the future of collaboration for the benefit of all. The community inspired Vlad, Tadas, and many other brilliant builders to create invaluable open source [tools](http://EdenCreators.com/tools) for cooperation. You can learn more about Eden Fractal at [EdenFractal.com](http://EdenFractal.com).
    
    - 
        
        Many of the most respected members of the Genesis Fractal were cooperative visionaries who wanted to experiment with the new processes of Fractally in the Eden community. You can learn how [Dan Singjoy](https://dansingjoy.com/) started Eden Fractal and explore detailed show notes about our first meeting [here](https://edenfractal.com/1). The Eden Fractal community has met every week since then with an average of 15 weekly participants and many of the community members have experienced immense benefits that changed their lives. Eden Fractal has created tremendous success for over 78 weeks as a grassroots, self-funded community of volunteers and is trailblazing the future of collaboration for the benefit of all. The community inspired Vlad, Tadas, and many other brilliant builders to create invaluable open source [tools](http://EdenCreators.com/tools) and architect new paradigms in human cooperation. A few notable milestones involving Optimism Fractal team members include the initiation of our [Eden+Fractal](https://edencreators.com/plus) consensus process created by Tadas, the proposal to start [Alien Worlds Fractal](https://edencreators.com/alienworldsfractal) by Vlad, the introduction of [Cagendas](https://edencreators.com/cagendas) and election of Dan as moderator in our [28th](https://edenfractal.com/28#06bc2809a32d4048be8a810880ff0fcc) meeting, and our introduction to Rosmari in the [35th meeting](https://edenfractal.com/35) (which also saw the introduction of [Fractalgram](https://edencreators.com/fractalgram)). You can watch every Eden Fractal meeting in this [playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lkX4t8YMZ7wytDZggdXeFor), read detailed show notes for many meetings [here](http://EdenFractal.com/videos), and explore articles linked on [EdenFractal.com](http://EdenFractal.com) for an overview of various public goods and (amazing experiences!) shared by Eden Fractal community members.
        
    
    Though our fractal consensus games have created profound benefits for over two years and we are on track to greatly empower all communities, the trajectory of our success has been slowed by the environment where we are growing. Most of our work has focused in the [Antelope](https://antelope.io/) (formerly EOS.io) ecosystem, which emerged from the largest ICO of all time in 2017 and has seen it’s flagship token (EOS) decrease in market value by over 97% after the company that conducted the ICO stopped supporting the network. Whereas the EOS Network used to have a top four cryptocurrency with a market cap of over $18 billion, it now has approximately a 300x smaller market cap than ETH and far less funding available than the Ethereum ecosystem. As a result, there is a huge community of talented, veteran builders and a very limited amount of funding opportunities in the Antelope ecosystem. For example, Eden Fractal has bootstrapped all of our innovations for over a year with less than $10k in funding from community members. Our organic success is attributed to builders who have heroically volunteered thousands of hours and are intrinsically motivated by deep conviction in our ability to create positive change. In addition to a lack of funding, the regulatory climate has also introduced challenges that have slowed our growth. The original developers of Fractally decided to stop pursuing their original vision with the Genesis Fractal to focus on related initiatives for fractal cooperation called [Psinq](https://psinq.com/). Meanwhile, Eden Fractal has used a non-transferable form of respect and focused on building unique [innovations](https://edenfractal.com/61) to protect community members from legal liability.
    
    As a community of volunteers, we have laid the seeds and nourished the growth of countless innovations that are profoundly helpful for all communities. Though tremendously successful on a grassroots level, our work has not yet had the right kind of environment to fully blossom. So many of our innovations are being developed like roots underneath the surface of a primordial garden and are nearly ready to emerge to create wonderful effects for all. After years of refining these models and demonstrating strong product-market fit with communities like Eden Fractal, the time is ripe for massive growth. We are stoked about how Optimism can perfectly nourish this growth and we’re confident Optimism Fractal will rapidly blossom into a flourishing ecosystem under these ideal conditions. The synergies are truly unique here. For example, we can imagine so many exciting ways that RetroPitches and other exciting Optimism Fractal games can enhance RetroPGF…
    
    By combining Optimism’s ethos of empowering builders who create public goods with our proven tools for coordinating with community consensus, we expect exponential results. The ‘ROI’ of fractal communities from a public goods perspective is incredibly high and we are very excited to see what can become possible with the philosophical alignment and ample funding opportunities in Optimism. We firmly believe this collaboration will unleash unprecedented creation of sustainable value for the entire world. The technology is mature, the community is ready, and we have the expertise to smoothly execute. It's as if millions of years of biological evolution have prepared the perfect conditions for a new species to propagate rapidly. We are thrilled to be on the precipice of a new paradigm and exponential breakthrough in how cooperative ecosystems are structured for the benefit of humanity.
    
    ![edencreators_create_a_heart_shaped_and_optimistic_planet_with_t_d40434a5-cf74-4063-b50e-69a98eb033ab (1).png](../edencreators_create_a_heart_shaped_and_optimistic_planet_with_t_d40434a5-cf74-4063-b50e-69a98eb033ab_(1).png)
    

## Related Posts

[Untitled](A%20History%20of%20Fractal%20Communities%20786c478b02c84177b02583cfe103eaec/Untitled%20357c06d1fb1c492d89f7fe150b15eb73.csv)

- 
    
    
    ![[https://optimystics.io/blog/the-roots-of-optimism-fractal](https://optimystics.io/blog/the-roots-of-optimism-fractal)](../twitter_cover_photo2_edencreators_no_objects_859cbcae-19c3-40d4-9a95-2b6720f2f77f121212.png)
    
    [https://optimystics.io/blog/the-roots-of-optimism-fractal](https://optimystics.io/blog/the-roots-of-optimism-fractal)
    
    ### [The Roots of Optimism Fractal](https://optimystics.io/blog/the-roots-of-optimism-fractal)
    
    Optimism Fractal is rooted in deep wisdom and designed to help communities thrive. Our games have been rigorously honed by hundreds of talented builders. This article summarizes the development that led to Optimism Fractal 🌱
    
    ![[https://optimystics.io/blog/welcome-to-optimism-fractal](https://optimystics.io/blog/optimystic-articles/welcome-to-optimism-fractal)](../optimism_fractal_1_thumbnail_demo.png)
    
    [https://optimystics.io/blog/welcome-to-optimism-fractal](https://optimystics.io/blog/optimystic-articles/welcome-to-optimism-fractal)
    
    ### [Welcome to Optimism Fractal!](https://optimystics.io/blog/welcome-to-optimism-fractal)
    
    As sunlight shines, sunflowers bloom! In the first episode of Optimism Fractal, the Optimystics embark and introduce a fun consensus game to create profound benefits for the Optimism Collective! 🌻 🌞 🔴