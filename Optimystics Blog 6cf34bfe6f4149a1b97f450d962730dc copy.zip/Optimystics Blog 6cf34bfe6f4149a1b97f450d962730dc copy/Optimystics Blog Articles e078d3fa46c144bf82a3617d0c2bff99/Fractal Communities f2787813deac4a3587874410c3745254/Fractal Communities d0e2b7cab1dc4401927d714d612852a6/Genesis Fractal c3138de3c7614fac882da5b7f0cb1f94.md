# Genesis Fractal

Created: October 13, 2023 8:27 PM

The [ƒractally](http://fractally.com) team hosted a 30 week experiment Fractal with 130 participants called the [Genesis Fractal](https://edencreators.com/genesisfractal). There was an average of 40 participants in each meeting and the large majority of participants experienced life changing benefits. You can watch videos of each meeting in this [playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lm1R8bZ9g4Lg5nyElSUYfVN), find many exciting community developments in this draft [article](https://edencreators.com/growingfractally#ddb7417a10294cf1b83fd6d83dfba683), and see a comprehensive [dashboard](https://t.me/gofractally/10791) created by an esteemed engineer in the community.