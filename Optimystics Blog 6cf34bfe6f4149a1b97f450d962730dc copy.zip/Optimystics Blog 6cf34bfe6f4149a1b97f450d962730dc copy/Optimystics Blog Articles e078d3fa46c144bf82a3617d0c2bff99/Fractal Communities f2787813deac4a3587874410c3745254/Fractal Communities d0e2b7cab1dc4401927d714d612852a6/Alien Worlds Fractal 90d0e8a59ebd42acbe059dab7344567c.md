# Alien Worlds Fractal

Created: October 13, 2023 8:27 PM

Alien Worlds Fractal has hosted over 26 weekly meetings with an average attendance of about ten people in each meeting and over forty participants in total. You can learn many exciting details about Alien Worlds Fractal and watch the first season of meetings in this [article](https://edencreators.com/alienworldsfractal). You can see the onchain results in these accounts ([1](https://wax.bloks.io/tokens/FRACTAL-wax-fractal.moon) and [2](https://wax.bloks.io/tokens/RESPECT-wax-pollpollpoll)). 

Alien Worlds Fractal has made significant innovations in fractal cooperation, such as the introduction of automated MSIGS and new game styles described in this [article](https://medium.com/@vladislavhramtsov/introducing-consensus-games-to-alien-worlds-9d31b7cdafa2). You can see the unpublished meetings from the second season [here](https://drive.google.com/drive/folders/1ot15xXVlzv_oHKC2r5Vh_9jWsW43EYuQ?usp=sharing) and explore the [group chat](https://t.me/fractalienworlds/1) to see highly engaged community discussions. Alien Worlds Fractal is supported by the creator of Alien Worlds and he created smart contracts to enable Eden Fractal to provide automatic votes for Alien Worlds leaders via IBC, as you can see [here](https://edencreators.com/alienworldsfractal#311abee4fdb74e829f10876dcd9b8e56). 

Alien Worlds is the most popular Web3 game by many metrics, as you can see on [AlienWorlds.io](http://AlienWorlds.io) and [DappRadar](https://dappradar.com/dapp/alien-worlds).