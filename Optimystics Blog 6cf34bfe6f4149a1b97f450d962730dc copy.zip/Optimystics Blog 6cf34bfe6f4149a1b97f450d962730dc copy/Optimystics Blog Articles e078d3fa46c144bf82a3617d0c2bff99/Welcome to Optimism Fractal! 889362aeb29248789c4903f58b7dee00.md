# Welcome to Optimism Fractal!

Displays on Pages:: Intro to Optimism
AI summary: Optimism Fractal is a platform that introduces users to the concept of optimism and provides resources for personal growth and development.
Published?: No

[https://www.youtube.com/watch?v=UxZIcui76Po](https://www.youtube.com/watch?v=UxZIcui76Po)

As sunlight shines, sunflowers bloom! In the first episode of Optimism Fractal, the Optimystics embark and introduce a fun consensus game to create profound benefits for the Optimism Collective! 🌻 🌞 🔴

Date: October 27th, 2023

# Show Notes

You can RSVP [here](https://lu.ma/optimismfractal) and join our [discord](https://discord.gg/dJgrP8ekYC) to get in touch. You can find more details at [OptimismFractal.com](http://OptimismFractal.com). Enjoy!

**Table of Contents**

Hello fellow readers! Thanks for stopping by ✨

- 
    
    Looking for a story to dive in? We go through very interesting tails and explain how to play the Respect Game in our special first episode of Optimism Fractal, featuring our very own four heroes 🎩
    

## Introductory Posts

![[https://gov.optimism.io/t/introducing-optimism-fractal/6990](https://gov.optimism.io/t/introducing-optimism-fractal/6990)](../../OptimismFractal%20com%20c238e1244229466ba8b7753b74104b6f/Optimism%20Fractal%20Website%20Database%20f636c69e7a3a4435a2163516c9e87249/Welcome%20to%20Optimism%20Fractal!%201d84ce88811049529b52028686cc157c/Untitled.png)

[https://gov.optimism.io/t/introducing-optimism-fractal/6990](https://gov.optimism.io/t/introducing-optimism-fractal/6990)

# Short Clips

Optimystics produced several short clips from this meeting to help you understand the benefits of Optimism Fractal. You can check out the videos below to learn more and feel free to reach out with any questions 🙂

## Intro to the Respect Game

[https://youtu.be/RPxopnvzWlI](https://youtu.be/RPxopnvzWlI)

What is the Respect Game? The Optimystics provide an overview of the Respect Game rules and show you how to play! 🌻

Here’s an overview of how to play:

1. **Forming Groups**: Participants gather in randomized groups of three to six players. If there are many participants, they split into multiple groups. The Respect Game can accommodate any amount of players due to it’s fractal nature.

1. **Sharing Contributions**: Each person in the group gets a chance to share what they've done recently to help the community. Each participant can take up to 4 minutes to do this. This could be anything from creating content, building software, inviting friends, or other helpful activities for the Optimism Collective.

1. **Ranking and Consensus**: After everyone has shared their contributions, the group discusses and ranks each other’s work in order of helpfulness. The players try to rank who did the most to help the community in the past week, then who helped the second most, the third most, and so forth. In order for any players in the group to win, the players must reach consensus by at least 2/3rds of the group agreeing to the ranks.

1. **Awarding Respect**: Based on these rankings, Respect is distributed to each participant. The better your contribution is ranked, the more respect you earn. Respect is not ****transferable, meaning you keep them as a personal token of your contributions and they build up for each person over time.

1. **Optimistic Technology**: You can play the Respect Game without using special tools, but the game is better when using a blockchain. At Optimism Fractal, the results of these rankings and the distribution of respect points are recorded on the OP Mainnet. This ensures transparency and allows everyone to see the contributions and respect of each member.

1. **Ongoing Participation**: The game repeats with regular meetings where members share their latest contributions and receive more respect over time for continually growing Optimism.

You can learn more at [Optimystics.io/respectgame](http://Optimystics.io/respectgame).

## Benefits of the Respect Game

[https://youtu.be/HfOiUAM7X6w](https://youtu.be/HfOiUAM7X6w)

How can the Respect Game create profound benefits for all communities? We provide a glimpse of the mystical benefits of Respect!

Here are some benefits of the Respect Game:

1. **Respect Scores**: Respect tokens serve as an immutable reputation score on the OP Mainnet. This provides a decentralized and transparent, credibly neutral composable record of an individual's contributions and impact within the community.

1. **Collaboration and Networking**: The system encourages collaboration and networking in fun weekly meetings. By participating and contributing to the community, individuals earn respect points, which can lead to higher rankings and recognition. This process fosters a supportive and exciting environment where members are incentivized to contribute positively.

1. **Composability on Optimism**: The respect system is highly composable, meaning it can be integrated with various decentralized applications and tools. This flexibility allows for broad applications, including reward systems, decision-making processes, and verification of contributions.

1. **Awarding Public Goods Creators**: The respect points are particularly focused on rewarding those who contribute to public goods and the broader ecosystem. This aligns with the mission of fostering collaboration and supporting creators who contribute to open-source projects or other community-benefiting initiatives.

1. **Democratic and Credibly Neutral Process**: The allocation of respect points is designed to be democratic and credibly neutral. Participants are placed in random breakout rooms and measurements are taken by peers on a weekly basis to insure that the distribution of points is fair and based on genuine contributions.

1. **Collective Decision-Making**: Respect tokens can be used to elect leaders of the community. Respect can give power in collective decisions and providing a structured way for the community to govern itself. The smart contracts can be operated by community members with the most Respect.

1. **Fractal Democracy**: The concept of fractal democracy is used where decision-making is decentralized into smaller groups like branches of a tree. This allows for more efficient and representative decision-making processes.

1. **Encouraging Participation and Positive Contribution**: Simply joining and participating in the community in a positive manner can earn respect points, encouraging a broad range of contributions and engagement levels.

The Respect Game is designed to promote collaboration, contribution to public goods, and a democratic process of recognition and decision-making, all underpinned by a strong community ethos. 

You can learn more at [Optimystics.io/respect](http://Optimystics.io/respect).

## Optimism Fractal Tools

[https://www.youtube.com/watch?v=Ggpfi55eKEw&feature=youtu.be](https://www.youtube.com/watch?v=Ggpfi55eKEw&feature=youtu.be)

How do we use the OP Mainnet to play the Respect Game? We demonstrate Fractalgram, an intuitive app that helps communities reach consensus while having fun!

You can learn more at [Optimystics.io/tools](http://Optimystics.io/tools).

## Meet the Optimystics

[https://www.youtube.com/watch?v=T4k6QKXIrF4](https://www.youtube.com/watch?v=T4k6QKXIrF4)

You can learn more about us at [Optimystics.io/about](http://Optimystics.io/about).

# Timestamps

[0:00](https://www.youtube.com/watch?v=UxZIcui76Po&t=0s) Welcome!

[0:33](https://www.youtube.com/watch?v=UxZIcui76Po&t=33s) Agenda overview

[1:25](https://www.youtube.com/watch?v=UxZIcui76Po&t=85s) Dan highlights website and Discord for ways to learn more about Optimism Fractal

[3:22](https://www.youtube.com/watch?v=UxZIcui76Po&t=202s) Vlad introduces himself as a developer responsible for the front-end of Optimism Fractal, shares his background in EOS, and expresses excitement to enter the optimism ecosystem.

[4:32](https://www.youtube.com/watch?v=UxZIcui76Po&t=272s) Tadas introduces himself as the developer who wrote the smart contracts and configured Fractagram for Optimism Factal meetings. He shares his interest in governance and finding the best methods for consensus.

[5:42](https://www.youtube.com/watch?v=UxZIcui76Po&t=342s) Dan elaborates further on both Tadas and Vlad's backgrounds, all part of the Optimystic team

[6:26](https://www.youtube.com/watch?v=UxZIcui76Po&t=386s) Rosmari introduces herself as helping with marketing, branding, content creation, podcast production, and Eden fractal meeting production focused on educating about optimism in recent months

[8:31](https://www.youtube.com/watch?v=UxZIcui76Po&t=511s) Dan introduces himself as a creator, host, moderator, coordinator, and founder of Eden Fractal. Has been working with the fractal community to bring fractals to Optimism through Optimism Fractal

[11:20](https://www.youtube.com/watch?v=UxZIcui76Po&t=680s) Dan provides an in-depth explanation of how the respect game works, with participants sharing contributions, ranking each other, and reaching a consensus on contribution levels to reward creators

[13:14](https://www.youtube.com/watch?v=UxZIcui76Po&t=794s) Dan explains the ranking levels, how respect token awards contributors. Dan explains the process of submitting the results on-chain to record the rankings on Optimism's mainnet

[14:31](https://www.youtube.com/watch?v=UxZIcui76Po&t=871s) Vlad contributions are setting up the front-end rank submission web app, numerous discussions on preparing for Optimism Fractal

[15:13](https://www.youtube.com/watch?v=UxZIcui76Po&t=913s) Tadas’s contributions, the main focus was the smart contract for optimism fractal. Completed final touches, preparing Fractalgram tool.  Deployed smart contract to optimism main net. Writing documents on consensus process

[18:17](https://www.youtube.com/watch?v=UxZIcui76Po&t=1097s) Rosmari shares screen, brainstorming with Dan, website collaboration with Dan, artwork, show notes featuring optimism from Eden Fractal. Planning marketing, shared optimism fractal on multiple threads. Engaging more with the Optimism community

[23:12](https://www.youtube.com/watch?v=UxZIcui76Po&t=1392s) Dan shares his screen, contributions over the past week including building the website, and Twitter account, created a luma event link for RSVPs, zoom, crafting articles, RCP, discord, sharing info, media, producing educational videos, participating in the community call, curating info, Eden fractal intro and alignment

Dan discusses participating in the community call, asking about retro PGF, and introducing optimism fractal. Also working on the Optimystic website.

[32:39](https://www.youtube.com/watch?v=UxZIcui76Po&t=1959s) Dan shares screen on Vlad’s web app , used for consensus results, gives overview

[33:12](https://www.youtube.com/watch?v=UxZIcui76Po&t=1992s) Dan shares screen on Tadas’s Fractalgram app, gives overview

[35:20](https://www.youtube.com/watch?v=UxZIcui76Po&t=2120s) conversation between Dan and Tadas on the optimism project and work involved. Rosmari joins the conversation, excited about all we’re doing.

[42:19](https://www.youtube.com/watch?v=UxZIcui76Po&t=2539s) Tadas shares the screen for Fractalgram app, Dan explains how Fractalgram works.

[43:51](https://www.youtube.com/watch?v=UxZIcui76Po&t=2631s) Tadas provides a more in-depth explanation of how Fractalgram works to facilitate playing the respect game and submitting results on-chain.

[44:20](https://www.youtube.com/watch?v=UxZIcui76Po&t=2660s) Tadas goes through the ranking process using Fractalgram. The voting polls require a 2/3 majority of the group to reach consensus.

Rankings

Level 6 - Tadas, Level 5 - Dan, Level 4 - Rosmari, Level 3 - Vlad

[50:22](https://www.youtube.com/watch?v=UxZIcui76Po&t=3022s) Tadas submits the group's consensus results on-chain via the app built by Vlad

[54:29](https://www.youtube.com/watch?v=UxZIcui76Po&t=3269s) Dan notes this is the first official on-chain result for the optimism fractal tools. Excluding test results done by Tadas.

[55:34](https://www.youtube.com/watch?v=UxZIcui76Po&t=3334s) Tadas explains the main rule in 2/3 of the breakout room maintains through submission. Tadas and Dan comment on flexibility of using different consensus methods, mention all of the Optimism Fractal tools are open source

[58:54](https://www.youtube.com/watch?v=UxZIcui76Po&t=3534s) Dan provides a further explanation that respect token rewards contributions and is a composable primitive that can be integrated with other tools. The mission is to foster collaboration and award public goods creators in Optimism

[1:02:53](https://www.youtube.com/watch?v=UxZIcui76Po&t=3773s) Rosmari explains respect, a non-transferable token is distributed using the Fibonacci ratio based on contribution levels. Levels are all on-chain which is a natural proof of authentication of contributions

[1:04:24](https://www.youtube.com/watch?v=UxZIcui76Po&t=3864s) Tadas comments its importance is that people’s contributions are recognized.

[1:04:52](https://www.youtube.com/watch?v=UxZIcui76Po&t=3892s) Dan comments on everyone earning respect by joining. The more you do the higher you can get ranked, an excellent opportunity to have fun, network, recognition. Dan defines fractals and fractal democracy

[1:10:37](https://www.youtube.com/watch?v=UxZIcui76Po&t=4237s) Dan shares screen for websites, contacts, Optimism fractal, Eden fractal, Eden creators

[1:11:49](https://www.youtube.com/watch?v=UxZIcui76Po&t=4309s) Dan thanks all the participants and expresses excitement for the future of Optimism Fractal.

[1:11:53](https://www.youtube.com/watch?v=UxZIcui76Po&t=4313s) Dan, Tadas, and Rosmari give final thank yous to close out the meeting.

[1:14:19](https://www.youtube.com/watch?v=UxZIcui76Po&t=4459s) Grow Optimism! 🌱

# Tweets

![[https://twitter.com/OptimismFractal/status/1715230593221296138](https://twitter.com/OptimismFractal/status/1715230593221296138)](../../OptimismFractal%20com%20c238e1244229466ba8b7753b74104b6f/Optimism%20Fractal%20Website%20Database%20f636c69e7a3a4435a2163516c9e87249/Welcome%20to%20Optimism%20Fractal!%201d84ce88811049529b52028686cc157c/Screenshot_2023-10-27_at_0.04.49.png)

[https://twitter.com/OptimismFractal/status/1715230593221296138](https://twitter.com/OptimismFractal/status/1715230593221296138)

- Tweets
    
    [https://twitter.com/OptimismFractal/status/1715230595117183068](https://twitter.com/OptimismFractal/status/1715230595117183068)
    
    [https://twitter.com/OptimismFractal/status/1715230599072326012](https://twitter.com/OptimismFractal/status/1715230599072326012)
    
    [https://twitter.com/OptimismFractal/status/1715230603040223726](https://twitter.com/OptimismFractal/status/1715230603040223726)
    

# Related Posts

![[https://optimystics.io/blog/the-roots-of-optimism-fractal](https://optimystics.io/blog/the-roots-of-optimism-fractal)](../../OptimismFractal%20com%20c238e1244229466ba8b7753b74104b6f/Optimism%20Fractal%20Website%20Database%20f636c69e7a3a4435a2163516c9e87249/Welcome%20to%20Optimism%20Fractal!%201d84ce88811049529b52028686cc157c/twitter_cover_photo2_edencreators_no_objects_859cbcae-19c3-40d4-9a95-2b6720f2f77f121212.png)

[https://optimystics.io/blog/the-roots-of-optimism-fractal](https://optimystics.io/blog/the-roots-of-optimism-fractal)

### [The Roots of Optimism Fractal](https://optimystics.io/blog/the-roots-of-optimism-fractal)

Optimism Fractal is rooted in profound wisdom designed to help communities thrive. Our processes have been honed by hundreds of the world’s most talented builders for countless hours to make the best experiences possible 🌻

![[https://optimystics.io/blog/fractalhistory](https://optimystics.io/blog/fractalhistory)](../edencreators_create_a_heart_shaped_and_optimistic_planet_with_t_d40434a5-cf74-4063-b50e-69a98eb033ab_(1).png)

[https://optimystics.io/blog/fractalhistory](https://optimystics.io/blog/fractalhistory)

### [The History of Fractal Communities](https://optimystics.io/blog/fractalhistory)

We’ve been developing the consensus games and fractal governance processes of Optimism Fractal with hundreds of builders for over three years. This article provides an overview of our past work and how these fractal innovations can create profound benefits for all.

![[https://optimismfractal.com/2](https://optimismfractal.com/2)](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/optimism_fractal_2_thumbnail_demo.png)

[https://optimismfractal.com/2](https://optimismfractal.com/2)

### [OF 2: Illuminating Public Goods](https://optimismfractal.com/2)

What are the best ways to award public goods creators? In the second episode of Optimism Fractal we play the Respect Game and highlight the brilliant work of visionary Optimists 🌻 🔴 ✨