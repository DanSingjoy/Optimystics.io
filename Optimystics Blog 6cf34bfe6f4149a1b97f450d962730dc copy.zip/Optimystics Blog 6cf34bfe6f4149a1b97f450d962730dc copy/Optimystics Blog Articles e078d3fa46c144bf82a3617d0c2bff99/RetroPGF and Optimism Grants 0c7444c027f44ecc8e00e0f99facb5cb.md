# RetroPGF and Optimism Grants

Displays on Pages:: 2023, EF 68, Optimism Missions, RetroPGF, missions
AI summary: This article explores various grant opportunities within the Optimism ecosystem, including RetroPGF and the Grants Council, and shares insights from a live discussion among community leaders. It serves as an overview for those interested in funding opportunities and community engagement within Optimism.
AI summary 1: In this blog post, we delve into the various grant opportunities available within the Optimism ecosystem, highlighting key programs such as RetroPGF and the Grants Council. Designed to support innovative projects and initiatives, these grants aim to foster growth and collaboration within the community. We also reflect on insights gathered during a live discussion with community leaders, offering valuable perspectives on the potential impact of these grants. Join us as we explore how these resources can help drive progress and innovation in the world of Optimism.
Description: We explore a plethora of grant opportunities in the Optimism ecosystem, including RetroPGF, the Grants Council, and more!
Published?: Yes

---

![Ether's Phoenix small font.png](RetroPGF%20and%20Optimism%20Grants%200c7444c027f44ecc8e00e0f99facb5cb/Ethers_Phoenix_small_font.png)

### Let’s summon Ether’s Phoenix together! 🌱🔴🙌🏽

This article provides an overview of grant opportunities in the Optimism ecosystem, including RetroPGF, the Grants Council, and more. If you’re not yet familiar with Optimism, check out this educational [guide](https://optimystics.io/blog/growing-with-optimism). The following was written in September 2023 and provides timestamps from a live discussion with community leaders during the 68th Eden Fractal meeting, which you can see below or in the original [show notes](https://edenfractal.com/68). Enjoy!

### Exploring RetroPGF and Optimism Grants

The Optimism RetroPGF Round 3 was mentioned briefly at [1:30:28](https://youtu.be/QcWcW2meiTg?t=5428), and explored further starting at [2:22:22](https://youtu.be/QcWcW2meiTg?t=8542). You can read more in this curated [article](https://edencreators.com/optimism#950c8896a2d942a4bb18428d36bc5dea) on how to apply and more grant details. Also for a quick overview, you can go to [1:40:50](https://youtu.be/QcWcW2meiTg?t=6050) where RetroPGF is given a very quick topline view, whilst presented as the biggest opportunity all about retroactive public goods funding. This was done alongside a brief comparison with other Optimism grants shown on the grants [page](https://community.optimism.io/docs/governance/get-a-grant/#). 

The differences between the Optimism Grants Council and the Retroactive PGF grant program are discussed starting at [1:31:00](https://www.youtube.com/watch?v=QcWcW2meiTg&t=5460s). Details around the specifics about the Optimism Fractal proposal name and a more general grant overview of grant opportunities within the Optimism ecosystem at Perry's request was done around [1:37:19](https://youtu.be/QcWcW2meiTg?t=5839). Dan outlined that the Optimism Fractal proposal which was applied for at the Optimism Grants Council was specifically for the Builders Committee with the aim to bring builders into the ecosystem. Later on at [2:20:52](https://youtu.be/QcWcW2meiTg?t=8050), there are more details given for each of the grants including the Grants Council, Token House Missions, Foundation Missions (RFPs), The Partner Fund, The Partner Fund, and the lovely Retroactive Grants (Retro PGF).

Another useful grant resource is the [Optimismgrants.io](http://Optimismgrants.io) website made by a community member, which is a changelog and status page for the grant programs of the Optimism Collective. It allows for users to see, for example, which programs are currently open for applications and what their deadlines are. Please keep in mind that this isn’t verified by the Eden Fractal members, so we recommend always to use the main [Optimism.io](http://Optimism.io) website as a first reference point. A quick way to find the Grants page is once on the website to navigate to the Documentation [page](https://community.optimism.io/), then search   for ‘Grants’ on the page in order to reach the [page](https://community.optimism.io/docs/governance/get-a-grant/#) called ‘Get a Grant’. This one is the holy grail! It provides an overview of the grant opportunities happening in the Optimism Collective (you are welcome!) 

In case interested in Optimism’s use of governance, check out [1:40:50](https://youtu.be/QcWcW2meiTg?t=6050) when Dan presents about their government system which contains the Citizens House and about 200 badge holders, which grew from 30 in the first season! This is where the badge holders can vote to distribute the RetroPGF funds and allocate them to projects. You can read more information in this Optimism Collective mirror blog [post](https://optimism.mirror.xyz/gQWKlrDqHzdKPsB1iUnI-cVN3v0NvsWnazK7ajlt1fI).

### Full Episode

Watch the full episode below for all the exciting discussions about summoning Ether’s Phoenix and check out this [article](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6.md) for more details about the roots of Optimism Fractal!

[https://youtu.be/QcWcW2meiTg](https://youtu.be/QcWcW2meiTg)

**EF 68: Planting Optimism Fractal**

What are the best growth opportunities for communities creating public goods? We explore the new Optimism Fractal grant proposal, RetroPGF, and other grants to fund public goods creators in the Optimism Ecosystem 🌱