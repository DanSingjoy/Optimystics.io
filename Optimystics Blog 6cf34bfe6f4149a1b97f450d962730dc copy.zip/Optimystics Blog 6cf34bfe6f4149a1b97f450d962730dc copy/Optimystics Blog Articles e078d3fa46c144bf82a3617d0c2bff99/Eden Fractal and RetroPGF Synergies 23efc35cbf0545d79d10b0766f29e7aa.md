# Eden Fractal and RetroPGF Synergies

Displays on Pages:: EF 68
AI summary: This document explores the synergies between fractal communities and RetroPGF, highlighting how both approaches focus on retroactive funding and decision-making based on past contributions. It emphasizes the importance of community engagement through live ranking and consensus during events.
AI summary 1: In this blog post, we delve into the fascinating intersections between fractal communities and RetroPGF, highlighting the synergies that have emerged as both realms continue to evolve. As fractal communities draw inspiration from the successes of tools like Eden Fractal and Fractally, we explore how these innovations can be leveraged on the Optimism platform. Through a detailed examination of retroactive funding and decision-making processes, we uncover how contributions are recognized and rewarded based on past performance. Join us as we unpack these exciting developments and invite you to participate in our weekly events to learn more about the collaborative potential within these communities.
Description: Explore the many exciting similarities and synergies that fractal communities share with RetroPGF 🤝🏽
Published?: Yes

---

![optimism view small font.png](Eden%20Fractal%20and%20RetroPGF%20Synergies%2023efc35cbf0545d79d10b0766f29e7aa/optimism_view_small_font.png)

Over the past two years many fractal communities have been inspired by the success of [fractally](https://fractally.com/) and [Eden Fractal](https://edenfractal.com/) tools, games and governance. Now it’s time for fractal communities to start growing on Optimism. While diving into Optimism over the past months, we’re discovering many exciting synergies between RetroPGF and the Respect game. You can see an overview of some of these synergies below and join our weekly events to learn more!

### Retroactive Funding and Decision-Making

In this week’s event, we [explored](https://youtu.be/QcWcW2meiTg?t=8542) RetroPGF and discussed it’s nature as ‘backwards looking’, similarly to how Eden Fractal, ƒractally, and the Respect Game work. This is about funding builders based on what they have done in the past, or *retroactively*.

Watch this clip to learn more:

[https://youtu.be/9JA4u7y_INo?si=YPW1gfh7jwR0whfb](https://youtu.be/9JA4u7y_INo?si=YPW1gfh7jwR0whfb)

**This analogy is a central part of the Eden Fractal meetings as players rank each other’s contributions based on what is done in the past week or so.** This is done weekly in a live environment in the breakout rooms during the respect games and all participants rank each other starting from Level 6 and work their way downwards to Level 1 by ‘who contributed the most to Eden Fractal’. 

All vote and consensus is reached for each level (2/3s) in order to proceed. All players submit their consensus votes for each level on chain and then rewards get distributed based on the fibonacci ratio starting with Level 6 as the highest. A list of some fractal communities that have played these consensus games is presented during [44:53](https://www.youtube.com/watch?v=QcWcW2meiTg&t=2693s), which can help you understand with the scope of fractal opportunities. Dan Singjoy also gives example of great thinkers such as Vitalik Buterin and Dan Larimer that have inspired the idea about it being easier to allocate funding and decide how much things are helping **after you see it happened.** 

Contributions in fractal community are rewarded retroactively, which aligns with RetroPGF’s core model and beliefs about rewarding contributions on past performance. You can see the full discussion and event by watching the episode below!

[https://youtu.be/QcWcW2meiTg](https://youtu.be/QcWcW2meiTg)

**EF 68: Planting Optimism Fractal**

What are the best growth opportunities for communities creating public goods? We explore the new Optimism Fractal grant proposal, RetroPGF, and other grants to fund public goods creators in the Optimism Ecosystem 🌱

**Note**: *Some of this article was originally written and published in the [show notes](https://edenfractal.com/69) for Eden Fractal’s 68th episode.*