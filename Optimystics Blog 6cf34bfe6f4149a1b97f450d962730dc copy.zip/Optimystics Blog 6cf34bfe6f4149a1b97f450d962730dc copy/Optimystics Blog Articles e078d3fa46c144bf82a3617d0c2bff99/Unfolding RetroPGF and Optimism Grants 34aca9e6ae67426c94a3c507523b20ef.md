# Unfolding RetroPGF and Optimism Grants

Displays on Pages:: EF 67, Optimism Missions, RetroPGF, missions
AI summary: This document discusses grant opportunities within the Optimism ecosystem, highlighting the funding of public goods creators aligned with the principle of Impact=Profit.
AI summary 1: In this blog post, we delve into the exciting world of grant opportunities available within the Optimism ecosystem. With a focus on the Unfolding RetroPGF initiative, we’ll explore how these grants can support public goods creators and foster innovative projects. Our discussion emphasizes the principle that impact can drive profit, highlighting the potential for positive change through funding. Join us as we uncover the various ways to engage with and benefit from these unique financial opportunities.
Description: An exploration of the amazing grant opportunities within the Optimism ecosystem!
Published?: Yes

![retro pgf art small font.png](Unfolding%20RetroPGF%20and%20Optimism%20Grants%2034aca9e6ae67426c94a3c507523b20ef/retro_pgf_art_small_font.png)

Lets explore the amazing grant opportunities within the Optimism ecosystem and opportunities to fund public goods creators with the axiom of Impact=Profit.

For anyone that’s unfamiliar with [Optimism Collective](https://app.optimism.io/announcement), this is a new type of community designed to reward public goods and build a sustainable future for the open internet. Optimism is a pioneering [Ethereum](https://ethereum.org/en/) L2 community that is highly aligned with our values for creating public goods and improving human coordination for everyone’s benefit!

## Eden Fractal News

In case you’ve missed our 66th [episode](https://edenfractal.com/66), we encourage you to watch Dan Singjoy’s introductory presentation about Optimism at [1:50:20](https://www.youtube.com/watch?v=uDFrqdLmp8I&t=6620s), highlighting the Optimism Fractal grant [proposal](https://app.charmverse.io/op-grants/page-8947154553563161) to start a new community at [2:03:55](https://youtu.be/uDFrqdLmp8I?si=dBv3M_RWEoDbaaPi&t=7435). The introductory presentation provides an overview of brilliant innovations from The Optimism Collective, including [RetroPGF](https://app.optimism.io/retropgf), [Superchain](https://app.optimism.io/superchain), and the [Optimistic Vision](https://www.optimism.io/vision). 

This week our group of heroes discussed the newly curated draft [article](https://edencreators.com/optimism) about Optimism, encouraging a deep dive into a sunny pool of opportunities. A presentation at [26:36](https://www.youtube.com/watch?v=xX3n_bMigAM&t=1596s) gives Optimism topics’ a quick peak, being part of the main Eden Fractal Topics. You can taste the feeling of excitement as we delve into each one at [1:23:00](https://www.youtube.com/watch?v=xX3n_bMigAM&t=4980s) covering [Intro to Optimism](https://www.notion.so/Intro-to-Optimism-0e541139bba54bf7a8388f311d193b60?pvs=21), [Optimism RetroPGF](https://www.notion.so/Optimism-RetroPGF-Round-3-7e389f02851e4b99b5be27c14a2c6a72?pvs=21), and the [Optimism RFG 6 - Academic Research](https://www.notion.so/Optimism-RFG-6-Academic-Research-bdca0583f73e4387b11ff156d5808844?pvs=21) topics!

The academic grant was another opportunity discussed at [1:39:56](https://www.youtube.com/watch?v=xX3n_bMigAM&t=5996s), aligned with the work from members such as Jorge and Eric, which got interested to participate in future rounds. Dan provided links and educated the group on the Academic grant during [2:09:55](https://www.youtube.com/watch?v=xX3n_bMigAM&t=7795s), while also informing about the RetroPGF grant details between [2:09:55](https://youtu.be/xX3n_bMigAM?t=7795) - [2:10:49](https://youtu.be/xX3n_bMigAM?t=7849).

Watch the full episode below to see all the action and check out this [article](https://optimystics.io/blog/the-roots-of-optimism-fractal) to learn more about how Optimism Fractal sprouted from Eden Fractal. Enjoy!

[https://youtu.be/xX3n_bMigAM](https://youtu.be/xX3n_bMigAM)

**EF 67: Growing with Optimism**

What are the synergies between Eden Fractal and Optimism? In the next stage of our epic journey we explore opportunities to help humanity flourish and summon Ether’s Phoenix with innovations in retroactive public goods funding 🌱 🌞

Date: September 13th, 2023

**Note**: *Some of this article was originally written and published in the [show notes](https://edenfractal.com/67) for Eden Fractal’s 67th episode.*