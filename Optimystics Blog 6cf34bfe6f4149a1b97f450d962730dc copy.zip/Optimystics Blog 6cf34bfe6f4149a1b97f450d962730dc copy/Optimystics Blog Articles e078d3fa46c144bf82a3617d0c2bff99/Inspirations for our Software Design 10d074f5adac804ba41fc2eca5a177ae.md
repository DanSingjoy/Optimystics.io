# Inspirations for our Software Design

Displays on Pages:: Tools
AI summary: This document outlines the inspirations behind the Optimism Fractal software, highlighting innovative concepts and projects that have influenced its design. It emphasizes the importance of collective decision-making and provides links to related resources and websites for further exploration.
AI summary 1: In this blog post, we explore the various inspirations behind the design of our software at Optimism Fractal. We delve into the innovative concepts and projects that have shaped our vision, highlighting how they contribute to our mission of fostering a more equitable society. This overview not only showcases the foundational ideas that drive our work but also invites readers to engage with the resources and communities that align with our goals. Join us as we navigate through these inspirations and consider how they pave the way for the future of collective decision-making and fractal democracy.
Description: An overview innovative concepts and projects that inspired Optimism Fractal software.
Published?: Yes

![image.png](Inspirations%20for%20our%20Software%20Design%2010d074f5adac804ba41fc2eca5a177ae/image.png)

## Welcome

Optimism Fractal is the culmination of years of development from hundreds of leaders working to create a more free and fair society. 

Explore Optimism Fractal’s [rich history](https://optimystics.io/blog/fractalhistory) to discover how we’re creating the future of collective decision-making with fractal democracy and see how you can play a leading role below. Read the Optimism Fractal [details page](https://optimismfractal.com/details) to learn our core intents, protocol specifications, and how we cooperate according to our community consensus processes.

You can find the ƒractally [whitepaper](https://bit.ly/fractally-whitepaper) for an in-depth understanding of the potential of these tools. The tools featured on these sites have inspired much of our work at Optimystics and provide helpful resources for those interested in diving deeper other communities who are using similar tools.

### Related Websites

You can also learn more about our tools at the following websites:

- [OptimismFractal.com](http://OptimismFractal.com)

- [OptimismFractal.com/videos](http://OptimismFractal.com/videos)

- [EdenFractal.com](http://EdenFractal.com)

- [EdenFractal.com/videos](http://EdenFractal.com/videos)

- [Fractally.com](http://Fractally.com)

- ƒractally [whitepaper](https://bit.ly/fractally-whitepaper)

- [EdenElections.com](http://EdenElections.com)

- [EdenCreators.com/tools](http://EdenCreators.com/tools)

## Related Posts

Here are some of the apps, games, and tools that we’re building at Optimism Fractal:

[Untitled](Inspirations%20for%20our%20Software%20Design%2010d074f5adac804ba41fc2eca5a177ae/Untitled%2010d074f5adac80b5831cf4f59f5c1b06.csv)