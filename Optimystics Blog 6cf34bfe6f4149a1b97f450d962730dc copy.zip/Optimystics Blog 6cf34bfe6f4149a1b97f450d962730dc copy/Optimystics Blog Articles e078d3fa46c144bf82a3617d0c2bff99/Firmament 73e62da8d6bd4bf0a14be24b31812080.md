# Firmament

Displays on Pages:: Tools
AI summary: Firmament is an innovative system designed to empower communities through fractal cooperation, consensus games, and independent community computing infrastructure, utilizing technologies such as Git and IPFS. Currently in development, it aims to help communities achieve consensus and independence with minimal reliance on external infrastructure.
AI summary 1: This blog post introduces Firmament, an innovative system designed to empower communities through fractal cooperation and consensus mechanisms. By leveraging technologies such as Git, blockchains, and IPFS, Firmament aims to facilitate independent community computing, allowing groups to reach consensus on essential information while minimizing reliance on external infrastructure. The post covers the project's development by Tadas Vaitiekunas, its relationship with the Ethereum Virtual Machine and Optimism, and provides a collection of valuable resources related to Firmament and its associated initiatives.
Description: A system for empowering communities with fractal cooperation, consensus games, and independent community computing infrastructure using Git and IPFS
Published?: Yes

![firmament1345 copy.png](Firmament%2073e62da8d6bd4bf0a14be24b31812080/firmament1345_copy.png)

## Welcome

This article provides an introduction and resources about Firmament, an innovative system for empowering communities with fractal cooperation, consensus games, and independent community computing infrastructure. Enjoy!

**Table of Contents**

## Introduction

Firmament is envisioned as a comprehensive app designed to empower communities with fractal cooperation and unprecedented independence. 

Firmament combines elements of git, blockchains, and IPFS to enable communities to reach consensus on all types of information relevant for communities. Upon release, communities will be able to use Firmament with EVM compatible blockchains to determine community respect, websites, and files with minimal dependencies on external infrastructure providers. 

Tadas Vaitiekunas built many components of Firmament in 2023 and the project is now on pause while he focuses on [frapps](https://github.com/sim31/frapps).

## Relation to Optimism

Tadas has been building Firmament on the Ethereum Virtual Machine for over a year and has expressed interest in integrating the OP Stack. Firmament is in relatively early stages of development and Tadas decided to focus first on building the first OP Fractal tools for [Optimism Fractal](http://optimismfractal.com) and other communities on Optimism. You can explore the resources below to learn many exciting details and potential benefits of this application.

## Resources

![[https://edenfractal.com/40](https://edenfractal.com/40)](Firmament%2073e62da8d6bd4bf0a14be24b31812080/40_thumbnail.png)

[https://edenfractal.com/40](https://edenfractal.com/40)

### [EF 40: Firmament, Albedo, and Emergent Missions](https://edenfractal.com/40)

On git, blockchains, and IPFS. After playing Eden+Fractal with Fractalgram, Tadas presents brilliant technical visions to empower communities with Firmament & Albedo 💫 

---

Tadas shared a detailed presentation introducing Firmament, a revolutionary system for empowering communities with fractal cooperation and unprecedented independence!

Firmament combines elements of git, blockchains, and IPFS to enable communities to reach consensus on all types of information relevant for communities. Upon release, communities will be able to use Firmament with EVM compatible blockchains to determine community respect, websites, and files with minimal dependencies on external infrastructure providers.

You can watch Tadas share the presentation about Firmament at [1:12:13](https://youtu.be/tDp6khZZI4U?t=4333) and thoughtful discussions from community members for the following hour. You can learn more by reading the slides of the [presentation](https://docs.google.com/presentation/d/14wQ9861ufLXCqdascm-ZW862qtEHArYzsI2vzvGwpVo/edit?usp=sharing) and see an early design of the app [here](https://sim31.github.io/albedo-updates/#2023-02-13). Discussions also continued after the meeting in the live chat, where you can read insightful [messages](https://t.me/edenfractal/1134/1737) between Marco and Tadas. You can also watch Tadas’ recent interview with Patrick about Firmament [here](https://www.youtube.com/watch?v=kEUo_XbCWUo).

Firmament is closely related to Albedo, which an innovative research initiative that Tadas is building to help communities cooperate. You can learn more about Firmament and Albedo on the [Albedo Pomelo Page](https://pomelo.io/grants/albedo) and see frequent updates of progress [here](https://sim31.github.io/albedo-updates/). Lastly, you can learn more about Albedo in this Eden Creators [article](https://edencreators.com/albedo) and learn more about a related app from Tadas called [Fractalgram](https://edenfractal.com/36#737afbddb529489684b873ad1ac4d5e0).

![Untitled](Firmament%2073e62da8d6bd4bf0a14be24b31812080/Untitled.png)

### Antelope Workshop Interview

[https://youtu.be/kEUo_XbCWUo](https://youtu.be/kEUo_XbCWUo)

Interview Timestamps (provided by the interview, Patrick from NovaCrypto)

[00:00](https://www.youtube.com/watch?v=kEUo_XbCWUo&t=0s) - Start

[01:38](https://www.youtube.com/watch?v=kEUo_XbCWUo&t=98s) - Before Albedo and Firmament

[03:57](https://www.youtube.com/watch?v=kEUo_XbCWUo&t=237s) - What are the problems we are solving?

[06:30](https://www.youtube.com/watch?v=kEUo_XbCWUo&t=390s) - What is the difference between Albedo and Firmament?

[09:31](https://www.youtube.com/watch?v=kEUo_XbCWUo&t=571s) - What is Firmament?

[11:18](https://www.youtube.com/watch?v=kEUo_XbCWUo&t=678s) - What is at the core of the firmament protocol?

[13:52](https://www.youtube.com/watch?v=kEUo_XbCWUo&t=832s) - The front-end app for Firmament

[14:26](https://www.youtube.com/watch?v=kEUo_XbCWUo&t=866s) - How will Firmchain work?

[16:45](https://www.youtube.com/watch?v=kEUo_XbCWUo&t=1005s) - How Firmchain will use IPFS?

[17:22](https://www.youtube.com/watch?v=kEUo_XbCWUo&t=1042s) - What can be push on Firmchain from a Web Browser? A directory of a DAO

[19:05](https://www.youtube.com/watch?v=kEUo_XbCWUo&t=1145s) - Maximizing the number of nodes?

[21:08](https://www.youtube.com/watch?v=kEUo_XbCWUo&t=1268s) - Albedo is the incubator of Firmament

[22:14](https://www.youtube.com/watch?v=kEUo_XbCWUo&t=1334s) - Next steps

[33:15](https://www.youtube.com/watch?v=kEUo_XbCWUo&t=1995s) - Albedo & Firmament on Pomelo

[42:40](https://www.youtube.com/watch?v=kEUo_XbCWUo&t=2560s) - Time to conclude

- 

## Repositories

- [FirmContracts](https://github.com/sim31/firmcontracts)

- [FirmSignal](https://github.com/sim31/firmsignal)

## Updates Journal

Tadas also shares frequent updates about his progress with Albedo and Firmament, which you can read [here](https://sim31.github.io/albedo-updates/).

## Related Posts

![[https://edencreators.com/albedo](https://edencreators.com/albedo)](Respect%20Trees%2051d05fc8eb774975adbbc415a899ec1a/1cf01135-f599-4a52-920e-4e6e4e132555.webp)

[https://edencreators.com/albedo](https://edencreators.com/albedo)

### [Albedo](https://edencreators.com/albedo)

An innovative research initiative by Tadas to grow communities with fractal cooperation.

![[https://optimystics.io/fractalgram](https://optimystics.io/fractalgram)](Respect%20Trees%2051d05fc8eb774975adbbc415a899ec1a/fractalgram_blue_2.png)

[https://optimystics.io/fractalgram](https://optimystics.io/fractalgram)

### [Fractalgram](https://optimystics.io/fractalgram)

An intuitive telegram app created by Tadas that helps communities cooperate and enjoy the Respect Game!

![[https://edencreators.com/edenplusfractal](https://edencreators.com/edenplusfractal)](Respect%20Trees%2051d05fc8eb774975adbbc415a899ec1a/edenfractal_translucent22_copy.png)

[https://edencreators.com/edenplusfractal](https://edencreators.com/edenplusfractal)

### [Eden + Fractal](https://edencreators.com/edenplusfractal)

An innovative, fractal consensus process created by Tadas that helps communities cooperate!

![[https://edencreators.com/creatortalk/creator-talk-episode-1-tadas](https://edencreators.com/creatortalk/creator-talk-episode-1-tadas)](Respect%20Trees%2051d05fc8eb774975adbbc415a899ec1a/centered_and_brighter_tadas_2.png)

[https://edencreators.com/creatortalk/creator-talk-episode-1-tadas](https://edencreators.com/creatortalk/creator-talk-episode-1-tadas)

### [Creator Talk | Eden+Fractal | Episode 1](https://edencreators.com/creatortalk/creator-talk-episode-1-tadas)

Dan Singjoy speaks with Tadas Vaitiekunas, a visionary builder who creates wonderful ways for people to cooperate. They discuss Eden+Fractal, an innovative consensus game that empowers communities with profound potential for creative collaboration!