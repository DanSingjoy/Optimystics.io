# Community Delegation

AI summary: This article discusses how Optimism Fractal can improve governance participation and decentralization within the Optimism Token House through onchain community delegation and the concept of community delegates. It highlights prior experiments, the role of the Optimism Fractal council, and the potential benefits of using reputation tokens for decision-making.
AI summary 1: In this blog post, we explore the concept of community delegation within the Optimism Token House, emphasizing the innovative role of Optimism Fractal in enhancing governance participation. As decentralized communities strive to have a voice, the article outlines how onchain community delegation can empower individuals to become delegates and contribute to a more inclusive decision-making process. We delve into past experiments, the establishment of the Optimism Fractal Council, and the tools being developed to facilitate effective governance. This piece aims to shed light on the transformative potential of community delegation in achieving a more engaged and decentralized governance structure.
Published?: No

![image.png](Community%20Delegation%20112074f5adac80cbb06fd76395f4b421/image.png)

## Welcome

This article provides an overview of how Optimism Fractal can help improve the Optimism Token House with onchain community delegation, allowing truly decentralized community’s to become delegates. Please note that it’s an early work in progress and will be updated soon. Enjoy!

**Table of Contents**

# Optimism Fractal Governance Overview

**Trailblazing The Future of Governance:** Optimism Fractal is the culmination of years of development from hundreds of leaders working to create a more free and fair society. 

Explore Optimism Fractal’s [rich history](https://optimystics.io/blog/fractalhistory) to discover how we’re creating the future of collective decision-making with fractal democracy and see how you can play a leading role below. Read our [details page](https://optimismfractal.com/details) to learn our core intents, protocol specifications, and how we cooperate according to our community consensus processes.

# How can Optimism Fractal Enhance the Token House?

The following is an overview of how Optimism Fractal can help increase governance participation,  OP delegation, and decentralization with Optimism Fractal. This first section will focus specifically on the idea of ‘community delegates’ formed using fractal governance processes.

## Community Delegation

### Prior Experiments in Delegation

Last year we experimented with a somewhat similar arrangement where the founder of a leading onchain metaverse game called [Alien Worlds](https://alienworlds.io/) delegated a few hundred thousand dollars worth of his game tokens to the Eden Fractal community and we voted on how to allocate his voting power together with our fractal governance processes. You can find more details and videos about this [here](https://edencreators.com/alienworldsfractal#block-311abee4fdb74e829f10876dcd9b8e56).

These kinds of ‘decentralized delegate’ solutions can be a excellent way to increase engagement in Optimism governance, foster more participation from delegates with smaller stake, harness the collective wisdom of the crowd, and contribute to the decentralization of the Superchain. The process of [fractal democracy](https://fractally.com/blog/what-is-fractal-democracy) can be profoundly helpful for the Collective and this sort of decentralized community delegation could be a great way to implement it into the Token House.

![[https://edencreators.com/alienworldsfractal#block-311abee4fdb74e829f10876dcd9b8e56](https://edencreators.com/alienworldsfractal#block-311abee4fdb74e829f10876dcd9b8e56)](Community%20Delegation%20112074f5adac80cbb06fd76395f4b421/image%201.png)

[https://edencreators.com/alienworldsfractal#block-311abee4fdb74e829f10876dcd9b8e56](https://edencreators.com/alienworldsfractal#block-311abee4fdb74e829f10876dcd9b8e56)

### Optimism Fractal Council

The [Optimism Fractal council](https://optimismfractal.com/council) is a pioneering governance body that uses Respect to empower collective decision-making and coordinate the future of fractal democracy on the Superchain. It  could potentially serve as a sort of decentralized delegate to enable greater participation and engagement in Optimism governance. 

![optimism fractal sages council1.png](Community%20Delegation%20112074f5adac80cbb06fd76395f4b421/optimism_fractal_sages_council1.png)

### Onchain Community Delegation with OREC

In addition, several developers in the Optimism Fractal community are building applications that will enable any communities or organizations to manage Optimism accounts with reputation tokens (such as [Respect](https://optimystics.io/respect)) in a fully onchain, decentralized, and democratic manner. 

One example of such software is [ORDAO](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f.md) and [OREC](OREC%20101074f5adac80adaff5ec3442ec8f89.md), which is short for Optimistic Respect-based Executive Contract and allows people to vote with Respect with an innovative ‘optimistic quorum’ mechanism. OREC is now being tested on the OP Mainnet and we can imagine many ways that they can be very beneficial for both the Token and Citizens’ Houses. 

In addition to Optimism Fractal, these open-source tools can enable many other communities to serve similar roles as the Anti-Capture Commission and could eventually be integrated into the OP Stack (if the Collective would like).

![[https://optimystics.io/ordao](https://optimystics.io/ordao)](Community%20Delegation%20112074f5adac80cbb06fd76395f4b421/ordao_blog_thumbnail_1.png)

[https://optimystics.io/ordao](https://optimystics.io/ordao)

## Comparables

Here are a couple examples of somewhat similar ‘community delegates’. While these each provide some benefits, neither provides the amount of decentralization, independence, and coordination that is possible with ORDAO and fractal governance.

[Anti-Capture Commission](Community%20Delegation%20112074f5adac80cbb06fd76395f4b421/Anti-Capture%20Commission%20112074f5adac803fbefdcb3bcef7780d.md) 

[Event Horizon](Community%20Delegation%20112074f5adac80cbb06fd76395f4b421/Event%20Horizon%20112074f5adac8091aa95da810d707d32.md) 

# Other Benefits for the Token House

Please keep in mind that this article is an early work in progress and will be updated soon. Optimism Fractal provides many other benefits for the Token House, such as connecting delegates and delegators, increasing educational awareness, and attracting builders. You can explore more about this [here](https://app.charmverse.io/op-grants/eden-creators-videos-5662222309650244). 

# Related Articles

### General Token House Info

You can also explore the following for more details about the Token House.

[The Future of Optimism Governance](https://optimism.mirror.xyz/PLrAQgE1EGRo7GRrFoztplFChnUZda4DFGW3dkQayxY)

[Token House Overview | Optimism Docs](https://community.optimism.io/token-house/token-house-overview)

![image.png](Community%20Delegation%20112074f5adac80cbb06fd76395f4b421/image%202.png)

### Optimystics Blog

[Untitled](Community%20Delegation%20112074f5adac80cbb06fd76395f4b421/Untitled%20112074f5adac8035917af792a13f5b78.csv)

- 
    
    ![image.png](Community%20Delegation%20112074f5adac80cbb06fd76395f4b421/image%203.png)