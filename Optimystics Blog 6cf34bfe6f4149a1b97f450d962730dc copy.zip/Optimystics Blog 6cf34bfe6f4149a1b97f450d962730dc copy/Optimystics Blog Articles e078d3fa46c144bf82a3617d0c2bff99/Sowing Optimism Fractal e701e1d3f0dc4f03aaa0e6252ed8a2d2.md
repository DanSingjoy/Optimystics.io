# Sowing Optimism Fractal

Displays on Pages:: 2023, EF 69, Optimism Missions, Roots of Optimism Fractal, missions
AI summary: The "Sowing Optimism Fractal" discusses the efforts of the Optimystics in nurturing the Optimism Fractal initiative to foster a more regenerative society through the Optimism Collective. It highlights their dedication to crafting impactful projects and educational efforts.
AI summary 1: In this blog post, we explore the journey of nurturing the Optimism Fractal and its mission to educate individuals about the Optimism Collective. Through a series of initiatives aimed at fostering a more regenerative society, the Optimystics dedicate their efforts to crafting impactful projects that promote optimism and sustainability. Join us as we delve into the various aspects of the Optimism Fractal and its significance in creating a brighter future for all.
Description: A story of nurturing Optimism Fractal and educating about the Optimism Collective to create more regenerative society 🪴
Published?: Yes

![edencreators_clear_sky_with_stars_30241b73-752a-415c-8365-6cec1dd7ba2a.png](Sowing%20Optimism%20Fractal%20e701e1d3f0dc4f03aaa0e6252ed8a2d2/edencreators_clear_sky_with_stars_30241b73-752a-415c-8365-6cec1dd7ba2a.png)

From day to night, the Optimystics work tirelessly on crafting the best Optimism Fractal initiative and sewing the seeds for the Optimism Collective’s benefit!❣️

Dan Singjoy shared an exciting update about Optimism Fractal with the community in the 69th episode of Eden Fractal. You can see  an overview of the [proposal](https://app.charmverse.io/op-grants/page-8947154553563161) to the Optimism Grants Council that was shared during [21:44](https://youtu.be/hlmDnOkudTw?t=1304). This was also referencing back to a previous episode 68th when Dan presented more pages reflecting on the initial Rubic feedback by the reviewers. During EF 68, Dan went through [the Rubic](https://app.charmverse.io/op-grants/page-13972604474186334) for Proposals for builders sub-committee between [2:00:00](https://youtu.be/QcWcW2meiTg?t=7215) - [2:07:53](https://youtu.be/QcWcW2meiTg?t=7673), including the Builders’ Cycle 15 Preliminary [Roundup](https://gov.optimism.io/t/cycle-15-grants-preliminary-roundup/6772) review and the [finalists](https://gov.optimism.io/t/cycle-15-final-grants-roundup/6858), amongst which was Optimism Fractal. The updates were that the Grants Council did not approve the grant, as mentioned in this topics [page](https://www.notion.so/Optimism-Fractal-Updates-550e35b5309f444186ad120f84fdfd15?pvs=21) presented during the event. Despite that, the Optimism Fractal team is aiming to build the tools and start the first events in October.

The page was shared with the group at [1:48:16](https://www.youtube.com/watch?v=hlmDnOkudTw&t=1h48m16s), as a topic of high-interest alongside the Optimism and Eden collaborations. During [1:58:37](https://youtu.be/hlmDnOkudTw?t=7117), you can watch Dan sharing the high spirits of connection with Optimism into the fractal synergies and immense progress towards improving communities. At [1:59:00](https://youtu.be/hlmDnOkudTw?t=7142), the [Optimism Collective](https://app.optimism.io/announcement) was briefly touched on and described as a reflection of the broader community and systems poised to reward public goods contributions. All sharing a common vision with Eden Fractal. Following a group discussion, a deep dive on Optimism Collective was presented at [2:13:54](https://youtu.be/hlmDnOkudTw?t=8034), including the two governing houses: the Token House and the Citizens’ House government structure illustrated at [2:15:26](https://youtu.be/hlmDnOkudTw?t=8126), alongside the Optimism Vision at [2:15:59](https://youtu.be/hlmDnOkudTw?t=8159). 

We keep on getting inspired to learn, grow and build together. We encourage you to watch the full episode to see all the action and check out this [article](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6.md) for more details about the inception of Optimism Fractal. Let’s do it! 🌞

[https://youtu.be/hlmDnOkudTw?si=ugHfXSKuAt-AcaLG](https://youtu.be/hlmDnOkudTw?si=ugHfXSKuAt-AcaLG)

**EF 69: Regeneration Nation**

What are the best ways to build a more regenerative society? We explore Optimism Fractal, RetroPGF Round 3, and the Interplanetary Unconference to help create a peaceful, sustainable future for all 🌻 🙏🏽 🌞

## Note

*Much of this article was written in September, 2023 and originally published in the [show notes](https://edenfractal.com/69) for Eden Fractal’s 69th episode.*