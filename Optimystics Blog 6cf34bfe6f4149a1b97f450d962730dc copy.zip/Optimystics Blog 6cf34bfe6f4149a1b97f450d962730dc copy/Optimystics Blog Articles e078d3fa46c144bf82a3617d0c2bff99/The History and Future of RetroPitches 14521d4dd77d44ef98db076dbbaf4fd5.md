# The History and Future of RetroPitches

Displays on Pages:: RetroPitches, cignals, games, public goods games
AI summary: RetroPitches is a consensus game designed for Optimists to collaborate and promote their RetroPGF projects while fostering the principles of Optimism. The game encourages cooperative competition among participants to enhance public goods initiatives.
AI summary 1: In this blog post, we delve into the intriguing world of RetroPitches, a unique consensus game designed to foster collaboration among Optimists as they work together to promote their RetroPGF projects. This exploration highlights the innovative mechanics of RetroPitches and its potential impact on the growth of Optimism within the community. By examining its history and envisioning its future, we aim to shed light on how games like RetroPitches can enhance collective engagement and support the development of public goods.
Description: An exploration of RetroPitches, a consensus game where Optimists coopete to promote their RetroPGF projects and grow Optimism.
Published?: Yes
super:Link: https://optimystics.io/exploringretropitches

![Untitled](The%20History%20and%20Future%20of%20RetroPitches%2014521d4dd77d44ef98db076dbbaf4fd5/Untitled.png)