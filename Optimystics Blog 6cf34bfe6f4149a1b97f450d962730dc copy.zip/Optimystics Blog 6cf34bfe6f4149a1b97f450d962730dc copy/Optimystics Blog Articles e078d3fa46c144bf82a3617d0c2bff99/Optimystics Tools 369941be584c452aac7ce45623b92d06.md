# Optimystics Tools

Displays on Pages:: Firmament, Fractal App, Fractalgram, ORDAO, Octant, Our Fractal Journey to Optimism, Respect, Respect Game, RetroPitches, cignals, citizens' house, contribution measurement, enhancing retropgf, impact evaluation, missions, public goods games, token house
AI summary: The document outlines the tools and initiatives developed by Optimystics to empower communities through open-source software, particularly focusing on the Respect Game and fractal cooperation. It includes details on software applications, community engagement, and collaborative decision-making processes within the Optimism Fractal ecosystem.
AI summary 1: In this blog post, we explore the innovative tools developed by Optimystics, aimed at empowering communities through open-source software and consensus games on the OP Stack. The focus is on enhancing human coordination and recognizing the contributions of public goods creators. We delve into the foundational concepts behind the Respect Game and fractal cooperation, highlighting how these tools facilitate effective collaboration and decision-making within various communities. Additionally, we discuss the ongoing development of applications and features designed to optimize community engagement and governance, showcasing the potential benefits for organizations utilizing these resources. Join us as we navigate through the impactful initiatives that are shaping the future of collaborative governance and community empowerment.
Description: We build open-source tools for anyone to empower their community with consensus games on the OP Stack. We aim to improve human coordination and award public goods creators with Optimism. 
Published?: Yes

![optimystics tools 2.png](Optimystics%20Tools%20369941be584c452aac7ce45623b92d06/optimystics_tools_2.png)

## Welcome

We build open-source software that anyone can use to empower their community or organization with many profound benefits.

Our software is based around the [Respect Game](../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Games%20a87953a98246402da3e171f43811bfda/Fractal%20Games%20958dadb96fc940c1a6789e663d36a2c5/Respect%20Game%2097fc60fcf6944c3095df07a64e86b481.md) and the concepts of fractal cooperation, which are being pioneered in several communities, including [Optimism Fractal](https://optimismfractal.com) and [Eden Fractal](https://edenfractal.com/). These tools are designed to help communities to collaborate effectively at any scale, optimize collective decision-making, and foster amazing experiences.

On this page you can find articles about a variety of tools that help improve human coordination, measure and evaluate impact, create accountability in a fun ways, and enable unprecedented independence on the Superchain. You can find the code repositories for our software in the articles and a development hub at the bottom of the page where we’re building in public. 

Everyone is welcome to join our [weekly events](https://lu.ma/optimystics) to try this software in a live environment and watch our [videos](https://optimystics.io/videos) to see these tools in use. Enjoy!

- 
    
    
    The tools that we’re most focused on building are fractal tools for  OptimismOP Stack blockchains, such as Optimism.
    
    These tools are built on the EVM, or Ethereum Virtual Machine. 
    
    **Table of Contents**
    

![edencreators_high_tech_hammer_and_screwdriver_with_fractal_gard_fc545efe-2a7b-49e1-aedd-06c058aa0033.png](Optimystics%20Tools%20369941be584c452aac7ce45623b92d06/edencreators_high_tech_hammer_and_screwdriver_with_fractal_gard_fc545efe-2a7b-49e1-aedd-06c058aa0033.png)

- 
    
    
    To play the "Respect Game" in the context of Optimism Fractal, the following steps are involved:
    
    1. **Web App Utilization**: The game leverages a web app, specifically designed for submitting consensus results. This app is part of the Optimism Fractal ecosystem, which focuses on collaboration and supporting public goods creators.
    2. **Community Meetings and Networking**: Regular community meetings are held, where participants can network, discuss, and ask questions. These meetings set the stage for playing the Respect Game.
    3. **Using the Fractalgram App**: The Fractalgram app, which integrates with Telegram, plays a central role. It's designed to be intuitive and user-friendly, even for those with limited experience in web3 or digital wallets.
    4. **Playing the Game in Telegram**: The game can be played directly within Telegram. Participants engage in polls, and the results are then pinned to the Optimism mainnet.
    5. **Entering Optimism Accounts**: Players enter their Optimism accounts into Telegram, facilitating the direct transmission of results to the Optimism mainnet.
    6. **Reaching Consensus**: A key part of the game is reaching consensus. Two-thirds of the group need to agree to form a consensus. This process is facilitated through the use of polls and discussions among participants.
    7. **Submitting Results**: After consensus is reached, results are submitted. This involves confirming the accuracy of participant addresses and other details before pushing the data onto the blockchain.
    8. **Additional Tools and Features**: The system plans to integrate features like Ethereum Name Service (ENS) for more user-friendly and readable transactions. This allows for easier identification of participants and more seamless interaction.
    9. **Confirmation and Submission to Blockchain**: The final step involves confirming the transaction details and then submitting them to the blockchain, ensuring that the consensus results are officially recorded.
    
    The process emphasizes collaboration, consensus-building, and the use of intuitive web applications to foster community interaction and decision-making within the Optimism Fractal ecosystem.
    

## Optimism Fractal Software

The following articles provide details about software, apps, and games that the Optimism Fractal community is using at weekly events or is in the process of developing. Most of the articles feature tools that help facilitate the process of playing Respect Games and various decision-making processes enabled by [Respect](Respect%206357d339d30b425997f3da4dd6f75f32.md).

We’re working to organize the various kinds of software we’re building to make it easier for you to understand how these tools fit together, so stay tuned for updates and feel free to reach out with questions at our weekly events or other communication channels, such as the Optimism Fractal [discord](https://discord.gg/dJgrP8ekYC) or farcaster [channel](https://warpcast.com/~/channel/optimismfractal).

Explore the articles below to learn about Optimism Fractal software and how it can help empower your community or organization!

- 
    
    You can see how the tools are used in weekly events at [OptimismFractal.com](http://OptimismFractal.com). 
    
    We build open-source software to support the Optimism Fractal community and help all groups cooperate with the Respect Game. 
    
    We’re happy to help you get started with our tools. 
    
    We have many more tools in development and we’re excited to share more with you soon. In the future we also aim to curate resources about more tools in the Optimism ecosystem on this page, such as introductory resources about the OP Stack and Superchain.
    
    When you click on each tool you can learn how it relates to Optimism
    
    - [ ]  review [Create a one-pager for Eden Creators / Eden Fractal](https://www.notion.so/Create-a-one-pager-for-Eden-Creators-Eden-Fractal-01f1659e788a418bb23ac2773daa700f?pvs=21)
        - [ ]  Consider adding them here
        - This includes many tools, services, games, shows, etc
        
    - [ ]  review optimism fractal proposal and addendum and see if we should add some text here
    
    - [ ]  Make OP Fractal tools art
    
    - [ ]  Consider improving the imagery of fractalgram and other
    
    - [ ]  Add links and overviews to oth
    
    Feel free to reach out with questions or comments.
    
- 
    
    [Untitled](Optimystics%20Tools%20369941be584c452aac7ce45623b92d06/Untitled%2077e159b7088545aea2ac9295c15f3a35.csv)
    
    [Untitled](Optimystics%20Tools%20369941be584c452aac7ce45623b92d06/Untitled%205a749ca34a394391b6572efe9372785a.csv)
    
    ![Untitled](Optimystics%20Tools%20369941be584c452aac7ce45623b92d06/Untitled.png)
    

[Untitled](Optimystics%20Tools%20369941be584c452aac7ce45623b92d06/Untitled%201b9c110ae445438b95d4629a62b6d6a4.csv)

## Get Involved

Optimism Fractal events provide a perfect place to try our tools while collaborating with talented builders in the Optimism Collective. You’re welcome to join our weekly [events](https://lu.ma/optimystics) on Thursdays at 17 UTC, watch our previous [episodes](https://optimystics.io/videos), and explore our [blog](https://optimystics.io/blog) to learn more about our tools. 

You can watch developers share updates about their work building these tools at weekly events in this [playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lk5Aavi98CqFj7ryM42bvbP). You can also join the Optimism Fractal [discord](https://discord.gg/dJgrP8ekYC) and see the fractal app channel for more details. Feel free to reach out with any questions. We hope you enjoy the software and look forward to seeing how you’ll use it!

![image.png](Optimystics%20Tools%20369941be584c452aac7ce45623b92d06/image.png)

- Original tools
    
    ## High Level Overview
    
    We recommend exploring the articles above for details about our software. 
    
    The follow sections provide breakdowns of the current Optimism Fractal software and the next generation Optimism Fractal software in development.
    
    ## Overview of Current Toolset
    
    In September 2023, the Optimystics created an open source toolset that enables anyone to grow their community by playing the [Respect Game](https://optimystics.io/respectgame) on Optimism. This toolset has been in use since the beginning of Optimism Fractal. You can find details about these tools below.
    
    This toolset includes smart contracts for ranking contributions, a webapp to submit votes while playing consensus games, and an app called Fractalgram to provide an intuitive experience for all players on during community events. The consensus games that these tools implement are used to distribute a non-transferable token called [Respect](https://optimystics.io/respect), which represents contribution of an individual to a common goal. The tools that we build are all open source, so developers can use the code in our [repositories](https://github.com/optimystics) and anyone can now start playing the Respect Game at their community events. 
    
    You can watch the short video clip below for a basic introduction to the game that these tools enable and explore the articles below for many exciting details. We encourage you to watch videos of Optimism Fractal events and explore our blog to gain a better understanding of the profound benefits these tools can create. 
    
    ### Introductory Video
    
    [https://youtu.be/Ggpfi55eKEw](https://youtu.be/Ggpfi55eKEw)
    
    How do we use the OP Mainnet to play the Respect Game? We demonstrate Fractalgram and our intuitive webapp that helps communities reach consensus while having fun!
    
- Development hub
    
    
    ### Development Hub
    
    The Optimism Fractal [Development Hub](https://www.notion.so/Development-Hub-b4df0dfa78144997922bed973cee26f9?pvs=21) provides an informative, collaborative space for developers who are interested in building with Optimism Fractal. It provides a place where you can find resources, projects, and tasks related to technical development for Optimism Fractal and our products. With open development strategy we aim to inspire many people to contribute to the development of Optimism Fractal and the Respect Game. 
    
    This hub is part of the Optimism Fractal [notion site](https://bit.ly/optimismfractalnotion), which fosters a collaborative community-driven approach to the development of Optimism Fractal. where you can learn more about our community and explore various ways that you can get involved. This site includes a development hub, educational hub, and other resources to help you start building with the Superchain.
    
    ![development hub2.png](Optimism%20Fractal%20Development%20Hub%2010d074f5adac80dca940f8c067707158/development_hub2.png)
    
- Recent updates
    
    ## Optimism Fractal Apps: Recent Updates
    
    Optimism Fractal software empowers all communities with profoundly helpful tooling to optimize collective decision-making on the EVM and the Superchain, the leading platform for decentralized computing. 
    
    Over the past months the Optimism Fractal community made amazing progress in technical development for apps related to the [Respect Game](../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Games%20a87953a98246402da3e171f43811bfda/Fractal%20Games%20958dadb96fc940c1a6789e663d36a2c5/Respect%20Game%2097fc60fcf6944c3095df07a64e86b481.md) and onchain governance protocols. There are the three Optimism Fractal applications in development, which are you can explore. The Optimism Fractal community (and any other communities or organizations that use Optimism Fractal software) will determine which software to use based on their functionalities.
    
    Below are some recent updates about [ORDAO](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f.md) and [OREC](OREC%20101074f5adac80adaff5ec3442ec8f89.md), [Fractalgram](Fractalgram%20198c4a23def749669d9bab38283ef66e.md), and the [Respect Games app](Respect%20Games%20App%2010c074f5adac80ab9ed4e19f74493525.md):
    
    ### ORDAO and OREC
    
    ORDAO is a new version of Optimism Fractal software that aims to enhance decentralized onchain governance. At its core is OREC (Optimistic Respect-based Executive Contract), which enables onchain execution of transactions based on community voting using an innovative consent-based system. The ORDAO app consists of EVM smart contracts designed to transfer ownership of the Optimism Fractal community account and decision-making powers to the current Respect distribution within the community.
    
    ORDAO utilizes a non-transferable ERC-1155 NFT system for Respect, which includes metadata about when and how the Respect was earned. It allows for proposing and voting on various types of transactions, including Respect distribution and custom calls. The app features an "OR console" for accessing OREC contract features through a browser console interface, along with a basic UI for Respect Game consensus submissions. A more comprehensive GUI is currently in development by another team.
    
    Developed by Tadas, the ORDAO app has been deployed on the OP Mainnet and is available for use by any community or organization. Interested parties can explore the concept and implementation on GitHub, watch informative video playlists, ask questions in the Optimism Fractal Discord, and participate in ORDAO Office Hours to learn more about this innovative governance solution. 
    
    You can learn more in the articles about [ORDAO](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f.md) and [OREC](OREC%20101074f5adac80adaff5ec3442ec8f89.md). 
    
    ![ordao blog thumbnail 1.png](Community%20Delegation%20112074f5adac80cbb06fd76395f4b421/ordao_blog_thumbnail_1.png)
    
    - 
        
        
        /
        
        ORDAO is a set of smart contracts that enables a powerful decentralized onchain governance and award distribution system for Optimism Fractal, as well as other communities or organizations. This app has been developed by Tadas, deployed on Optimism, and is now being actively tested. 
        
        You can learn more in the articles about [ORDAO](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f.md) and [OREC](OREC%20101074f5adac80adaff5ec3442ec8f89.md). 
        
        ORDAO is a code name for a new version of Optimism Fractal software, not yet officially adopted by the community. The core component is [OREC](OREC%20101074f5adac80adaff5ec3442ec8f89.md) (Optimistic Respect-based Executive Contract), which allows for truly decentralized, onchain execution of transactions based on community voting with an innovative consent-based voting system. 
        
        The ORDAO app features a set of EVM smart contracts built with the intention to transfer ownership of the Optimism Fractal community account and onchain decision-making powers to the current Respect distribution of Optimism Fractal. It uses a non-transferable, non-fungible token (NFT) system for [Respect](Respect%206357d339d30b425997f3da4dd6f75f32.md), which includes metadata about when and how the Respect was earned.
        
        ORDAO allows for proposing and voting on various types of transactions, including Respect distribution, custom calls, and more. It features an "OR console" which provides access to all features of the OREC contract through a browser console interface along with a basic UI for Respect Game consensus submissions. A GUI is in development by another team, as you can read in our Fractalgram [article](Fractalgram%20198c4a23def749669d9bab38283ef66e.md).
        
        The ORDAO app is now deployed on the OP Mainnet and may be used by any community or organization. You can explore the concept and implementation in the [Github Repository](https://github.com/sim31/frapps/tree/main/concepts/apps/of2).  You can learn more by reading below and watching the [video playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lmBtLkZ7fEF6luDLBShtWFT), asking questions about ORDAO and OREC Optimism Fractal [discord](https://discord.gg/dJgrP8ekYC), and joining the [ORDAO Office Hours](https://lu.ma/hjj2no0v).
        
    
    - 
        
        In essence, ORDAO is a more decentralized, automated, and flexible governance and award distribution system for Optimism Fractal.
        
    
    ### Fractalgram Web App
    
    Development of the next generation Fractalgram web app began in mid-2024, introducing exciting new features to the Optimism Fractal ecosystem and improvements over the current telegram web app. Abraham Becker initiated this project during Onchain Summer, with Howard joining the collaboration in September. 
    
    They are building a comprehensive web application with features that include:
    
    - Wide-ranging wallet connection integrations for seamless user access
    - Custom usernames for a personalized experience
    - Robust voting functionality to facilitate community decision-making
    - Integration with Hats Protocol for enhanced role management
    - Planned integration with ORDAO smart contracts for advanced governance features
    - Foundations for an all-in-one app to streamline community interactions
    
    You can learn more about this application in our article about [Fractalgram](Fractalgram%20198c4a23def749669d9bab38283ef66e.md). In this article you can see a demo of this application and find more details about their work in an application for Onchain Summer. 
    
    ![fractalgram app 1280720.jpg](Fractalgram%20198c4a23def749669d9bab38283ef66e/fractalgram_app_1280720.jpg)
    
    ### Respect Games App
    
    The Respect Games platform uses blockchain technology to revolutionize how communities track, evaluate, and reward contributions. Developed by Vlad's team, it creates a transparent, decentralized system for recognizing valuable work within organizations.
    
    They are building a comprehensive web application with features that include:
    
    - User-friendly interface for the Respect Game
    - New consensus algorithm for determining contribution value
    - Asynchronous submissions with flexible ranking periods
    - Onchain contributions for transparency
    - Non-transferrable ERC-1155 Respect Tokens
    - Liquidity pool integration for rewards
    - AI-enhanced contribution summaries (planned)
    - Customizable community pages
    
    The app addresses governance challenges through structured work documentation, data-driven decision-making, fair reward distribution, and simplified decentralized governance. Launching in September, it combines peer evaluation, and AI insights to enhance engagement, transparency, and fairness in organizational governance on Optimism.
    
    You can learn [Respect Games app](Respect%20Games%20App%2010c074f5adac80ab9ed4e19f74493525.md) article.
    
    ![image.png](Respect%20Games%20App%2010c074f5adac80ab9ed4e19f74493525/image.png)
    
    ## Product Development Videos
    
    You can watch these developers share updates about their work at weekly events in this [playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lk5Aavi98CqFj7ryM42bvbP). You can also join the Optimism Fractal [discord](https://discord.gg/dJgrP8ekYC) and see the fractal app channel for more details. For more details about the upcoming apps, you can see our [tools](Optimystics%20Tools%20369941be584c452aac7ce45623b92d06.md) and a two minute [presentation](https://youtu.be/B0b0klPCVzA?si=Tqu8yJYHIGvYLq9J&t=2259) from Dan with some figma designs.
    
    ![[https://youtu.be/B0b0klPCVzA](https://youtu.be/B0b0klPCVzA)](Fractal%20Apps%2035f6bfe79a03466da32abff09356c247/EF_94_thumbnail_demo.png)
    
    [https://youtu.be/B0b0klPCVzA](https://youtu.be/B0b0klPCVzA)
    
    ### [EF 94: Eden Fractal Products](https://youtu.be/B0b0klPCVzA)
    
    What are the ideal products for optimizing community decision-making? We explore the potential offerings Eden Fractal should develop, focusing on easy-to-implement tools and resources for various audiences 📦
    
    ![[https://youtu.be/j9BBB0HHDVU](https://youtu.be/j9BBB0HHDVU)](Fractal%20Apps%2035f6bfe79a03466da32abff09356c247/EF_98_promo_image_final_1280x720.png)
    
    [https://youtu.be/j9BBB0HHDVU](https://youtu.be/j9BBB0HHDVU)
    
    ### [EF 98: Customer Needs](https://youtu.be/j9BBB0HHDVU)
    
    What role does product packaging plays in educating society about decision-making? Explore strategies for marketing and packaging Eden Fractal’s tools to aid community and organizational decision-making, focusing on understanding users' needs 🌞
    
    ![[https://youtu.be/P18cOpiGPJU](https://youtu.be/P18cOpiGPJU)](Fractal%20Apps%2035f6bfe79a03466da32abff09356c247/EF_103_fractal_pitches_game_thumbnail_resize_1280x720.png)
    
    [https://youtu.be/P18cOpiGPJU](https://youtu.be/P18cOpiGPJU)
    
    ### [EF 103: Community Ambitions](https://youtu.be/P18cOpiGPJU)
    
    Why should you implement a fractal consensus process? Thought leaders share innovative pitches, discussing how fractal tools can improve decision-making in various fields and layers of society 🤝🏽🌍🌱
    
- 
    
    
    ## What is the Respect Game?
    
    The Respect Game is a wonderful social game that anyone can play to foster collaborations, award public goods creators, and grow their community with fractal governance. All of the tools built by Optimystics are based around the Respect Game and use cases for Respect. You can watch introductor videos and learn more about the profound benefits of the Respect Game in this [article](https://optimystics.io/respectgame). 
    
    - 
        
        This consensus game is at the heart of Optimism Fractal and the tools we build at Optimystics. Here’s how it works:
        
        First, a group of people meet up and go into subgroups of three to six people. This can happen on video calls or in person. Then each participant gets to introduce themselves and share their work with their group of optimists. They each speak about how they’ve helped their community. At Optimism Fractal, we rank contributions to Optimism. After each player takes their turn speaking for up to four minutes, they try to reach consensus in ranking their contributions to community and then they post the rankings to the OP Mainnet with our intuitive web app. 
        
        In order to win the players is need to form 2/3rds consensus to rank each persons contributions to the community and signal this onchain before the end of the game. All players who reach consensus earn Respect, a soulbound token that can give you mystical powers and help badgeholders understand your impact in future seasons of RetroPGF. Players earn more respect when they are ranked higher and the game repeats for an hour each week.
        
    
    ![[https://optimystics.io/respectgame](https://optimystics.io/respectgame)](../respect_game_1.png)
    
    [https://optimystics.io/respectgame](https://optimystics.io/respectgame)
    
    ### Enhancing RetroPGF with the Optimism Fractal Tools
    
    RetroPGF is a groundbreaking mechanism to reward public goods creators and grow communities, but it has a key problem that our tools can solve. You can read this [article](https://optimystics.io/enhancing-retropgf-with-optimism-fractal) to learn how Optimism Fractal can relieve burden from badgeholders, raise awareness public goods creators, and help the citizens fairly reward impact in the Optimism Collective.
    
    ![[https://optimystics.io/enhancing-retropgf-with-optimism-fractal](https://optimystics.io/enhancing-retropgf-with-optimism-fractal)](../enhancing_retropgf_with_optimism_fractal_no__text.png)
    
    [https://optimystics.io/enhancing-retropgf-with-optimism-fractal](https://optimystics.io/enhancing-retropgf-with-optimism-fractal)