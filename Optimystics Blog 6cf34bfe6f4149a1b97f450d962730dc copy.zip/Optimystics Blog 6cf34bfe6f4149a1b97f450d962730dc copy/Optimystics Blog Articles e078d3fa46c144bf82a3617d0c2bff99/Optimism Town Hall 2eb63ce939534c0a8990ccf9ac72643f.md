# Optimism Town Hall

Displays on Pages:: Cagendas, optimism fractal season 3, optopics
AI summary: The document outlines the Optimism Town Hall, a weekly event designed for collaborative discussions about the Optimism Superchain, where participants engage in interactive games to propose and prioritize topics. It emphasizes community involvement, governance discussions, and the innovative Cagendas game for setting agendas democratically.
AI summary 1: The Optimism Town Hall is a groundbreaking weekly event designed to foster impactful and interactive discussions surrounding the Optimism ecosystem. This post explores the objectives and structure of the Town Hall, emphasizing its role as a collaborative forum for community members to engage in governance discussions and prioritize topics through innovative agenda-setting games like Cagendas. Readers will learn about the unique features of the Town Hall, including its integration with the Optimism Fractal community and the use of onchain reputation tokens to facilitate democratic dialogue. Join us as we delve into the exciting potential of the Optimism Town Hall to shape the future of community coordination and governance.
Description: A new weekly event and collaborative forum dedicated to hosting impactful, interactive, and respectful conversations about Optimism.
Published?: Yes

![OF 26 thumbnail 1280x720.png](Optimism%20Town%20Hall%202eb63ce939534c0a8990ccf9ac72643f/OF_26_thumbnail_1280x720.png)

## Welcome

A collaborative forum dedicated to conversations about the Superchain, featuring innovative community agenda games where participants choose the topics!

Optimism Town Hall provides a special place to learn about the latest developments on the Superchain, help lead the Collective, and explore opportunities with the Optimism Fractal community. At each event we play a *Cagendas* game where you can propose, vote, and choose topics with onchain reputation tokens, which provides a fun and fair way to participate in community discussions. Optimism Town Hall is presented by [Optimystics](https://optimystics.io/) and hosted by [Dan Singjoy](https://dansingjoy.com/).

Everyone is welcome to join Optimism Town Hall [weekly events](https://lu.ma/optimismtownhall) on Thursdays at 18 UTC to participate in governance discussions, pioneer the future of community coordination, and help lead the Optimism Collective. You can RSVP for email reminders at the link above and explore below to learn more!

**Table of Contents**

- 
    
    
    Optimism Town Hall is a new collaborative forum dedicated to open, structured, and impactful conversations about Optimism. This innovative event is pioneering interactive ways to optimize discussions with fun social games that enable community members to prioritize topics, deliberate democratically, and form consensus on key issues by voting with onchain reputation tokens. 
    

- 
    
    **Table of Contents**
    

## Synergies with Optimism Fractal

The Community Agenda game empowered by [Optimism Fractal](https://optimismfractal.com/), a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain. Optimism Fractal hosts weekly events an hour before the town hall that everyone can join to play the [Respect Game](https://optimystics.io/respectgame), an amazing consensus game that helps foster collaborations, evaluate positive impact, and coordinate decentralized governance. You’re welcome to play the Respect Game at Optimism Fractal [weekly events](https://lu.ma/4ggdpzyp) on Thursdays at 17 UTC to network with talented innovators, promote your work, and earn Respect by helping the Collective. 

Participants who form consensus in the Respect Game earn [Respect](https://optimystics.io/respect), a soulbound reputation token that shows appreciation for fellow community members and provides many mystical powers. For example, the Optimism Fractal community is led by a [council](https://optimismfractal.com/council) of community members who have earned Respect in weekly events. At the start of Optimism Fractal’s third season, the council approved a [proposal](https://snapshot.org/#/optimismfractal.eth/proposal/0xffac428d3920f62cf593a2d62c1db98faaf3bf5b9d2827388e802d2fab9a215d) to start playing a collaboration agenda game called Cagendas after the Respect Game at a new event called Optimism Town Hall.  

![optimism fractal promo image 11 copy.png](Optimism%20Town%20Hall%202eb63ce939534c0a8990ccf9ac72643f/optimism_fractal_promo_image_11_copy.png)

## Organizing Discussions with Cagendas

Optimism Town Hall is trailblazing how community discussions are organized in a democratic and interactive manner with [Cagendas](Cagendas%205174556889354c5e9dd2f9a82f15bc89.md), a social coordination game for collaborative agenda setting that empowers community members to propose, deliberate, and prioritize discussion topics with Respect.

Here are the current rules of Cagendas:

1. Anyone who has earned Respect at Optimism Fractal can propose a topic by creating a poll in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth).

2. Anyone who has earned Respect at Optimism Fractal can vote on polls with their Respect to help determine the discussion topic for each weekly event. 

3. Whichever poll has received the most votes in the Topic Poll by Monday at 17 UTC will be the topic discussed during the week’s event after the Respect Game.
    1. The poll for the topic proposal must end on Monday at 17 UTC (or earlier) to be eligible as a formal topic proposal for the week’s event.

Everyone is welcome to join, suggest topics, and participate in Optimism Town Hall discussions. The Respect token allows you to formally propose and vote on topics. You can earn Respect by joining the Respect Game an hour before the event to gain greater influence on this discussions. The Optimism Town Hall provides open platform for all optimists and we value your perspectives, so please share your thoughts and let us know if there are any subjects you'd like to discuss.

We’re also exploring ways to create an auxiliary reputation token that allows citizens, delegates, public goods creators, and other stakeholders in the Optimism Collective to vote in Cagendas games without needing to play the Respect Game. You can explore more and contribute development of Cagendas [here](https://bit.ly/3yxsJGv). 

![cagendas logo 94.png](Optimism%20Town%20Hall%202eb63ce939534c0a8990ccf9ac72643f/cagendas_logo_94.png)

- 
    
    The Respect token allows you to formally propose and vote on topics, but it is not required to suggest topics and participate in discussions at Optimism Town Hall. The event is provides a stage for all optimists to share their thoughts and we look forward to hearing your perspectives. Feel free to let us know if there’s anything you’d like to discuss.
    
    While the Respect token allows you to formally propose and vote on topics, it is not required to suggest topics and participate in discussions at Optimism Town Hall. The event is provides a stage for all optimists to share their thoughts and we look forward to hearing your perspectives. Feel free to let us know if there’s anything you’d like to discuss.
    
    Of course you’re welcome to join Optimism Town Hall, suggest topics, and participate in discussions if you haven’t earned Respect at Optimism Fractal events. The Respect token enables you to formally propose topics and vote on discussion topics. Everyone is welcome to join the events an hour earlier to play the Respect Game, where you can earn Respect and gain more influence on discussions.
    

## Next Steps for Optimism Town Hall

The Optimism Town Hall can provide you with a platform to help lead the Optimism Collective and create a better world for everyone. We have very exciting plans for the Optimism Town Hall and look forward to collaborating with everyone there to actualize the [Optimistic Vision](https://www.optimism.io/vision). 

The Optimism Town Hall is under active development as a community led project and contributions are welcome to guide it’s development.  We’re currently in the process of developing iterative Cagendas games modes, such as a more interactive and dynamic game mode called [OPTOPICS](OPTOPICS%20e6a774108a1141439162db80680deb1c.md). You can see a simple overview of how topics are chosen at Optimism Town Hall events on this [page](https://www.notion.so/How-do-we-choose-discussion-topics-at-Optimism-Town-Hall-b69a22c142524e2a95c210c6160049d2?pvs=21).

Optimism Town Hall is created by the creators of [Eden Town Hall](https://edentownhall.com/episodes) and [Eden Fractal](https://edenfractal.com/), where we’ve been developing the foundation for collaborative forums and collective discussions for the past three years. You may also be familiar our work on consensus gameshows like [RetroPitches](https://www.notion.so/OptimismFractal-com-c238e1244229466ba8b7753b74104b6f?pvs=21) and other shows about [public goods games](Public%20Goods%20Games%20a30eee3f0d1d4becaaca9ac7ca191e4b.md). We’re actively developing building Optimism Town Hall with the Optimism Fractal community and plan to introduce exciting initiatives, so stay tuned for updates coming soon. 

Optimism Town Hall events recur on Thursdays at 18 UTC and you’re welcome to join each week. We’re looking forward to seeing you at the events, seeing your topic proposals, and hearing your thoughts!

## Get Involved and Shape The Future

- Attend Optimism Town Hall  [weekly events](https://lu.ma/optimismtownhall) to learn about the Superchain, share your thoughts, and help lead the Collective.

- Propose topics in the [Optimism Town Hall snapshot space](https://snapshot.org/#/optimismtownhall.eth), highlighting the most important issues that deserve attention.

- Suggest topics in the Optimism Town Hall [Discord channel](https://discord.gg/ZKv3tRWrSr), the Optimism [governance forum](https://gov.optimism.io/t/optimism-fractal-season-3), or throughout the event.

- Contribute to the development of Optimism Town Hall through the [Notion project](https://bit.ly/4dSH6Fy) and help shape its future.

- Participate in Optimism Fractal [weekly events](https://lu.ma/4ggdpzyp) to play the Respect Game, earn Respect, and gain influence within the community.

- Watch videos below about the events and share them with friends to spread the word!

## Watch Optimism Town Hall Videos

You can watch all Optimism Town Hall videos at [OptimismFractal.com/videos](http://OptimismFractal.com/videos). The town hall videos are in the last half hour of Optimism Town Hall events and we plan to start producing each episodes on it’s own in the near future. You can find introductory discussions about Cagendas and the first Optimism Town Hall event in the videos below:

[https://youtu.be/-QbLQgOZKwk?si=OcjbbBnrlvMPaOl1](https://youtu.be/-QbLQgOZKwk?si=OcjbbBnrlvMPaOl1)

**Introducing Cagendas**

After a spirited Respect Game we introduce Optimism Town Hall and Cagendas, a community agenda game for prioritizing topics, deliberating key issues, and forming consensus to benefit the Optimism Collective 🍎 ⏱️ 💫 

In this video you can watch brief introductory discussions about Cagendas and Optimism Town hall at [4:10](https://www.youtube.com/watch?v=-QbLQgOZKwk&t=250s) and [1:19:52](https://youtu.be/-QbLQgOZKwk?t=4792) in this video. You can watch the full episode and explore the timestamps in the description to see outstanding contributions in the Respect Game, awesome discussions with talented newcomers, and a very interesting conversation about collaborations to build the upcoming Optimism Fractal app.

- 
    
    In our season three debut we introduce Optimism Town Hall and Cagendas, a community agenda game for prioritizing topics, deliberating key issues, and forming consensus to benefit the Optimism Collective 🍎 ⏱️ 💫 
    
    How can communities maximize positive impact for the Optimism Collective? In our Season 3 debut, we introduced a new game for collective agenda creation 🌻
    
    innovative community agenda game and collaborative forum called Optimism Town Hall to maximize positive impact for the Collective
    
    In the first event of Optimism Fractal’s third season, we introduce an innovative community agenda game and collaborative forum called Optimism Town Hall to maximize positive impact for the Collective 🔴 ✨
    

[https://youtu.be/XdzOMH54LrM?si=iAAhblwAF8NfTw6d](https://youtu.be/XdzOMH54LrM?si=iAAhblwAF8NfTw6d)

***Exploring Optimism Town Hall and Cagendas***

In our second episode of the season we dive deeper into the potential benefits, next steps, and rationale of how the Optimism Town Hall maximizes positive impact for the Collective 🔴 ✨

You can watch a detailed presentation about the Optimism Town Hall at [1:06:15](https://www.youtube.com/watch?v=XdzOMH54LrM&t=3975s) in this video. You can also watch the full episode and explore timestamps in the description to see beautiful presentations featuring excellent work from public goods creators and an historical recollection of Optimism Fractal and fractal communities.

- 
    
    
     pioneering interactive ways to optimize meeting time with fun social games that enable community members to prioritize topics, deliberate democratically, and form consensus on key issues by voting with Respect.  
    
    more in-depth overview of the potential benefits, next steps, and rationale of these new initiatives
    

![[https://youtu.be/08pMPx6MLnc](https://youtu.be/08pMPx6MLnc)](Optimism%20Town%20Hall%202eb63ce939534c0a8990ccf9ac72643f/thumbnail_of_27_final_thumbnail.png)

[https://youtu.be/08pMPx6MLnc](https://youtu.be/08pMPx6MLnc)

### [OF 27: Topics Game and Base Builders](https://youtu.be/08pMPx6MLnc)

How can communities navigate discussions by voting on topics with Respect? We ride the Superchain waves in a Respect Game, then dive into the second Optimism Town Hall with Opie for a collective agenda game and an introduction to Base 🔵 🔴 

The second Optimism Town Hall started at [58:23](https://www.youtube.com/watch?v=08pMPx6MLnc&t=3503s) in this video with Dan introducing the event, explaining the voting process, and the differences between Cagendas and OPTOPICS. At [1:13:32](https://www.youtube.com/watch?v=08pMPx6MLnc&t=4412s), the discussion shifted to “Engaging with Base,” where community members shared insights and feedback on Base’s integration and opportunities for builders.

![[https://youtu.be/CsTqPS4HHsw](https://youtu.be/CsTqPS4HHsw)](Optimism%20Town%20Hall%202eb63ce939534c0a8990ccf9ac72643f/thumbnail_of_28_thumbnail_draft.png)

[https://youtu.be/CsTqPS4HHsw](https://youtu.be/CsTqPS4HHsw)

### [**OF 28: Optimism Fractal Software**](https://youtu.be/CsTqPS4HHsw)

What software will empower millions of communities on the Superchain? Watch builders share impressive presentations in the Respect Game, then choose discussion topics at Optimism Town Hall and preview a next generation Optimism Fractal app 🌻📲

# Related Posts

[Untitled](Optimism%20Town%20Hall%202eb63ce939534c0a8990ccf9ac72643f/Untitled%2071a79f3709424efc8d85e53e430a8f0e.csv)