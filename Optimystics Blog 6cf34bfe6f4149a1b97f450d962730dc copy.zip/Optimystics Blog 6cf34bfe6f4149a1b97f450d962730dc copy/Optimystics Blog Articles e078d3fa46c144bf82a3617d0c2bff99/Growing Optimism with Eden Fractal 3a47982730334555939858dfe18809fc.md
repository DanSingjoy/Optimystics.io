# Growing Optimism with Eden Fractal

Displays on Pages:: EF 67, Intro to Optimism, Roots of Optimism Fractal
AI summary: "Growing Optimism with Eden Fractal" is a new educational video series that explores the principles and stories behind the Optimism Collective, aiming to inspire and share practical insights for a brighter future. The series was developed during live events with community leaders and Web3 pioneers and features episodes available on YouTube.
AI summary 1: In this blog post, we are excited to introduce our new educational video series, "Growing Optimism with Eden Fractal." This series aims to explore the rich concepts of the Optimism Collective, showcasing inspiring stories and practical insights that can help us all contribute to a brighter future. Through various episodes, viewers will engage with thought-provoking content that emerged from live events featuring community leaders and Web3 pioneers. Join us as we embark on this enlightening journey that promises to uplift and educate!
Description: We’re pleased to release "Growing Optimism with Eden Fractal,” our new educational video series that explores the Optimism Collective to shape a brighter future for all! 🌱❣️ 🌞
Published?: Yes

![ORIGINAL for youtube Growing Optimism thumbnail with default text.png](Growing%20Optimism%20with%20Eden%20Fractal%203a47982730334555939858dfe18809fc/ORIGINAL_for_youtube_Growing_Optimism_thumbnail_with_default_text.png)

## Growing Optimism with Eden Fractal

We’re pleased to announce the launch of our new educational video series, "Growing Optimism with Eden Fractal"!

Each episode will delve into different aspects of Optimism, sharing inspiring stories, practical tips, and thought-provoking insights. Join us on this journey as we unlock the secrets of the Optimism Collective and discover how the Optimism Collective is creating a brighter future for all. This educational series was created during live Eden Fractal events throughout August-Septembers of 2023 with community leaders and Web3 pioneers. 

You can watch the first five videos of the series in our Youtube [playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lnG4TEQj-57IX6dFtC3LAvt) and watch the full Eden Fractal episodes with many more exciting details on our [videos](../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Optimystics%20Videos%204aa0cc0fe82f46fd8fb6a8548b7a5732.md) page. You can also learn more in this [article](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6.md). The first episode is below. Enjoy! 🔴

[https://www.youtube.com/watch?v=v3iJvTQLCGU](https://www.youtube.com/watch?v=v3iJvTQLCGU)

Peace and love,

Optimystics