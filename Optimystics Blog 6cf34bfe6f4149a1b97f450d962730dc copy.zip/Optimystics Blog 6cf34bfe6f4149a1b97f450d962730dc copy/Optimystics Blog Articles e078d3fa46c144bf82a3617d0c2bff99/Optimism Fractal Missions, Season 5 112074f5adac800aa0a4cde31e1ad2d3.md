# Optimism Fractal Missions, Season 5

Displays on Pages:: 2023, 2024, Optimism Missions, missions, token house
AI summary: This document outlines mission requests and ideas for the Optimism Collective in December 2023, with a focus on enhancing the RetroPGF review process and brainstorming new mission concepts. It invites feedback and collaboration from the community.
AI summary 1: In this blog post, we outline our mission requests and innovative ideas for the Optimism Collective as we approach December 2023. Our primary focus is on enhancing the RetroPGF review process, a critical aspect that requires attention and refinement. Additionally, we present a variety of brainstorming ideas aimed at attracting builders, creators, and a diverse range of participants to strengthen the Optimism ecosystem. We invite our readers to engage with these concepts, provide feedback, and join us in our mission to foster growth and collaboration within the community.
Description: An outline our mission requests and ideas for the Optimism Collective in December 2023, focusing on improving the RetroPGF review process and brainstorming mission ideas.
Published?: Yes

![mission season 5 planning.png](Optimism%20Fractal%20Missions,%20Season%205%20112074f5adac800aa0a4cde31e1ad2d3/mission_season_5_planning.png)

## Welcome

This page provides an overview of our ideas for mission requests and proposals from Optimism Season 5 in December, 2023. We’re curious to hear your thoughts and hope you find it valuable. Feel free to reach out with any questions or comments. See our 

**Table of Contents**

## Mission Request 1: Improve the RetroPGF Review Process

The mission request that we have developed most so far is to improve the review process for RetroPGF. You can see a draft of this mission request [here](https://optimystics.io/missions/improve-retropgf-review-process). We plan to further refine this mission request in the coming days and would appreciate feedback.

## Mission Request Ideas

In addition to the Mission Request above, we have also brainstormed many ideas for other potential mission requests. One of our main goals with these mission request ideas is to draw builders, creators, and all kinds of people to grow the Optimism Collective. There are many ways that we can envision this being executed and as such there are many ideas below. You can select the buttons at the top to sort the mission requests by their Collective Intent.

[Mission Request Ideas](Optimism%20Fractal%20Missions,%20Season%205%20112074f5adac800aa0a4cde31e1ad2d3/Mission%20Request%20Ideas%20988caa8b468a4d159bbdced51f638f2e.csv)

![Untitled](Optimism%20Fractal%20Missions,%20Season%205%20112074f5adac800aa0a4cde31e1ad2d3/Untitled.png)

## Mission Proposal Ideas

Here are some quick ideas for products or services that we can offer if there are fitting missions. Feel free to let us know if there are any ideas that you’d like to see further developed or any missions that you’d like us to propose that may be related to these ideas. We’ll improve this in the future but figured it may be helpful to provide context for our work and some of the mission request ideas above.

[Mission Proposal Ideas](Optimism%20Fractal%20Missions,%20Season%205%20112074f5adac800aa0a4cde31e1ad2d3/Mission%20Proposal%20Ideas%2078f2fb4137f34042a80a9b7024677b73.csv)

[Videos](Optimism%20Fractal%20Missions,%20Season%205%20112074f5adac800aa0a4cde31e1ad2d3/Videos%207693432594ed4a469e2eb6c3c33cef10.md)

## Mission Request Project

Our team is working on a project to to create mission requests. You can see a bit of the project below and we can give you full access if you’d like to see more or collaborate here.

[Create Mission Requests for Optimism Season 5](https://www.notion.so/Create-Mission-Requests-for-Optimism-Season-5-037a7955c1d44c1faec99f022b439049?pvs=21) 

## Next Steps

Thank you for reading. We’re working to refine our mission requests to help grow Optimism and are curious to hear your thoughts. Feel free to reach out with any questions or comments :)

[Untitled](Optimism%20Fractal%20Missions,%20Season%205%20112074f5adac800aa0a4cde31e1ad2d3/Untitled%20112074f5adac80c5966ee2a6f320f18a.csv)