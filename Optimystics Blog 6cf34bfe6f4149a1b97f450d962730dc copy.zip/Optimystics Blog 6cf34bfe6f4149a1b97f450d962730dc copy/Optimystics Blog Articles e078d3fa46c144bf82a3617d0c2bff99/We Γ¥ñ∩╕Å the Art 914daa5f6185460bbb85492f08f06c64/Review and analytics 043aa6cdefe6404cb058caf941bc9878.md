# Review and analytics

[https://x.com/flynnjamm/status/1744559842994323755?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ](https://x.com/flynnjamm/status/1744559842994323755?s=12&t=xP2VArgrZ3VqnY5S2s8WeQ)