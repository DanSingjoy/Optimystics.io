# Anti-Capture Commission

The Anticapture Commission (ACC) is a group that is a collection of top delegates who are collectively delegated 10 million OP.

I believe that the ACC was designed by the Optimism Foundation to help decentralize the Token House. Optimism Fractal could potentially serve a similar role in a more decentralized, programmatic, and democratic way with ORDAO.

You can find details about the ACC in the following links:

[https://gov.optimism.io/t/anticapture-commission/6889](https://gov.optimism.io/t/anticapture-commission/6889)

[https://gov.optimism.io/t/anticapture-commission-communication-thread/](https://gov.optimism.io/t/anticapture-commission-communication-thread/)

[https://www.youtube.com/playlist?list=PLXDWIGDC9_QJy-d26n3IbCdTfc2x7CT9i](https://www.youtube.com/playlist?list=PLXDWIGDC9_QJy-d26n3IbCdTfc2x7CT9i)

[https://snapshot.org/#/anticapturecommission.eth](https://snapshot.org/#/anticapturecommission.eth)

Playlist:

[Anticapture Commission](https://www.youtube.com/playlist?list=PLXDWIGDC9_QJy-d26n3IbCdTfc2x7CT9i)

[Anticapture Commission Communication Thread](https://gov.optimism.io/t/anticapture-commission-communication-thread/7501/12)

[https://www.youtube.com/playlist?list=PLXDWIGDC9_QJy-d26n3IbCdTfc2x7CT9i](https://www.youtube.com/playlist?list=PLXDWIGDC9_QJy-d26n3IbCdTfc2x7CT9i)