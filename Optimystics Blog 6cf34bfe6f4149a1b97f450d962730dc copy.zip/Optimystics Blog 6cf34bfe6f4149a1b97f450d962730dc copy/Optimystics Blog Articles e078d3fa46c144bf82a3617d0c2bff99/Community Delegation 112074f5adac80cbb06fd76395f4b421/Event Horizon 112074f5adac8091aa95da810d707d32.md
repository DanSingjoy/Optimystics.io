# Event Horizon

Event Horizon was just approved for a Optimism Mission requesting 15k OP in user incentives. I don’t think that Event Horizon was operating on Optimism previously but now it seems that they will be

[https://app.charmverse.io/op-grants/event-horizon-public-access-voter-pool-415135727941663](https://app.charmverse.io/op-grants/event-horizon-public-access-voter-pool-415135727941663)

## Top Resources

[https://eventhorizon.vote/](https://eventhorizon.vote/)

[https://x.com/EventHorizonDAO](https://x.com/EventHorizonDAO)

[https://medium.com/hvax](https://medium.com/hvax)

## Videos

[https://www.youtube.com/watch?v=6_0df410jeQ&pp=ygUYZXZlbnQgaG9yaXpvbiBkZWxlZ2F0aW9u](https://www.youtube.com/watch?v=6_0df410jeQ&pp=ygUYZXZlbnQgaG9yaXpvbiBkZWxlZ2F0aW9u)

[https://www.youtube.com/watch?v=REmBCbFylJc](https://www.youtube.com/watch?v=REmBCbFylJc)

## Articles

### Tally Blog

[Solving Delegation with Event Horizon & The Tally Protocol](https://tally.mirror.xyz/Ho9D5AiqA7_IjuwOu-dl9-ph3VWUu0PAgB3EI0kD3zI)

[The Tally Protocol Education: Redelegation](https://tally.mirror.xyz/BfiTANyJubJ3LTLAT2KW-cwMqY8aUeh9WDC_LBybHvU)

### Event Horizon Blog

[The Limitations of Current DAO Quorum Models, Benefits of Mobilizing Yield Assets in Governance…](https://medium.com/hvax/the-limitations-of-current-dao-quorum-models-benefits-of-mobilizing-yield-assets-in-governance-b3d195269610)

[Sacrificial Specialization](https://medium.com/hvax/sacrificial-specialization-7538c067674c)

[Implicit Delegation: Event Horizon’s Governance Solution.](https://medium.com/hvax/implicit-delegation-event-horizons-governance-solution-3815d61ded12)

[Enter the Event Horizon](https://medium.com/hvax/enter-the-event-horizon-664990951247)

[State of the DAO #3](https://medium.com/hvax/state-of-the-dao-3-3e20474e29b9)

[Event Horizon Pilot Launch: Empowerment through Voter NFTs](https://medium.com/hvax/event-horizon-pilot-launch-empowerment-through-voter-nfts-8530becb4bf4)

[Delegate to a public access, public good citizen enfranchisement pool through Event Horizon](https://forum.arbitrum.foundation/t/delegate-to-a-public-access-public-good-citizen-enfranchisement-pool-through-event-horizon/21523)

[https://tally.mirror.xyz/Ho9D5AiqA7_IjuwOu-dl9-ph3VWUu0PAgB3EI0kD3zI](https://tally.mirror.xyz/Ho9D5AiqA7_IjuwOu-dl9-ph3VWUu0PAgB3EI0kD3zI)