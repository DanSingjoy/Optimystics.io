# Optimism Fractal Hats Tree

Displays on Pages:: Fractalgram, Tools
AI summary: The document discusses the Optimism Fractal Hats Tree, a project that won the grand prize at the Hats Protocol Hatathon, emphasizing its role in enhancing decision-making through programmable on-chain roles. It highlights the collaboration between Dan and Jacob Homanics in developing this project and outlines how users can claim hats based on their earned Respect.
AI summary 1: In this blog post, we delve into the Optimism Fractal Hats Tree, a groundbreaking project that emerged as a co-winner of the inaugural Hats Protocol Hatathon. This innovative initiative enhances decision-making processes through the implementation of programmable on-chain roles, utilizing the concept of "Respect" within the community. We will explore the significance of this project, the collaborative efforts behind its creation, and how it provides new powers for participants in the Optimism Fractal ecosystem. Join us as we unpack the details of this remarkable achievement and its implications for future integrations with the Hats Protocol.
Description: A look into the Optimism Fractal Hats Tree, highlighting its significance in enhancing decision-making through programmable on-chain roles with Respect.
Published?: Yes

![OTH image as part of OF 41.png](Optimism%20Fractal%20Hats%20Tree%2010d074f5adac8072831ecf6eac50896f/OTH_image_as_part_of_OF_41.png)

## Welcome

This article provides an overview of the [Optimism Fractal Hats Tree](https://app.hatsprotocol.xyz/trees/10/175), which recently was announced as a co-winner of the inaugural Hats Protocol Hatathon and provides new powers for [Respect](Respect%206357d339d30b425997f3da4dd6f75f32.md). Please note that this article is an early work in progress and will be updated soon. 

**Table of Contents**

## Overview

You can find the most information about the Optimism Fractal Hats Tree by watching the Optimism Town Hall episode and exploring show notes at [OptimismFractal.com/41](http://OptimismFractal.com/41). You can also join this [chat](https://t.me/hatsprotocolandoptimismfractal) to learn more and participate in our discussions with the founders of Hats Protocol. You can explore this [project](https://bit.ly/of-hats-project) for information about future integrations with Hats Protocol and explore below for details about the integrations so far. 

![[https://optimismfractal.com/41](https://optimismfractal.com/41)](Optimism%20Fractal%20Hats%20Tree%2010d074f5adac8072831ecf6eac50896f/optimism_fractal_41_thumbnail_and_hats_image.png)

[https://optimismfractal.com/41](https://optimismfractal.com/41)

[**OF 41: Optimism Fractal Hats Tree, Let's GROW, and Hats Protocol**](https://optimismfractal.com/41)

Why was Optimism Fractal selected as co-winner of the first Hats Protocol Hatathon? Watch builders attest to each other's work during the Respect Game, then dive into the structure of Optimism Fractal & Let's GROW Hats Trees to discover how hats enhance decision-making with programmable onchain roles 🧢🌻🌳

## Optimism Fractal Hats Tree is a Winner!

We’re pleased to announce that the [Optimism Fractal Hats Tree](https://app.hatsprotocol.xyz/trees/10/175) was selected a co-winner of the Mad Hatter grand prize in the first Hats Protocol Hatathon! 🌻🧢

Dan collaborated with [Jake Homanics](https://jacobhomanics.com/) to create the Optimism Fractal Hats Tree in the Hatathon. Huge thanks to [Jacob](https://twitter.com/JacobHomanics/status/1831774911767203931) for the amazing work building the Hats Tree and all the great support from the Haberdasher Labs team. This is an important first step towards many more powerful integrations between Optimism Fractal and Hats Protocol. You can learn more at [HatsProtocol.xyz](http://hatsprotocol.xyz/) and the ‘Hats Protocol + Optimism Fractal’ [telegram group](https://telegram.me/hatsprotocolandoptimismfractal) where we’re planning the next steps with the Hats founders.

We commemorated the momentous win at this week’s Optimism Town Hall event, which you can watch in the second half of the video above!

## How to claim Optimism Fractal hats

![optimism fractal hats tree image.png](Optimism%20Fractal%20Hats%20Tree%2010d074f5adac8072831ecf6eac50896f/optimism_fractal_hats_tree_image.png)

Dan and **Jacob Homanics** participated in the Hats Protocol [Hatathon](https://t.me/hatsprotocolandoptimismfractal/151) and they've launched a great MVP! So far they’ve created a basic [Hats Tree](https://app.hatsprotocol.xyz/trees/10/175) that enables anyone who has earned [Respect](Respect%206357d339d30b425997f3da4dd6f75f32.md) at Optimism Fractal weekly events to claim a Rookie Hat, which grants access to the Optimism Fractal charmverse [space](https://app.charmverse.io/optimismfractal) and a new networking page for builders. The Hats Tree also enables anyone who has earned over 50 Respect and read the tutorial article about fractalgram to claim a Respect Game Leader hat, which signifies that you can lead a breakout room at weekly events.

If you have earned Optimism Fractal Respect then please claim your hats to help enhance our integrations with Hats Protocol. You can claim the Rookie Hat by clicking [here](https://app.hatsprotocol.xyz/trees/10/175?hatId=175.1.2), then connecting your wallet and clicking the ‘claim hat’ button near the right side of the screen. If you’d like to signify that you’re ready to host a breakout room for the Respect Game then you can also claim the Rising Star, Fractalgram Certification, and Respect Game Leader hats as well. You can also join this [chat](https://t.me/hatsprotocolandoptimismfractal) to learn more and participate in our discussions with the founders of Hats Protocol. 

This is an important first step towards many more powerful integrations between Optimism Fractal and Hats Protocol. Huge thanks to Jacob for all the amazing work building the Hats Tree and all the support from the Haberdasher Labs team!

## Optimism Fractal Hats Tree Overview

[https://x.com/hatsprotocol/status/1833864343714513247](https://x.com/hatsprotocol/status/1833864343714513247)

## Videos

![[https://optimismfractal.com/41](https://optimismfractal.com/41)](Optimism%20Fractal%20Hats%20Tree%2010d074f5adac8072831ecf6eac50896f/optimism_fractal_41_thumbnail_and_hats_image.png)

[https://optimismfractal.com/41](https://optimismfractal.com/41)

### [**OF 41: Optimism Fractal Hats Tree, Let's GROW, and Hats Protocol**](https://optimismfractal.com/41)

Why was Optimism Fractal selected as co-winner of the first Hats Protocol Hatathon? Watch builders attest to each other's work during the Respect Game, then dive into the structure of Optimism Fractal & Let's GROW Hats Trees to discover how hats enhance decision-making with programmable onchain roles 🧢🌻🌳

[https://www.youtube.com/watch?v=vVQbuUUn5pc](https://www.youtube.com/watch?v=vVQbuUUn5pc)

### **Hats Protocol Interview with Jacob Homanics**

![optimism fractal hats 2.png](Optimism%20Fractal%20Hats%20Tree%2010d074f5adac8072831ecf6eac50896f/optimism_fractal_hats_2.png)