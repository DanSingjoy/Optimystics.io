# Optimism Town Hall v2

Displays on Pages:: Cagendas, optimism fractal season 3, optopics
AI summary: The document is about Optimism Town Hall, a new weekly event and collaborative forum dedicated to hosting conversations about Optimism. It aims to encourage participation in governance discussions and pioneer the future of community coordination within the Optimism Collective.
Description: A new weekly event and collaborative forum dedicated to hosting impactful, interactive, and respectful conversations about Optimism.
Published?: No

Optimism Town Hall is a new weekly event and collaborative forum dedicated to openly structured conversations about Optimism. This innovative event pioneers interactive ways to build culture with fun social games that enable community members to prioritize topics, deliberate democratically, and form consensus on key issues by voting with onchain reputation tokens. 

The [Optimism Town Hall weekly events](https://lu.ma/optimismtownhall) are open for everyone and occur every Thursday at 18 UTC. The reason why we feel the urge to start this event is to encourage and inspire participation in governance discussions, pioneer the future of community coordination, and help lead the Optimism Collective. You can learn more about the details of how we’re planning to run these events and get everyone involved below.

![optimism town hall proposal image final  wider 155.png](Optimism%20Town%20Hall%20v2%20aef80d4096894fffb0f475c8d9b68914/optimism_town_hall_proposal_image_final__wider_155.png)

- 
    
    **Table of Contents**
    

## Synergies with Optimism Fractal

The Optimism Town Hall is powered by [Optimism Fractal](https://optimismfractal.com/), a community dedicated to fostering collaboration and awarding public good creators on Optimism. Optimism Fractal is founded by the [Optimystics](https://optimystics.io/) and has received a RetroPGF grant during Round 3 for which we’re immensely thankful for.

Optimism Fractal hosts weekly events which start an hour before the town hall that everyone can join to play the [Respect Game](https://optimystics.io/respectgame) - a joyful consensus process that helps foster collaborations, evaluate positive impact, and coordinate decentralized governance. The creation of Optimism Town Hall is sprouted from the Optimism Fractal’s established governance system and community effort. We believe that this is one of the best way that Optimism Fractal can provide value to the broader Superchain. If you’re looking for ways to meet and network with optimists, promote your work, and earn Respect by helping the Collective - our doors are always open. [Join us](http://lu.ma/optimismfractal) every Thursday at 17 UTC!

### Using Reputation Tokens to Vote

Participants who form consensus in the Respect Game earn [Respect](https://optimystics.io/respect), a soulbound reputation token that shows appreciation for fellow community members. The Optimism Fractal community is led by a [council](https://optimismfractal.com/council) of community members who have earned Respect from joining weekly events, which also have the option to participate in the Council and earn their place depending on their total Respect Score. Another exciting use case of Respect is to set community agenda that empowers community members to propose, discuss and vote on topics, as described in this [proposal](https://snapshot.org/#/optimismfractal.eth/proposal/0xffac428d3920f62cf593a2d62c1db98faaf3bf5b9d2827388e802d2fab9a215d). 

## Organizing Discussions with Cagendas

Optimism Town Hall is trailblazing how community discussions are organized in a democratic and interactive manner with [Cagendas](Cagendas%205174556889354c5e9dd2f9a82f15bc89.md), a social coordination game for collaborative agenda setting that empowers community members to propose, deliberate, and prioritize discussion topics with Respect.

Here are the current rules of Cagendas:

1. Anyone who has earned Respect at Optimism Fractal can propose a topic by creating a poll in the Optimism Town Hall [snapshot space](https://snapshot.org/#/optimismtownhall.eth).

2. Anyone who has earned Respect at Optimism Fractal can vote on polls with their Respect to help determine the discussion topic for each weekly event. 

3. Whichever poll has received the most votes in the Topic Poll by Monday at 17 UTC will be the topic discussed during the week’s event after the Respect Game.
    1. The poll for the topic proposal must end on Monday at 17 UTC (or earlier) to be eligible as a formal topic proposal for the week’s event.

We’re also exploring ways to create an auxiliary reputation token that allows citizens, delegates, public goods creators, and other stakeholders in the Optimism Collective to vote in Cagendas games without needing to play the Respect Game. You can explore more and contribute development of Cagendas [here](https://bit.ly/3yxsJGv).

## Next Steps for Optimism Town Hall

The Optimism Town Hall can provide you with a platform to help lead the Optimism Collective and create a better world for everyone. We have very exciting plans for the Optimism Town Hall and look forward to collaborating with everyone there to actualize the [Optimistic Vision](https://www.optimism.io/vision). 

The Optimism Town Hall is under active development as a community led project and contributions are welcome to guide it’s development.  We’re currently in the process of developing iterative Cagendas games modes, such as a more interactive and dynamic game mode called [OPTOPICS](OPTOPICS%20e6a774108a1141439162db80680deb1c.md). Optimism Town Hall is created by the creators of [Eden Town Hall](https://edentownhall.com/episodes) and [Eden Fractal](https://edenfractal.com/), where we’ve been developing the foundation for collaborative forums and collective discussions for the past three years. You may also be familiar our work on consensus gameshows like [RetroPitches](https://www.notion.so/OptimismFractal-com-c238e1244229466ba8b7753b74104b6f?pvs=21) and we’re planning to share more [public goods games](Public%20Goods%20Games%20a30eee3f0d1d4becaaca9ac7ca191e4b.md) soon. We’re actively developing building Optimism Town Hall with the Optimism Fractal community and plan to introduce many exciting initiatives, so stay tuned for lots of exciting updates coming soon. 

Optimism Town Hall events recur on Thursdays at 18 UTC and you’re welcome to join each week. We’re looking forward to seeing you at the events, seeing your topic proposals, and hearing your thoughts!

## Get Involved and Shape The Future

- Attend the weekly [Optimism Town Hall events](https://lu.ma/optimismtownhall) to share your thoughts and help lead the community.

- Propose topics in the [Optimism Town Hall snapshot space](https://snapshot.org/#/optimismtownhall.eth), highlighting the most important issues that deserve attention.

- Suggest topics in the Optimism Town Hall [Discord channel](https://discord.gg/ZKv3tRWrSr) or the Optimism [governance forum](https://gov.optimism.io/t/optimism-fractal-season-3/8095/2) and explore the new OPTOPICS Cagendas game at this week’s event.

- Contribute to the development of Optimism Town Hall through the [Notion project](https://bit.ly/4dSH6Fy) and help shape its future.

- Participate in Optimism Fractal [weekly events](https://www.notion.so/Promote-OTH-1-3de5089a487a4e3ba2aba5d2fa5c8115?pvs=21) to play the Respect Game, earn Respect, and gain influence within the community.

- Watch videos below about the events and share them with friends to spread the word!

## Watch Optimism Town Hall Videos

We invite you to watch discussions about Cagendas and the first Optimism Town Hall event in the videos below:

[https://youtu.be/-QbLQgOZKwk?si=OcjbbBnrlvMPaOl1](https://youtu.be/-QbLQgOZKwk?si=OcjbbBnrlvMPaOl1)

**Introducing Cagendas**

After a spirited Respect Game we introduce Optimism Town Hall and Cagendas, a community agenda game for prioritizing topics, deliberating key issues, and forming consensus to benefit the Optimism Collective 🍎 ⏱️ 💫 

In this video you can watch brief introductory discussions about Cagendas and Optimism Town hall at [4:10](https://www.youtube.com/watch?v=-QbLQgOZKwk&t=250s) and [1:19:52](https://youtu.be/-QbLQgOZKwk?t=4792) in this video. You can watch the full episode and explore the timestamps in the description to see outstanding contributions in the Respect Game, awesome discussions with talented newcomers, and a very interesting conversation about collaborations to build the upcoming Optimism Fractal app.

- 
    
    In our season three debut we introduce Optimism Town Hall and Cagendas, a community agenda game for prioritizing topics, deliberating key issues, and forming consensus to benefit the Optimism Collective 🍎 ⏱️ 💫 
    
    How can communities maximize positive impact for the Optimism Collective? In our Season 3 debut, we introduced a new game for collective agenda creation 🌻
    
    innovative community agenda game and collaborative forum called Optimism Town Hall to maximize positive impact for the Collective
    
    In the first event of Optimism Fractal’s third season, we introduce an innovative community agenda game and collaborative forum called Optimism Town Hall to maximize positive impact for the Collective 🔴 ✨
    

[https://youtu.be/XdzOMH54LrM?si=iAAhblwAF8NfTw6d](https://youtu.be/XdzOMH54LrM?si=iAAhblwAF8NfTw6d)

***Exploring Optimism Town Hall and Cagendas***

In our second episode of the season we dive deeper into the potential benefits, next steps, and rationale of how the Optimism Town Hall maximizes positive impact for the Collective 🔴 ✨

You can watch a detailed presentation about the Optimism Town Hall at [1:06:15](https://www.youtube.com/watch?v=XdzOMH54LrM&t=3975s) in this video. You can also watch the full episode and explore timestamps in the description to see beautiful presentations featuring excellent work from public goods creators and an historical recollection of Optimism Fractal and fractal communities.

- 
    
    
     pioneering interactive ways to optimize meeting time with fun social games that enable community members to prioritize topics, deliberate democratically, and form consensus on key issues by voting with Respect.  
    
    more in-depth overview of the potential benefits, next steps, and rationale of these new initiatives
    

# Related Posts

[Untitled](Optimism%20Town%20Hall%20v2%20aef80d4096894fffb0f475c8d9b68914/Untitled%201cfb48f545a64b459f0a4d4ba08c680e.csv)