# Fractal Apps

Displays on Pages:: Fractalgram, ORDAO, Respect Games, Tools
AI summary: This document provides an overview of the Optimism Fractal Apps, which facilitate community governance and decision-making through innovative tools like ORDAO, Fractalgram, and the Respect Games app. It highlights their features, development progress, and the benefits they bring to organizations using these decentralized solutions.
AI summary 1: In this blog post, we explore the emerging landscape of Fractal Apps, which are designed to enhance collective decision-making and governance within communities and organizations. We will delve into the functionalities and developments of key applications such as ORDAO, the Fractalgram web app, and the Respect Games platform. Each of these tools plays a significant role in facilitating decentralized governance and optimizing user engagement through innovative technology. Furthermore, we will provide recent updates on their development, showcasing how the Optimism Fractal community is pushing the boundaries of what is possible in decentralized systems. Join us as we uncover the transformative potential of these applications and their impact on community coordination and decision-making.
Description: An overview of apps that make it easy to play the Respect Game, facilitate coordination, and cooperate with fractal governance within communities and organizations.
Published?: Yes

![fractal app 2.png](Fractal%20Apps%2035f6bfe79a03466da32abff09356c247/fractal_app_2.png)

## Welcome

Fractal Apps is a comprehensive web application that facilitates coordination and collaboration within communities and organizations. This page outlines the features, development status, and benefits of the upcoming web app. Enjoy!

**Table of Contents**

![Untitled](Fractal%20Apps%2035f6bfe79a03466da32abff09356c247/Untitled.png)

## Overview of Optimism Fractal Apps

Optimism Fractal software empowers all communities with profoundly helpful tooling to optimize collective decision-making on the EVM and the Superchain, the leading platform for decentralized computing. 

Over the past months the Optimism Fractal community made amazing progress in technical development for apps related to the [Respect Game](../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Games%20a87953a98246402da3e171f43811bfda/Fractal%20Games%20958dadb96fc940c1a6789e663d36a2c5/Respect%20Game%2097fc60fcf6944c3095df07a64e86b481.md) and onchain governance protocols. There are the three Optimism Fractal applications in development, which are you can explore. The Optimism Fractal community (and any other communities or organizations that use Optimism Fractal software) will determine which software to use based on their functionalities.

Below are some recent updates about [ORDAO](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f.md) and [OREC](OREC%20101074f5adac80adaff5ec3442ec8f89.md), [Fractalgram](Fractalgram%20198c4a23def749669d9bab38283ef66e.md), and the [Respect Games app](Respect%20Games%20App%2010c074f5adac80ab9ed4e19f74493525.md):

### ORDAO and OREC

ORDAO is a new version of Optimism Fractal software that aims to enhance decentralized onchain governance. At its core is OREC (Optimistic Respect-based Executive Contract), which enables onchain execution of transactions based on community voting using an innovative consent-based system. The ORDAO app consists of EVM smart contracts designed to transfer ownership of the Optimism Fractal community account and decision-making powers to the current Respect distribution within the community.

ORDAO utilizes a non-transferable ERC-1155 NFT system for Respect, which includes metadata about when and how the Respect was earned. It allows for proposing and voting on various types of transactions, including Respect distribution and custom calls. The app features an "OR console" for accessing OREC contract features through a browser console interface, along with a basic UI for Respect Game consensus submissions. A more comprehensive GUI is currently in development by another team.

Developed by Tadas, the ORDAO app has been deployed on the OP Mainnet and is available for use by any community or organization. Interested parties can explore the concept and implementation on GitHub, watch informative video playlists, ask questions in the Optimism Fractal Discord, and participate in ORDAO Office Hours to learn more about this innovative governance solution. 

You can learn more in the articles about [ORDAO](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f.md) and [OREC](OREC%20101074f5adac80adaff5ec3442ec8f89.md). 

![ordao blog thumbnail 1.png](Community%20Delegation%20112074f5adac80cbb06fd76395f4b421/ordao_blog_thumbnail_1.png)

- 
    
    
    /
    
    ORDAO is a set of smart contracts that enables a powerful decentralized onchain governance and award distribution system for Optimism Fractal, as well as other communities or organizations. This app has been developed by Tadas, deployed on Optimism, and is now being actively tested. 
    
    You can learn more in the articles about [ORDAO](ORDAO%20bf8412b1dff24fa8964dcda79474fd6f.md) and [OREC](OREC%20101074f5adac80adaff5ec3442ec8f89.md). 
    
    ORDAO is a code name for a new version of Optimism Fractal software, not yet officially adopted by the community. The core component is [OREC](OREC%20101074f5adac80adaff5ec3442ec8f89.md) (Optimistic Respect-based Executive Contract), which allows for truly decentralized, onchain execution of transactions based on community voting with an innovative consent-based voting system. 
    
    The ORDAO app features a set of EVM smart contracts built with the intention to transfer ownership of the Optimism Fractal community account and onchain decision-making powers to the current Respect distribution of Optimism Fractal. It uses a non-transferable, non-fungible token (NFT) system for [Respect](Respect%206357d339d30b425997f3da4dd6f75f32.md), which includes metadata about when and how the Respect was earned.
    
    ORDAO allows for proposing and voting on various types of transactions, including Respect distribution, custom calls, and more. It features an "OR console" which provides access to all features of the OREC contract through a browser console interface along with a basic UI for Respect Game consensus submissions. A GUI is in development by another team, as you can read in our Fractalgram [article](Fractalgram%20198c4a23def749669d9bab38283ef66e.md).
    
    The ORDAO app is now deployed on the OP Mainnet and may be used by any community or organization. You can explore the concept and implementation in the [Github Repository](https://github.com/sim31/frapps/tree/main/concepts/apps/of2).  You can learn more by reading below and watching the [video playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lmBtLkZ7fEF6luDLBShtWFT), asking questions about ORDAO and OREC Optimism Fractal [discord](https://discord.gg/dJgrP8ekYC), and joining the [ORDAO Office Hours](https://lu.ma/hjj2no0v).
    

- 
    
    In essence, ORDAO is a more decentralized, automated, and flexible governance and award distribution system for Optimism Fractal.
    

### Fractalgram Web App

Development of the next generation Fractalgram web app began in mid-2024, introducing exciting new features to the Optimism Fractal ecosystem and improvements over the current telegram web app. Abraham Becker initiated this project during Onchain Summer, with Howard joining the collaboration in September. 

They are building a comprehensive web application with features that include:

- Wide-ranging wallet connection integrations for seamless user access
- Custom usernames for a personalized experience
- Robust voting functionality to facilitate community decision-making
- Integration with Hats Protocol for enhanced role management
- Planned integration with ORDAO smart contracts for advanced governance features
- Foundations for an all-in-one app to streamline community interactions

You can learn more about this application in our article about [Fractalgram](Fractalgram%20198c4a23def749669d9bab38283ef66e.md). In this article you can see a demo of this application and find more details about their work in an application for Onchain Summer. 

![fractalgram app 1280720.jpg](Fractalgram%20198c4a23def749669d9bab38283ef66e/fractalgram_app_1280720.jpg)

### Respect Games App

The Respect Games platform uses blockchain technology to revolutionize how communities track, evaluate, and reward contributions. Developed by Vlad's team, it creates a transparent, decentralized system for recognizing valuable work within organizations.

They are building a comprehensive web application with features that include:

- User-friendly interface for the Respect Game
- New consensus algorithm for determining contribution value
- Asynchronous submissions with flexible ranking periods
- Onchain contributions for transparency
- Non-transferrable ERC-1155 Respect Tokens
- Liquidity pool integration for rewards
- AI-enhanced contribution summaries (planned)
- Customizable community pages

The app addresses governance challenges through structured work documentation, data-driven decision-making, fair reward distribution, and simplified decentralized governance. Launching in September, it combines peer evaluation, and AI insights to enhance engagement, transparency, and fairness in organizational governance on Optimism.

You can learn [Respect Games app](Respect%20Games%20App%2010c074f5adac80ab9ed4e19f74493525.md) article.

![image.png](Respect%20Games%20App%2010c074f5adac80ab9ed4e19f74493525/image.png)

## Product Development Videos

You can watch these developers share updates about their work at weekly events in this [playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lk5Aavi98CqFj7ryM42bvbP). You can also join the Optimism Fractal [discord](https://discord.gg/dJgrP8ekYC) and see the fractal app channel for more details. For more details about the upcoming apps, you can see our [tools](Optimystics%20Tools%20369941be584c452aac7ce45623b92d06.md) and a two minute [presentation](https://youtu.be/B0b0klPCVzA?si=Tqu8yJYHIGvYLq9J&t=2259) from Dan with some figma designs.

![[https://youtu.be/B0b0klPCVzA](https://youtu.be/B0b0klPCVzA)](Fractal%20Apps%2035f6bfe79a03466da32abff09356c247/EF_94_thumbnail_demo.png)

[https://youtu.be/B0b0klPCVzA](https://youtu.be/B0b0klPCVzA)

### [EF 94: Eden Fractal Products](https://youtu.be/B0b0klPCVzA)

What are the ideal products for optimizing community decision-making? We explore the potential offerings Eden Fractal should develop, focusing on easy-to-implement tools and resources for various audiences 📦

![[https://youtu.be/j9BBB0HHDVU](https://youtu.be/j9BBB0HHDVU)](Fractal%20Apps%2035f6bfe79a03466da32abff09356c247/EF_98_promo_image_final_1280x720.png)

[https://youtu.be/j9BBB0HHDVU](https://youtu.be/j9BBB0HHDVU)

### [EF 98: Customer Needs](https://youtu.be/j9BBB0HHDVU)

What role does product packaging plays in educating society about decision-making? Explore strategies for marketing and packaging Eden Fractal’s tools to aid community and organizational decision-making, focusing on understanding users' needs 🌞

![[https://youtu.be/P18cOpiGPJU](https://youtu.be/P18cOpiGPJU)](Fractal%20Apps%2035f6bfe79a03466da32abff09356c247/EF_103_fractal_pitches_game_thumbnail_resize_1280x720.png)

[https://youtu.be/P18cOpiGPJU](https://youtu.be/P18cOpiGPJU)

### [EF 103: Community Ambitions](https://youtu.be/P18cOpiGPJU)

Why should you implement a fractal consensus process? Thought leaders share innovative pitches, discussing how fractal tools can improve decision-making in various fields and layers of society 🤝🏽🌍🌱

# Historical Progress

## First WebRTC User Interface

In 2022 the [fractally](https://fractally.com) team starting building a similar app and announced plans to open-source it in the future. The WebRTC user interface is hosted on a web app that’s accessible on an internet browser, which enables peer to peer video calls and eliminates dependencies on conferencing services like zoom. The UI enables intuitive drag and drop functionality for selecting the most valued contributions to the community. Elements of the UI will dynamically turn red, yellow, orange, and green to visually indicate the level of consensus reached for each contributor. 

You can watch a funny UI demo video below to gain a better understanding of how the Fractal App facilitates ranking contributions during events. You can also learn more about this innovative, fun, and intuitive app by watching Fractally team members Daniel Larimer and Brandon Fancher also share exciting details about the UI in the last 30 minutes of [Genesis Fractal meeting 24](https://youtu.be/LUglfvP4mG8).

[https://www.youtube.com/watch?v=9k9U_hlWmVE](https://www.youtube.com/watch?v=9k9U_hlWmVE)

[https://www.youtube.com/watch?v=f6nGunlAcCQ](https://www.youtube.com/watch?v=f6nGunlAcCQ)

## Update in Early 2024

Our team member Vlad has been working with several talented builders for over a year to create a comprehensive fractal app that allows any community or organization to coordinate their operations with the [Respect Game](../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Games%20a87953a98246402da3e171f43811bfda/Fractal%20Games%20958dadb96fc940c1a6789e663d36a2c5/Respect%20Game%2097fc60fcf6944c3095df07a64e86b481.md). The first version of such an app is complete on Antelope networks (as you can see [here](https://fractal.upscalenow.io/)) and we’re now planning to port over the software to the EVM in the coming months, while also exploring ways to reach full feature parity on the OP Mainnet to enable everyone to benefit from the Respect Game.

The Fractal App is a web application that offers features such as WebRTC integration for video meetings, automatic video recording, member induction system, automated [Respect](Respect%206357d339d30b425997f3da4dd6f75f32.md) distribution custom token distribution, dynamic permission system of the contract based on member’s Respect, onchain randomization of members into breakout groups during weekly meetings, and onchain ranking validation. Additionally, this app offers a well-designed decentralized system for electing custodians in a dynamic manner, an automatic compensation distribution system, increased engagement with onchain accountability, and potential for further development to enhance collaboration within the community. 

You can learn more about this app in the videos and text below. You can find many more details about the most recent version of this app in this [article](https://medium.com/@vladislavhramtsov/introduction-to-the-fractal-app-7a5b062fb2f7) and learn more about different versions of this app in this [overview](https://edencreators.com/tools#89c00c49528b4fa58c62197f448a1d07). You can also learn more about an earlier version of this app [here](https://medium.com/@vladislavhramtsov/introducing-consensus-games-to-alien-worlds-9d31b7cdafa2) and find more details about the software components to automatically update permissions on this [page](https://edenfractal.com/44). We will also add a direct link to the app so you can experience it for yourself in the near future. Enjoy!

- 
    
    
    One of the unique features of the Fractal App smart contract is an [automated MSIG](https://edenfractal.com/44) functionality that dynamically updates permissions to include the most respected members who have earned the most respect in the past twelve weeks. This functionality is already enabled in [Alien Worlds Fractal](https://edencreators.com/alienworldsfractal) as you can see in this [article](https://medium.com/@vladislavhramtsov/introducing-consensus-games-to-alien-worlds-9d31b7cdafa2) and you can learn more about the app [here](https://edencreators.com/tools#86549b97a26944c0a26f126f15974b51). You can see the Github Repository for the open source software [here](https://github.com/mschoenebeck/zeos1fractal) and learn more in this [article](https://twitter.com/ZEOSonEOS/status/1714710437005013295).
    
    ## Components
    
    There are three main components of the Fractal App: the smart contract, fractal node, and user interface.
    
    One of the unique features of the Fractal App smart contract is an [automated MSIG](https://edenfractal.com/44) functionality that dynamically updates permissions to include the most respected members who have earned the most respect in the past twelve weeks. Other exciting features include the contract holding the application state, the ability to trigger contract state changes through community member actions, privileged actions for respected community members on the automated MSIG, [RNG](https://medium.com/@matthias.schoenebeck/r4ndomnumb3r-7a26d36e8018) for random grouping during meetings, automatic validation of ranking results, claimability of any number of tokens in proportion to respect points, and automatic distribution of eosio.token based on member rankings.
    
    The fractal node includes a web server for user interface access, a Janus WebRTC server for hosting and recording breakout room video sessions, and a simple API for controlling the application. It allows for opening and closing breakout rooms and restricts access to certain rooms based on randomly determined EOS accounts.
    
    The user interface is a browser app that gives community access to the applicatio, facilitates the video sessions and live ranking of the participants, loads the corresponding features depending on the status of the blockchain account, and facilitates membership management, (including the induction system).
    
    ### Features
    
    **Smart contract:**
    
    - Contract owned by most respected WG members as determined by fractal democracy.
    - Contract holds the entire application state.
    - State changes are triggered by community members executing actions on the contract.
    - Some actions are privileged only executable by msiggers.
    - Features RNG for random grouping of the members during the weekly meetings (https://medium.com/@matthias.schoenebeck/r4ndomnumb3r-7a26d36e8018).
    - Automatically validates ranking results.
    - Distributes any eosio.token based on WG members ranking each other.
    
    **Fractal node:**
    
    - Runs web server for the user interface so community members have access to the application.
    - Runs Janus WebRTC server to host and record the breakout room video sessions.
    - Provides a simple API through which the fractally application can be controlled.
    - Opens/closes breakout rooms.
    - Only allows certain EOS accounts access to certain rooms (determined randomly by the smart contract).
    
    **User interface:**
    
    - Browser app
    - Gives community access to the application
    - Facilitates the video sessions and live ranking of the participants
    - Loads the corresponding features depending on the status of the EOS account
    - Facilitates membership management, including the induction system
    
    ## Recent Work
    
    [https://whimsical-boat-be8.notion.site/51d00c9a51b141d4a6ece6adf3aece87?v=933031ba3817477aaa785eff9ea6ab5b](https://www.notion.so/51d00c9a51b141d4a6ece6adf3aece87?pvs=21)
    

### Related Intro Video

[https://youtu.be/SJ2lZbImLdM?si=VxT7jAhnpkWFOsHl](https://youtu.be/SJ2lZbImLdM?si=VxT7jAhnpkWFOsHl)

Get a front-row seat as Vlad takes you on a dynamic tour of the ZEOS Fractal App. Discover the core purpose behind this groundbreaking platform and get an in-depth look at its user interface and standout features.

- 
    
    [https://twitter.com/ZEOSonEOS/status/1708862705384214567](https://twitter.com/ZEOSonEOS/status/1708862705384214567)
    

- List view
    
    
    ### Overview of Features
    
    The first version of the w**eb-app that Vlad is building includes following features:**
    
    1. WebRTC integration for weekly video meetings.
    2. Automatic video recording for all the meetings.
    3. Automated Respect distribution system.
    4. Dynamic permission system of the contract based on member's Respect holdings.
    5. Onchain member randomization into groups for the weekly meetings.
    6. Onchain ranking validation.
    
    ### Overview of Benefits
    
    Benefits of fractal apps include:
    
    1. The contract of the Fractal app constantly at the hands of most respected community members).
    2. Compensation distribution system for members of the community.
    3. Increased accountability and engagement from the community members (onchain proof of participation in the meetings).
    4. Possibility of further development, including additional on-chain modules that further increase the collaboration, productivity and cohesion of the community
    
    This provides a high level overview of benefits provided by the Fractal App and many more details will be added soon. For more details about the benefits of this app, you’re welcome to explore many more [benefits](https://optimystics.io/respectgame#2f4565963b0c4790b75176c0f7c6695f) described in our article about the Respect Game.
    
    - 
        
        
        The Fractal App is a web application that offers features such as WebRTC integration for video meetings, automatic video recording, member induction system, custom token distribution, RESPECT distribution, dynamic permission system of the contract based on member’s Respect, on-chain randomization of members into breakout groups during weekly meetings, and on-chain ranking validation.
        
    
    Many other features have also been developed since this article was written in late 2023 and more details will be added soon.
    

- 
    
    
    ## Relationship with Optimism
    
    The Fractal App is currently built with smart contracts on Antelope blockchains, but all of the software could be ported over to Optimism and Vlad has expressed interest in porting the software. These tools could synergize with helpful primitives on Optimism like ERC-4337 and Hats Protocol. The deep research, development, and live environment testing conducted in another Web3 ecosystem serves a valuable role in refining for their development on Optimism.
    

## Original Optimism Fractal Software

You can learn about the original Optimism Fractal software that is currently in use at [Optimystics.io/tools](http://Optimystics.io/tools).

## Learn More

We will also add a direct link to the app so you can experience it for yourself in the near future. You can find more details about the most recent version of this app in this [article](https://medium.com/@vladislavhramtsov/introduction-to-the-fractal-app-7a5b062fb2f7) and learn more about different versions of this app in this [overview](https://edencreators.com/tools#89c00c49528b4fa58c62197f448a1d07). You can also learn more about an earlier version of this app [here](https://medium.com/@vladislavhramtsov/introducing-consensus-games-to-alien-worlds-9d31b7cdafa2) and find more details about the software components to automatically update permissions in this [episode](https://edenfractal.com/44) of Eden Fractal. Feel free to reach our with any questions or comments :)

## Related Posts

[Untitled](Fractal%20Apps%2035f6bfe79a03466da32abff09356c247/Untitled%204c876869929743d890c48f6b6c404072.csv)

- 
    
    
    ![[https://edencreators.com/consortium](https://edencreators.com/consortium)](../../EdenCreators%20com%20e2e80b29f2c84f54b8dec5b82cc7dbfb/Projects%20Database%20941395d3cd604d3dba244233a96bb5b1/Garden%20dde15c61f98f492e96c3242727c1de8c/Garden%20Database%208c96684e4e9a49a0bf1414f97768d8d7/Consortium%20eb3e4cad890f4dca906f88d39e0b138d/square1.png)
    
    [https://edencreators.com/consortium](https://edencreators.com/consortium)
    
    ### [Consortium](https://www.notion.so/Consortium-eb3e4cad890f4dca906f88d39e0b138d?pvs=21)
    
    A powerful voting application that helps communities make decisions, signal their opinions, and measure consensus.
    
    ![[https://edencreators.com/alienworldsfractal](https://edencreators.com/alienworldsfractal)](../../EdenCreators%20com%20e2e80b29f2c84f54b8dec5b82cc7dbfb/Projects%20Database%20941395d3cd604d3dba244233a96bb5b1/Garden%20dde15c61f98f492e96c3242727c1de8c/Garden%20Database%208c96684e4e9a49a0bf1414f97768d8d7/Consortium%20eb3e4cad890f4dca906f88d39e0b138d/alien_worlds_fractal1.png)
    
    [https://edencreators.com/alienworldsfractal](https://edencreators.com/alienworldsfractal)
    
    ### [Alien World’s ƒractal](https://www.notion.so/Alien-Worlds-Fractal-000d3c32312e4551985c223ecc85862f?pvs=21)
    
    A community of cosmic explorers and intergalactic heroes who play fractal consensus games to create wonderful extropy across the universe!
    
    ![[https://youtu.be/lGf8kXJNVXQ](https://youtu.be/lGf8kXJNVXQ)](../../EdenFractal%20com%2001042c8032d449da996a700c32f78534/Eden%20Fractal%20Website%20Database%20d542ab0a162c46e09a6d1291e836d36b/DEFS%2000aeaea5b65443b091fc536e7145b763/defs8001.png)
    
    [https://youtu.be/lGf8kXJNVXQ](https://youtu.be/lGf8kXJNVXQ)
    
    ## [Discussing Eden Fractal Stuff](https://youtu.be/lGf8kXJNVXQ)
    
    Vlad and Dan discuss the best dogs in the galaxy, our mission, holocracy, cooperative designs, moderation, proposals, opinions, agreements, and more!