# The Roots of Optimism Fractal

Displays on Pages:: 2023, Intro to Optimism, Octant, Optimism Missions, Our Fractal Journey to Optimism, enhancing retropgf
AI summary: The document outlines the origins and development of Optimism Fractal, a community aimed at fostering collaboration and public goods creation within the Optimism Superchain. It discusses the community's activities, including the Respect Game, and its connections with other fractal communities.
AI summary 1: In this blog post, we delve into the origins and evolution of Optimism Fractal, a community aimed at fostering collaboration and supporting public good creators within the Optimism Superchain. We explore how Optimism Fractal sprouted from the foundations laid by Eden Fractal, highlighting key events leading to its launch in October 2023. Readers will gain insights into the community's mission, the innovative Respect Game, and the ongoing efforts to enhance governance and public goods funding. Join us as we navigate the journey of Optimism Fractal and its potential impact on communities striving for a better future.
Description: Explore the early history of Optimism Fractal, how it sprouted out of Eden Fractal, and more of our early roots! 🌱
Published?: Yes

![optimism fractal rainbow 2 - 720.png](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/optimism_fractal_rainbow_2_-_720.png)

## Welcome

This article provides an overview how Optimism Fractal started in October 2023 and the events around it’s launch. For a deeper dive into our rich history that led to Optimism Fractal, you can see this [post](https://optimystics.io/blog/fractalhistory). Enjoy!

**Table of Contents**

![sunny flower with short stem roots232.png](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/sunny_flower_with_short_stem_roots232.png)

## What is Optimism Fractal?

**Optimism Fractal is a community dedicated to fostering collaboration, awarding public good creators, and optimizing governance on the Optimism Superchain.**

Optimism Fractal features an innovative social game called the [Respect Game](https://optimystics.io/respectgame), where community members rank each other’s contributions to Optimism during weekly meetings and earn respect for helping the Collective. In addition to being a wonderful way to meet amazing people, this consensus game has proven to be profoundly helpful in empowering communities to create public goods, foster meaningful collaborations, and coordinate for mutual benefit. Everyone is welcome to join Optimism Fractal [weekly events](https://lu.ma/optimystics) on Thursdays at 17 UTC. These meetings provides a perfect place to have fun while networking with talented builders and build your reputation by sharing what you’ve done to help the Superchain. 

We welcome you to watch the [first episode](https://optimystics.io/blog/optimystic-articles/welcome-to-optimism-fractal) of Optimism Fractal for an introduction from the Optimystics, including an overview of the Respect Game and a tour of our first OP Stack tools. You can watch all episodes of Optimism Fractal and learn more at [OptimismFractal.com](http://OptimismFractal.com).

![[http://lu.ma/optimismfractal](http://lu.ma/optimismfractal)](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/optimism_fractal_thursday_17_.png)

[http://lu.ma/optimismfractal](http://lu.ma/optimismfractal)

## The Sprouting of Optimism Fractal

### Early Origins: 2021-2023

Optimism Fractal is rooted in profound wisdom designed to help communities thrive and it’s processes have been rigorously honed by hundreds of the builders for over four years. You can read [A History of Fractal Communities](https://optimystics.io/blog/our-fractal-journey-to-optimism) for a deep dive into our epic history, the evolution of fractal community growth, and revelations about how these fractal innovations can create profound benefits for the Optimism Collective.

Optimism Fractal is inspired by [Eden Fractal](https://edenfractal.com/) and [Fractally](https://fractally.com/), trailblazing communities of brilliant innovators that have been perfecting processes for community cooperation for over three years. We’ve been avidly focused on retroactive public goods funding and improving governance for years, so we became fascinated when we discovered Optimism. After months of development, creators of Eden Fractal started the Optimystics team and launched Optimism Fractal in October, 2023. 

![fractal history 3.png](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/fractal_history_3.png)

### Original Mission Proposal for Optimism Grants Council

The Optimystics  created a grant [proposal](https://app.charmverse.io/op-grants/page-8947154553563161) that outlined plans to start Optimism Fractal in August and followed up with an [addendum](https://bit.ly/46IqHQX) with more details for the reviewers of the Optimism Grants Council. We discussed our progress and shared educational content with community members in Eden Fractal meeting each week, then produced awesome videos and created comprehensive show notes about each meeting to help everyone enjoy the benefits of Optimism. 

### Growing Optimism Fractal with Eden Fractal

After making the proposal, Dan Singjoy hosted several Eden Fractal events and shared detailed walkthroughs of the Grants Council Proposal processes with dozens of Web3 community leaders. Then we created several videos and articles about the presentations and discussions, as you can see in the following links ([1](https://optimystics.io/blog/optimism-fractal-and-optimism-grants-council), [2](https://optimystics.io/blog/optimism-fractal-grant-proposal), and [3](https://optimystics.io/blog/retropgf-and-optimism-grant-opportunities)). These articles provide an educational resource for anyone interested in participating in Optimism Grants Council programs.

You can follow the epic journey and see how Optimism Fractal emerged by exploring show notes for episodes of Eden Fractal below or this [playlist](https://www.youtube.com/playlist?list=PLa5URJF9l5lnG4TEQj-57IX6dFtC3LAvt). In the past months, talented developers have built tools that enable anyone to grow their community with fractal consensus games on Optimism. This includes a set of smart contracts and intuitive app called Fractalgram where players can play the Respect Game on the [OP Stack](https://optimism.mirror.xyz/fLk5UGjZDiXFuvQh6R_HscMQuuY9ABYNF7PI76-qJYs). This sets the stage for the next step in the evolution of human collaboration, powered by Optimism. 

The Eden Fractal community has discussed Optimism and Optimism Fractal in each meeting since their 66th episode. You can watch full episodes and explore detailed show notes where the Eden Fractal community started discussing Optimism and rallying around the launch of Optimism Fractal below.

![[https://edenfractal.com/66](https://edenfractal.com/66)](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/EF_66_msig_thumbnail_final.png)

[https://edenfractal.com/66](https://edenfractal.com/66)

### [**EF 66: Permission Possible**](https://edenfractal.com/66)

Hip hip hooray! Our mythical heroes approved three proposals to update the eden.fractal permissions and explored an introduction to the Optimism Collective, a new type of community designed to reward public goods and build a sustainable future for all 🌞 

![[https://edenfractal.com/67](https://edenfractal.com/67)](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/EF_67_msig_new_sunny_final.png)

[https://edenfractal.com/67](https://edenfractal.com/67)

### [EF 67: Growing with Optimism](https://edenfractal.com/67)

What are the synergies between Eden Fractal and Optimism? In the next stage of our epic journey we explore opportunities to help humanity flourish and summon Ether’s Phoenix with innovations in retroactive public goods funding 🔴 ✨

![[https://edenfractal.com/68](https://edenfractal.com/68)](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/EF_68_thumbnail_final.png)

[https://edenfractal.com/68](https://edenfractal.com/68)

### [EF 68: Planting Optimism Fractal](https://edenfractal.com/68)

What are the best ways to grow communities that create public goods? We explore the new Optimism Fractal proposal, RetroPGF, and other exciting opportunities for public goods creators in the Optimism ecosystem 🌱 🌻

![[https://edenfractal.com/69](https://edenfractal.com/69)](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/EF_69_thumbnail_demo2.png)

[https://edenfractal.com/69](https://edenfractal.com/69)

### [**EF 69: Regeneration Nation**](https://edenfractal.com/69)

What are the best ways to build a more regenerative society? We explore Optimism Fractal, RetroPGF Round 3, and the Interplanetary Unconference to help create a peaceful, sustainable future for all 🌻 🌞

![[https://www.youtube.com/watch?v=DOsg5ntH_VY](https://www.youtube.com/watch?v=DOsg5ntH_VY)](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/EF_70_thumbnail_demo.png)

[https://www.youtube.com/watch?v=DOsg5ntH_VY](https://www.youtube.com/watch?v=DOsg5ntH_VY)

### [EF 70: Fractal Fruits](https://www.youtube.com/watch?v=DOsg5ntH_VY)

How can we inspire an abundant society that rewards public goods creators? The Eden Fractal gardeners explore magical innovations like RetroPGF, Optimism Fractal, and Aquadac to help foster community collaboration 🌳✨

![[https://youtu.be/ZFoAoZgwx3g](https://youtu.be/ZFoAoZgwx3g)](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/EF_72_thumbnail_demo.png)

[https://youtu.be/ZFoAoZgwx3g](https://youtu.be/ZFoAoZgwx3g)

### [EF 72: Optimism Fractal Benefits](https://youtu.be/ZFoAoZgwx3g)

How does Optimism Fractal benefit communities? We nurture the sprouting Optimism Fractal and explore the profound benefits it can create for the Optimism Collective 🌻 🔴

## Optimism Fractal, Season 1

After a successful launch, the Optimism Fractal community has continued to meet for weekly events and grow while developing the foundations for the future. You can watch each episode of Optimism Fractal and explore show notes at [OptimismFractal.com/videos](http://OptimismFractal.com/videos). You can also watch hundreds of related videos on the Eden Creators [youtube channel](https://www.youtube.com/@EdenCreators).  The first four episodes are provided below for anyone who would like to watch the first Optimism Fractal events. 

![[https://optimismfractal.com/1](https://optimismfractal.com/1)](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/optimism_fractal_1_thumbnail_demo.png)

[https://optimismfractal.com/1](https://optimismfractal.com/1)

### [**OF 1: Welcome to Optimism Fractal!**](https://optimismfractal.com/1)

As sunlight shines, sunflowers bloom! In the first episode of Optimism Fractal, the Optimystics embark and introduce a fun consensus game to create profound benefits for the Optimism Collective! 🌻 🌞 🔴

![[https://optimismfractal.com/2](https://optimismfractal.com/2)](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/optimism_fractal_2_thumbnail_demo.png)

[https://optimismfractal.com/2](https://optimismfractal.com/2)

### [OF 2: Illuminating Public Goods](https://optimismfractal.com/2)

What are the best ways to award public goods creators? In the second episode of Optimism Fractal we play the Respect Game and highlight the brilliant work of visionary Optimists 🌻 🔴 ✨

![[https://optimismfractal.com/3](https://optimismfractal.com/3)](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/OF_3_thumbnail_demo.png)

[https://optimismfractal.com/3](https://optimismfractal.com/3)

### [OF 3: Doing Cool Things](https://optimismfractal.com/3)

How can public goods creators get the recognition they deserve? We play an awesome Respect Game to foster collaborations and put a spotlight on pioneering builders in the Optimism Collective 🌱 🔴 ☀️

![[https://optimismfractal.com/4](https://optimismfractal.com/4)](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/optimism_fractal_4_thumbnail_downloaded_from_Youtube.webp)

[https://optimismfractal.com/4](https://optimismfractal.com/4)

### [OF 4: Collective Collaborations](https://optimismfractal.com/4)

What are the best ways to grow thriving communities? We welcome talented newcomers, share educational resources, and play a game of respect to award public goods creators at Optimism Fractal 🪴 🔴 🌻

## What is Optimism, anyway?

Optimism Fractal is working with an exciting Ethereum L2 ecosystem called [Optimism](https://www.optimism.io/) that is highly aligned with our goals of funding public goods and coordinating humanity for everyone’s benefit.

The [Optimism Collective](https://app.optimism.io/announcement) is pioneering a fascinating bicameral governance system focused on rewarding positive impact with profit, building a Superchain with some of the most world’s most successful companies (including OpenAI and Coinbase), and running the world’s largest system for retroactive public goods funding ([RetroPGF](https://app.optimism.io/retropgf)). The first rounds of RetroPGF have been highly acclaimed by many brilliant thought leaders, such as Vitalik Buterin.

We believe that Optimism provides an ideal environment to foster the growth of fractal communities and are stoked about how Optimism Fractal can create profound benefits by helping countless communities to grow with Optimism. You can learn more about Optimism in our video and articles below.

[https://youtu.be/v3iJvTQLCGU?si=2W7WsuXGTq2nq7-7](https://youtu.be/v3iJvTQLCGU?si=2W7WsuXGTq2nq7-7)

## Related Posts

[Untitled](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/Untitled%20c05f6462b9bf484f8c0330398245b7fa.csv)

- 
    
    ![DALL·E 2023-10-21 11.52.49 - Illustration of a bright and gorgeous sunflower with its center morphing into a black hole. The surrounding space is illuminated with vibrant colors, 2215.png](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/DALLE_2023-10-21_11.52.49_-_Illustration_of_a_bright_and_gorgeous_sunflower_with_its_center_morphing_into_a_black_hole._The_surrounding_space_is_illuminated_with_vibrant_colors_2215.png)
    
    ![optimism fractal text golden 1.png](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/optimism_fractal_text_golden_1.png)