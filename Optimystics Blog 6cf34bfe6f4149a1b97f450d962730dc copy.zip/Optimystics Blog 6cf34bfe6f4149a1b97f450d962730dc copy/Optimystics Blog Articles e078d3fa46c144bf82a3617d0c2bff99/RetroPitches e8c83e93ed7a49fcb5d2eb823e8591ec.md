# RetroPitches

AI summary: RetroPitches are engaging competitions where applicants present their projects for RetroPGF grants, allowing participants to rank the pitches and learn about various public goods initiatives. These events aim to promote awareness and collaboration within the Optimism Collective.
AI summary 1: In this blog post, we introduce RetroPitches, an exciting initiative that showcases the innovative projects of RetroPGF applicants through fun and competitive pitch games. RetroPitches provide a unique platform for public goods creators to present their ideas, engage with participants, and receive valuable feedback. We explore the format of these games, highlight their significance in promoting public goods, and discuss the synergies with the Respect Game. Join us as we delve into the history, future, and impact of RetroPitches in fostering a vibrant community around public goods initiatives.
Published?: No

![retropgf pitches final image.png](RetroPitches%20e8c83e93ed7a49fcb5d2eb823e8591ec/retropgf_pitches_final_image.png)

## What are RetroPitches?

We’re thrilled to share RetroPGF Pitch Games, aka RetroPitches! 🌞

RetroPitches are fun, friendly competitions where RetroPGF applicants present their projects and participants rank their pitches. These games give public goods creators a great opportunity to promote their RetroPGF grant and provide citizens with an easy way to learn about exciting projects in the Optimism Collective.

The first season of these innovative public goods games occur throughout the third round of RetroPGF. RetroPitches happen on zoom calls after Optimism Fractal events and each participating project gets up to five minutes to pitch their grant.  You’re also welcome to join an hour earlier to play the Respect Game, which also provides many benefits for RetroPGF grantees and citizens of Optimism. 

You can learn more about RetroPitches and sign up to pitch in the [announcement post](https://gov.optimism.io/t/introducing-retropgf-pitch-games/7122). Everyone is welcome to join the events and help determine the winners of the game. You can join on the [event page](https://lu.ma/retropitches) and share the intro [tweet](https://twitter.com/optimystics_/status/1725949361710915988) to help spread the word. We looking forward to seeing your pitches and hope you enjoy the events! 🔴 ✨

![Untitled](RetroPitches%20e8c83e93ed7a49fcb5d2eb823e8591ec/Untitled.png)

**Table of Contents**

## RetroPitch Videos

RetroPitch games are recorded and shared on social media to further raise awareness for public goods creators. You can watch episodes of RetroPitches below and watch full episodes of Optimism Fractal with more public goods games on our [videos](../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Optimystics%20Videos%204aa0cc0fe82f46fd8fb6a8548b7a5732.md) page.

[https://youtu.be/wFc02QUdLjg](https://youtu.be/wFc02QUdLjg)

### RetroPitches 3

How can public goods creators spread the word about their work? RetroPGF applicants share presentations then judges vote on the most impactful, exciting, heartwarming, and fun pitches 🎤 🏟️ ✨

![[https://youtu.be/I0Y-j1nEGQA](https://youtu.be/I0Y-j1nEGQA)](RetroPitches%20e8c83e93ed7a49fcb5d2eb823e8591ec/retropgf_pitches_2_thumbnail_draft.png)

[https://youtu.be/I0Y-j1nEGQA](https://youtu.be/I0Y-j1nEGQA)

### [RetroPitches 2](https://youtu.be/I0Y-j1nEGQA)

How can public goods games grow Optimism? In the second RetroPitch event we give a spotlight for RetroPGF applicants and participants rank the most helpful, exciting, and fun pitches  🌱 🔴 🏟️

![[https://youtu.be/IYwhREMx84Y](https://youtu.be/IYwhREMx84Y)](RetroPitches%20e8c83e93ed7a49fcb5d2eb823e8591ec/retropgf_pitches_1_thumbnail.png)

[https://youtu.be/IYwhREMx84Y](https://youtu.be/IYwhREMx84Y)

### [RetroPitches 1](https://youtu.be/IYwhREMx84Y)

We debut the RetroPitch games to help public goods creators promote their RetroPGF grant and give citizens an easy way to learn about exciting projects in the Optimism Collective 🔴 🌟

![[https://optimismfractal.com/6](https://optimismfractal.com/6)](../../OptimismFractal%20com%20c238e1244229466ba8b7753b74104b6f/Optimism%20Fractal%20Website%20Database%20f636c69e7a3a4435a2163516c9e87249/Media%20eac86b8f965a415c9a69c2b58aa97103/optimism_fractal_6_thumbnail_final_.png)

[https://optimismfractal.com/6](https://optimismfractal.com/6)

### [OF 6: Public Goods Games](https://optimismfractal.com/6)

What are the best ways to promote public goods creators and help citizens fairly reward impact? We play the Respect Game and RetroPGF Pitch Game to measure the output of outstanding buidlers in the Optimism Collective 🏟️ 🔴 ✨

![[https://optimismfractal.com/5](https://optimismfractal.com/5)](../../Optimystics%20io%2019f664ef7b684e0495c75a9ed7ed2476/Optimystics%20Website%2084e6f8ba02f842c0a52481435ecb160f/Optimystics%20Videos%204aa0cc0fe82f46fd8fb6a8548b7a5732/optimism_fractal_5_thumbnail_final.png)

[https://optimismfractal.com/5](https://optimismfractal.com/5)

### [**OF 5: Respect Games and RetroPitches!**](https://optimismfractal.com/5)

How can consensus games create profound benefits for all? We set the stage at Optimism Fractal for a joyful Respect Game and the first RetroPGF Pitch Game to amplify the power of public goods creators ⚡️🌞 🔴

## Synergies with the Respect Game

The [Respect Game](https://optimystics.io/respectgame) is a profoundly helpful consensus game that provides a fun way to foster collaborations, promote public goods creators, and fairly award positive impact. There are many synergies between RetroPitches and the Respect Game, such as enabling RetroPitch judges to vote on pitches with their [Respect](https://optimystics.io/respect). You can find more details about this below and stay tuned for more!

![respect game players 1.png](RetroPitches%20e8c83e93ed7a49fcb5d2eb823e8591ec/respect_game_players_1.png)

## The History and Future of RetroPitches

The RetroPitches games have a rich history and exciting future with many resources to explore.  You can learn more about the exciting history and future of RetroPitches in this [article](https://optimystics.io/exploringretropitches). 

We believe that [public goods games](Public%20Goods%20Games%20a30eee3f0d1d4becaaca9ac7ca191e4b.md) like RetroPitches will create profound benefits by providing a spotlight for all public goods creators and sharing fun experiences that help citizens evaluate impact in the Optimism Collective. As RetroPGF grows with many more applicants in future rounds, we envision that these kinds of games will become an essential tradition that enables retroactive public goods funding to thrive at scale.

![[https://optimystics.io/exploringretropitches](https://optimystics.io/exploringretropitches)](The%20History%20and%20Future%20of%20RetroPitches%2014521d4dd77d44ef98db076dbbaf4fd5/Untitled.png)

[https://optimystics.io/exploringretropitches](https://optimystics.io/exploringretropitches)

- 
    
    
    [Exploring RetroPitches](RetroPitches%20e8c83e93ed7a49fcb5d2eb823e8591ec/Exploring%20RetroPitches%2068097132274e4367830c63b3d379bfa1.md)
    

## Related Posts

[Untitled](RetroPitches%20e8c83e93ed7a49fcb5d2eb823e8591ec/Untitled%20de7f40d5071e4b3c90443067a2958b3f.csv)