# Optimism Fractal Development Hub

Displays on Pages:: Fractal App, Fractalgram, ORDAO, OREC, Respect Game, Respect Games App, Tools, op fractal stack
AI summary: The Optimism Fractal Development Hub is a collaborative space and educational resource designed for developers interested in building with the Optimism Fractal. It offers access to projects, tasks, and various resources to facilitate technical development and community engagement.
AI summary 1: In this blog post, we introduce the Optimism Fractal Development Hub, a collaborative space designed to support developers interested in creating with Optimism Fractal. This hub serves as an educational resource, offering a variety of projects, tasks, and essential information for developers. We discuss the importance of community involvement, the opportunities available for contribution, and the resources provided within the hub. Additionally, we outline the potential funding opportunities for developers who make a positive impact on the Optimism Collective. Join us as we explore how you can engage with this vibrant community and contribute to the exciting developments happening within the Optimism Fractal ecosystem.
Description: A collaborative space and educational resource for developers who are interested in building with Optimism Fractal. It includes projects, tasks, and info related to Optimism Fractal development.
Published?: Yes

![development hub2.png](Optimism%20Fractal%20Development%20Hub%2010d074f5adac80dca940f8c067707158/development_hub2.png)

## Introduction

The Optimism Fractal [Development Hub](https://bit.ly/Optimism-Fractal-Development-Hub) provides an informative, collaborative space for developers who are interested in building with Optimism Fractal. It provides a place where you can find resources, projects, and tasks related to technical development for Optimism Fractal and our products. With open development strategy we aim to inspire many people to contribute to the development of Optimism Fractal and the Respect Game. 

**Table of Contents**

## Optimism Fractal Notion Site

This hub is part of the Optimism Fractal [notion site](https://bit.ly/optimismfractalnotion), which fosters a collaborative community-driven approach to the development of Optimism Fractal. where you can learn more about our community and explore various ways that you can get involved. This site includes a development hub, educational hub, and other resources to help you start building with the Superchain.

You may also want to explore the blog or tools on [Optimystics.io](http://optimystics.io/) and the basics at [OptimismFractal.com/details](http://optimismfractal.com/details). These may provide a better introductory overview than the development site, while the development hub provides projects, tasks, and much of the latest research. We can provide guidance if there’s anything in particular that you want to explore deeper.

## Projects and Tasks

At the core of the Optimism Fractal development hub are well-organized databases of projects and tasks related to the development of Optimism Fractal, the Collective, and the Superchain. You can see some screenshots below for examples of how this looks and explore the Optimism Fractal [Development Hub](https://bit.ly/Optimism-Fractal-Development-Hub) to get involved.

![image.png](Optimism%20Fractal%20Development%20Hub%2010d074f5adac80dca940f8c067707158/image.png)

![image.png](Optimism%20Fractal%20Development%20Hub%2010d074f5adac80dca940f8c067707158/image%201.png)

## Start Contributing

There are many opportunities to contribute to the development of Optimism Fractal and we’re excited to collaborate. The best way to get started is to join our [weekly events](https://lu.ma/4ggdpzyp), explore the notion site, and ask any questions that come to mind in our [discord](https://discord.gg/dJgrP8ekYC). We greatly appreciate help your interest in building with Optimism Fractal and are happy to help you however we can. 

There’s a lot to build with Optimism Fractal and many ways that you can contribute. For example, if you want to help with smart contract development then there are a couple open-source codebases for fractal apps that you might want to look into and start contributing towards. We also have many exciting conceptual designs for tools and features that you can start building if you’d like. A lot of the software we’re developing is well documented in various articles, videos, code repositories, and notion projects so there’s lots of ways to start building.

In addition to technical development we’re also always looking for people to help spread the word, create educational content, and contribute in a wide variety of other ways. It’s up to you to contribute however you see fit and joining the weekly events is an excellent way to help support the community while also learning how to best contribute. We also recommend exploring the website and listening to the videos to get a feel for what the community needs and how it makes the most sense for you to get more involved.

Let us know if there’s any way in particular that you want to help and we can provide you with resources or help you connect with others if you’d like. There are a lot of great resources that you might want to look into as you get started and it depends on how you want to help Feel free to reach out with questions in the discord or at the events as well, there are also many other community members that would be glad to help you and following along there is a good way to stay up to date on the latest technical projects where you may want to get involved. 

## Funding Opportunities

Developers who contribute to Optimism Fractal and make a positive impact on Optimism Collective may be eligible to earn [RetroFunding](https://optimism.mirror.xyz/nz5II2tucf3k8tJ76O6HWwvidLB6TLQXszmMnlnhxWU), as you can see [here](https://youtu.be/5FeRMLjw0yY?si=bks4xqP6W-2q-v6u&t=3421). There are many funding opportunities for developers building with Optimism Fractal and we’re working to curate these opportunities in this [project](https://www.notion.so/Build-Optimism-Fractal-Development-Hub-and-Create-Educational-Resources-for-Builders-1b19b1098081451c9f593c4bd5552f3b?pvs=21). 

## About the Development Hub

This [development hub](https://bit.ly/Optimism-Fractal-Development-Hub) is a work in progress and is updated frequently. The hub is intended to be a collaborative community-driven project and there are many opportunities to help build it. If you’re interested in contributing to this development hub and helping more developers start building with Optimism Fractal, please let us know and see this [project](https://bit.ly/developmenthubproject) for more details.  

## Related Posts

Thanks for reading. Here are articles about software, games, and apps built by the Optimism Fractal community:

[Untitled](Optimism%20Fractal%20Development%20Hub%2010d074f5adac80dca940f8c067707158/Untitled%2010d074f5adac80d09f0cdd92aa6fdb67.csv)