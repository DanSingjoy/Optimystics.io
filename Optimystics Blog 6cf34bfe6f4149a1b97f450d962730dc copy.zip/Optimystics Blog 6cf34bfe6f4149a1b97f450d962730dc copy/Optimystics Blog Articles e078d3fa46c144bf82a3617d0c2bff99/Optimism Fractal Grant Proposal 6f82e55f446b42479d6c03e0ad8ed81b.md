# Optimism Fractal Grant Proposal

Displays on Pages:: 2023, EF 67, Optimism Missions, Roots of Optimism Fractal, missions
AI summary: The Optimism Fractal Grant Proposal seeks to enhance the Optimism Collective by developing collaborative games, tools, and shows, as outlined in their mid-2023 initiative. This proposal is part of a broader vision to foster synergies within the Optimism community.
AI summary 1: In this blog post, we explore the Optimism Fractal Grant Proposal, a groundbreaking initiative aimed at enhancing the Optimism Collective through innovative collaborative games, tools, and shows. Originally proposed in mid-2023, this initiative seeks to foster community engagement and creativity within the Optimism ecosystem. We will discuss the key elements of the proposal, its intended impact on the community, and how it aligns with the broader goals of the Optimism Fractal. Join us as we delve into the vision that drives this exciting endeavor and the synergies that are emerging in the vibrant Optimism city.
Description: The Optimism Fractal proposal from mid-2023 aimed to empower the Optimism Collective with the next generation of collaborative games, tools, and shows at Optimism Fractal
Published?: Yes

![original proposal 2.png](Optimism%20Fractal%20Grant%20Proposal%206f82e55f446b42479d6c03e0ad8ed81b/original_proposal_2.png)

### Welcome!

Hello fellow traveler, thanks for stopping by! We hope you enjoy the vision and emerging synergies in the Optimism city 🔴 🌇 🎩

### Optimism Fractal Grant Proposal

The Optimism Fractal proposal aims to empower the Optimism ecosystem with the next generation of collaborative games, tools, and shows pioneered by [Eden Fractal](https://edenfractal.com/) and [ƒractally](https://fractally.com/). We invite you to read more in Eden Fractal’s recent [show notes](https://edenfractal.com/66#03a2f9592d464076aef6834d6e25d009). You can read the full proposal [here](https://app.charmverse.io/op-grants/proposals?id=c13749af-eea6-407a-8973-09bc29c95266) and explore the article to learn more.

Following on from the last Eden Fractal meeting where the Optimism Fractal grant was presented between [2:04:06](https://youtu.be/uDFrqdLmp8I?t=7446) - [2:09:01](https://www.youtube.com/watch?v=uDFrqdLmp8I&t=7741s), the high interest in collaboration amongst players strongly persisted. The interest continued going up rapidly ever since the topic was mentioned between [1:30:15](https://youtu.be/xX3n_bMigAM?t=5415)[1:31:05](https://youtu.be/xX3n_bMigAM?t=5467), which opened the floor for an enthusiastic group discussion. The main sub-topics discussed were an exploration of the Optimism Grants Council processes and ways that the Optimism Fractal grant can support Eden Fractal members, with a focus on the wider Optimism community starting at [1:34:30](https://www.youtube.com/watch?v=xX3n_bMigAM&t=5670s).

The discussion around Optimism Fractal’s grant plan was going in full steam at [1:39:56](https://www.youtube.com/watch?v=xX3n_bMigAM&t=5996s), then followed by a group discussion on software development and EVM implementation for Optimism community chain between [1:45:06](https://www.youtube.com/watch?v=xX3n_bMigAM&t=6306s) - [1:54:16](https://www.youtube.com/watch?v=xX3n_bMigAM&t=6856s). This acted as a smooth segway to a naturally formed Q and A session where Optimism Fractal, Eden Fractal and RetroPGF benefits and synergies were beautifully composed. This conveyed the root message and mutual aim to create more public goods, one being the Optimism Fractal grant proposal explored in-depth between [2:02:01](https://www.youtube.com/watch?v=xX3n_bMigAM&t=7321s)-[2:07:47](https://youtu.be/xX3n_bMigAM?t=7667). 

The discussion provided details on the application process and a variety of gra, whilst opening the door for inspiring collaborations in the Optimism ecosystem. Follow along and get involved in future episodes for more about Optimism Fractal!

[https://youtu.be/xX3n_bMigAM](https://youtu.be/xX3n_bMigAM)

**EF 67: Growing with Optimism**

What are the synergies between Eden Fractal and Optimism? In the next stage of our epic journey we explore opportunities to help humanity flourish and summon Ether’s Phoenix with innovations in retroactive public goods funding 🌱 🌞

Date: September 13th, 2023

**Note**: *Some of this article was originally written and published in the [show notes](https://edenfractal.com/67) for Eden Fractal’s 67th episode.*