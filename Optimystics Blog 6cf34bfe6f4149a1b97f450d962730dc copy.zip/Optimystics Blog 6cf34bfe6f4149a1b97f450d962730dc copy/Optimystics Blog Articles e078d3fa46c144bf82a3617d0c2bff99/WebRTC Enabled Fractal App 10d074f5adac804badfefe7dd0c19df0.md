# WebRTC Enabled Fractal App

Displays on Pages:: Tools
AI summary: The document discusses the development of a WebRTC-enabled fractal application that is not yet published. It also mentions ongoing communication with the Livepeer founder for potential integration of Livepeer's services.
AI summary 1: In this blog post, we will explore the innovative WebRTC-enabled Fractal application, designed to enhance real-time communication and collaboration. We will discuss its features, the technology behind it, and how it leverages Livepeer's services to improve user experience. Join us as we delve into the potential of this application and its implications for the future of online interaction.
Published?: No

We’re in communication with the Livepeer founder to integrate Livepeer’s services.

- [ ]  add from [Fractal Apps](Fractal%20Apps%2035f6bfe79a03466da32abff09356c247.md)