# Intro to Optimism

Displays on Pages:: EF 66, Intro to Optimism, Our Fractal Journey to Optimism, Roots of Optimism Fractal
AI summary: This document introduces the Optimism Collective, a community focused on rewarding public goods and fostering a sustainable future through innovative projects. It includes details about the Optimism Fractal proposal, its alignment with Eden Fractal's values, and resources for further exploration.
AI summary 1: In this blog post, we delve into the concept of Optimism and its transformative potential within the decentralized community landscape. The Optimism Collective is introduced as a pioneering initiative aimed at rewarding public goods and fostering a sustainable future for the open internet. We explore the significant developments within this new community, including its alignment with Eden Fractal's values, and discuss key innovations such as RetroPGF and the Superchain. Additionally, we highlight the importance of collaborative tools and games in empowering communities and enhancing mechanisms for funding public goods. Join us as we embark on an enlightening journey through the principles and projects driving the Optimism ecosystem.
Description: The Optimism Collective is a new type of community designed to reward public goods and build a sustainable future for all 🔴 ✨
Published?: Yes

![intro to optimism image small font.png](Intro%20to%20Optimism%20e5fb1de4d081486193bae5efbd3ae977/intro_to_optimism_image_small_font.png)

Hello fellow traveller,

Thanks for stopping by, we hope you are having a very optimistic day! This article was written in September 2023 and provides timestamps from a live discussion with community leaders during the 66th Eden Fractal meeting, which you can see below or in the original [show notes](https://edenfractal.com/66). Enjoy!

### What is Optimism?

The [Optimism Collective](https://app.optimism.io/announcement) is a new type of community designed to reward public goods and build a sustainable future for the open internet. Optimism is a pioneering [Ethereum](https://ethereum.org/en/) L2 community that is highly aligned with Eden Fractal’s values for creating public goods and improving human coordination for everyone’s benefit. 

We encourage you to watch Dan Singjoy’s introductory presentation about Optimism at [1:50:20](https://www.youtube.com/watch?v=uDFrqdLmp8I&t=6620s) and a presentation about a grant [proposal](https://app.charmverse.io/op-grants/page-8947154553563161) to start a new community called Optimism Fractal at [2:03:55](https://youtu.be/uDFrqdLmp8I?si=dBv3M_RWEoDbaaPi&t=7435). The introductory presentation provides an overview of brilliant innovations from The Optimism Collective, including [RetroPGF](https://app.optimism.io/retropgf), [Superchain](https://app.optimism.io/superchain), and the [Optimistic Vision](https://www.optimism.io/vision). 

We’re excited to share more educational resources about Optimism to help grow abundant communities, improve humanity’s mechanisms for funding public goods, and create profound benefits for all. You can watch our [videos](https://youtube.com/playlist?list=PLa5URJF9l5lkX4t8YMZ7wytDZggdXeFor&si=uRVou-Ho0RFpnD1u), explore our [show notes](https://edenfractal.com/videos), and join our events in future weeks to take part in our epic journey as Eden Fractal starts growing with Optimism. You can learn more exciting details about Optimism in this [article](https://optimystics.io/blog/intro-to-optimism), [announcement](https://app.optimism.io/announcement), and [Optimism.io](http://Optimism.io)! 🔴

### Optimism Fractal Original Proposal

The Optimism Fractal proposal aims to empower the Optimism ecosystem with the next generation of collaborative games, tools, and shows pioneered by [Eden Fractal](https://edenfractal.com/) and [ƒractally](https://fractally.com/). In addition to helping Optimism, the proposal aims to empower all communities with tools for fractal consensus games and independent cooperation on the Ethereum Virtual Machine (or [EVM](https://ethereum.org/en/developers/docs/evm/)) and [OP Stack](https://optimism.mirror.xyz/fLk5UGjZDiXFuvQh6R_HscMQuuY9ABYNF7PI76-qJYs), which are the world’s leading software infrastructures for decentralized computing. These presentations set the stage for many fascinating community discussions about the synergies between Eden Fractal and the Optimism ecosystem.  

### Video Clip

In the video below we provide an overview of Optimism, including the Superchain, retroactive public goods funding aka RetroPGF, bicameral governance structure, and synergies with fractal communities.

[https://www.youtube.com/watch?v=v3iJvTQLCGU&list=PLa5URJF9l5lnG4TEQj-57IX6dFtC3LAvt&index=2](https://www.youtube.com/watch?v=v3iJvTQLCGU&list=PLa5URJF9l5lnG4TEQj-57IX6dFtC3LAvt&index=2)

This video was recorded during the 66th Eden Fractal meeting. You can see the full episode here and learn more in our and learn more about our series Growing Optimism with Eden Fractal.

- 
    
    
     The Optimism Fractal proposal aims to empower the Optimism ecosystem with the next generation of collaborative games, tools, and shows pioneered by [Eden Fractal](https://edenfractal.com/) and [ƒractally](https://fractally.com/). In addition to starting the new Optimism Fractal community, these social tools highly support independent cooperation on the Ethereum Virtual Machine (or [EVM](https://ethereum.org/en/developers/docs/evm/)) and [OP Stack](https://optimism.mirror.xyz/fLk5UGjZDiXFuvQh6R_HscMQuuY9ABYNF7PI76-qJYs), which are the world’s leading software stacks for decentralized computing. These presentations set the stage for many fascinating community discussions about the synergies between Eden Fractal and the Optimism ecosystem.  
    

## Related Posts

You can learn more about Optimism and our work with the Optimism Collective in the articles below:

[Untitled](Intro%20to%20Optimism%20e5fb1de4d081486193bae5efbd3ae977/Untitled%205c8a270c70eb43e7a1f2a7b2353b1fe2.csv)

- 
    
    
    ![[https://edenfractal.com/66](https://edenfractal.com/66)](../../EdenFractal%20com%2001042c8032d449da996a700c32f78534/Eden%20Fractal%20Website%20Database%20d542ab0a162c46e09a6d1291e836d36b/Videos%203e3eba6903524c0e8ae9aa47be6cd682/EF_66_msig_thumbnail_final2.png)
    
    [https://edenfractal.com/66](https://edenfractal.com/66)
    
    ### [**EF 66: Permission Possible**](https://edenfractal.com/66)
    
    Hip hip hooray! Our mythical heroes approved three proposals to update the eden.fractal permissions and explored an introduction to the Optimism Collective, a new type of community designed to reward public goods and build a sustainable future for all 🌞 🔴
    
    ![[https://edenfractal.com/67](https://edenfractal.com/67)](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6/EF_67_msig_new_sunny_final.png)
    
    [https://edenfractal.com/67](https://edenfractal.com/67)
    
    ### [EF 67: Growing with Optimism](https://edenfractal.com/67)
    
    What are the synergies between Eden Fractal and Optimism? In the next stage of our epic journey we explore opportunities to help humanity flourish and summon Ether’s Phoenix with innovations in retroactive public goods funding 🌱 🌞