# The Growth of Optimism

Displays on Pages:: EF 69, Intro to Optimism
AI summary: This article explores the initiatives of the Optimism Collective and Superchain aimed at fostering a regenerative society through community engagement and public goods. It includes insights from a live discussion during the 69th Eden Fractal meeting, emphasizing the importance of collaboration and sustainable practices.
AI summary 1: In this blog post, we explore the concept of optimism and its significance in fostering a regenerative society through the efforts of the Optimism Collective and Superchain. The article highlights educational resources aimed at understanding how these initiatives promote public goods and enhance community coordination. Drawing insights from a live discussion during the 69th Eden Fractal meeting, we delve into the values that underpin the Optimism movement and its commitment to creating a sustainable future for the open internet. Join us as we uncover the growth of optimism and its impact on our collective well-being.
Description: Educational resources about the Optimism Collective and Superchain to build a more regenerative society for all 🌃
Published?: Yes

![Image created by the Optimism Foundation](The%20Growth%20of%20Optimism%20234b893e40af492bb9e45af0d680277a/2020-04-11_11-06-04.png)

Image created by the Optimism Foundation

### Welcome!

This article provides educational resources about the Optimism Collective and Superchain to build a more regenerative society for all.  The following was written in September 2023 and provides timestamps from a live discussion with community leaders during the 69th Eden Fractal meeting, which you can see below or in the original [show notes](https://edenfractal.com/68). For the latest updates and most detailed information, visit [Optimism.io](http://Optimism.io). Enjoy!

### What is Optimism?

For anyone that’s unfamiliar with [Optimism Collective](https://app.optimism.io/announcement), it is a new type of community designed to reward public goods and build a sustainable future for the open internet. Optimism is a pioneering [Ethereum](https://ethereum.org/en/) L2 community that is highly aligned with fractal community values for creating public goods and improving human coordination for everyone’s benefit!

![Image created by the Optimism Foundation](The%20Growth%20of%20Optimism%20234b893e40af492bb9e45af0d680277a/optimism_city.png)

Image created by the Optimism Foundation

### How is Optimism Growing?

The growth of Optimism is immense and we’re making educational content to help convey the benefits. One of the questions asked was about the number of existing DAOs on Optimism. From [2:01:04](https://www.youtube.com/watch?v=hlmDnOkudTw&t=3664s) to [2:05:14](https://www.youtube.com/watch?v=hlmDnOkudTw&t=3914s), Dan Singjoy endeavored to provide data on adoption detailing participation in RetroPGF and the promising undertakings using the OP stack. 

To further support views, Dan presented the Superchain website at [2:07:05](https://youtu.be/hlmDnOkudTw?t=7625) showing the many chains using the OP stack. He gave examples like [Basechain](https://base.org/) launched by [Coinbase](https://www.coinbase.com/) and [Worldcoin](https://worldcoin.org/) built by [OpenAI](https://openai.com/). At [2:09:12](https://youtu.be/hlmDnOkudTw?t=7752), Dan explained one of the best ways to start building and familiarise with the scope of opportunities is to gauge adoption looking at the [recipients of RetroPGF 2](https://docs.google.com/spreadsheets/d/13QTVuv4HTTDBctRxuqngECUMc70QP4usbmcFT8XT-GI/edit#gid=583271201). This list helps to get a sense of what’s been rewarded in the past and therefore, inspire collaboration. (A quick update here is that users can’t access the project profiles from the last round because the page was deprecated, so an alternative of this is the recently launched archive [page](https://retropgfhub.com/archive) in the RetroPGF Hub, which is made by a community member. He advices to correct anything in case its incorrectly listed). Dan noted about 200 projects that received funding in the retroPGF2 results page, where 10m OP tokens were distributed to fund public goods that support development and usage of the OP Stack.

Continuing on at [2:04:12](https://www.youtube.com/watch?v=hlmDnOkudTw&t=8027s), Dan emphasized the significant impact on funding retroactively and the many community supporters routing for support public goods projects on Optimism. The new season of retroPGF Round 3 has 30 million OP tokens allocated to reward contributions that have supported the development and adoption of Optimism (and this is just the beginning!). Dan resurfaced once again at [2:09:53](https://youtu.be/hlmDnOkudTw?t=7793) the love for public goods and humanity, which gets supported more and more with each new season of [RetroPGF](https://edencreators.com/optimism#1e553c1188134f86b5c1e45189fb64b1). This represents the biggest opportunity for Optimism Fractal and the team is excited to port over the exciting social games and fractal governance tools to Optimism’s ecosystem. 🔴 🌱 

### Full Episode

Watch the full episode below to see all the exciting discussions and check out this [article](The%20Roots%20of%20Optimism%20Fractal%20081143d25ab640c1bcbd8cc2fc2aa3e6.md) for more details about the roots of Optimism Fractal. Thanks for reading and watching :)

[https://youtu.be/hlmDnOkudTw?si=ugHfXSKuAt-AcaLG](https://youtu.be/hlmDnOkudTw?si=ugHfXSKuAt-AcaLG)

**EF 69: Regeneration Nation**

What are the best ways to build a more regenerative society? We explore Optimism Fractal, RetroPGF Round 3, and the Interplanetary Unconference to help create a peaceful, sustainable future for all 🌻 🙏🏽 🌞